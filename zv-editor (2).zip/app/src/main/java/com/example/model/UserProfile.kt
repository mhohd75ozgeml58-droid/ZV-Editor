package com.example.model

data class UserProfile(
  val name: String = "",
  val email: String = "",
  val photoUrl: String? = null,
  val isGuest: Boolean = false,
  val isAuthenticated: Boolean = false
) {
  companion object {
    val GUEST = UserProfile(
      name = "Guest Creator",
      email = "guest@zveditor.app",
      isGuest = true,
      isAuthenticated = true
    )
    val ANONYMOUS = UserProfile(
      name = "",
      email = "",
      isGuest = false,
      isAuthenticated = false
    )
  }
}
