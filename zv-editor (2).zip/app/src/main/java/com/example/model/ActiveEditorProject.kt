package com.example.model

import androidx.compose.ui.graphics.Color
import com.example.data.db.ProjectEntity

data class ActiveEditorProject(
  val id: Long = 0,
  val title: String = "ZV_Project_${System.currentTimeMillis() % 10000}",
  val type: String = "VIDEO", // "VIDEO" or "PHOTO"
  val mediaUri: String = "",
  val durationSeconds: Float = 15.0f,
  val currentPositionSeconds: Float = 0.0f,
  val isPlaying: Boolean = false,
  val aspectRatio: String = "9:16", // "9:16", "16:9", "1:1", "4:5"
  
  // Cut / Trim / Split
  val trimStartSeconds: Float = 0.0f,
  val trimEndSeconds: Float = 15.0f,
  val splitPointSeconds: Float = 7.5f,
  val cutSegments: List<Pair<Float, Float>> = emptyList(),

  // Crop / Transform
  val cropRatio: String = "Original",
  val rotationDegrees: Int = 0,
  val flipHorizontal: Boolean = false,
  val flipVertical: Boolean = false,

  // Speed & Audio
  val speed: Float = 1.0f, // 0.25x to 3.0x
  val volume: Float = 1.0f, // 0 to 2.0 (200%)
  val isMuted: Boolean = false,

  // Filters & Adjustments
  val filterName: String = "Normal",
  val filterIntensity: Float = 1.0f,
  val brightness: Float = 0.0f, // -1f to 1f
  val contrast: Float = 1.0f, // 0.5f to 2.0f
  val saturation: Float = 1.0f, // 0f to 2.0f
  val warmth: Float = 0.0f,
  val exposure: Float = 0.0f,
  val blurRadius: Float = 0.0f,

  // Effects & Transitions
  val effectName: String = "None",
  val effectIntensity: Float = 0.8f,
  val transitionName: String = "None",
  val animationType: String = "None",

  // Music & Voice
  val musicTrackName: String = "None",
  val musicVolume: Float = 0.8f,
  val musicStartSeconds: Float = 0.0f,
  val recordedVoiceDurationSeconds: Float = 0.0f,
  val isVoiceRecordingActive: Boolean = false,

  // Text & Stickers
  val textOverlay: String = "",
  val textColor: Long = 0xFFFFFFFF,
  val textSize: Float = 24.0f,
  val textPositionX: Float = 0.5f,
  val textPositionY: Float = 0.5f,
  val textAnimation: String = "None",
  val textFont: String = "Sans",
  val textBackgroundColor: Long? = 0x88000000,
  val stickerName: String = "",
  val stickerScale: Float = 1.0f,
  val stickerPositionX: Float = 0.5f,
  val stickerPositionY: Float = 0.35f
) {
  fun toEntity(): ProjectEntity {
    return ProjectEntity(
      id = id,
      title = title,
      type = type,
      mediaUri = mediaUri,
      durationSeconds = durationSeconds,
      aspectRatio = aspectRatio,
      filterName = filterName,
      filterIntensity = filterIntensity,
      brightness = brightness,
      contrast = contrast,
      saturation = saturation,
      volume = volume,
      speed = speed,
      rotationDegrees = rotationDegrees,
      cropRatio = cropRatio,
      trimStartSeconds = trimStartSeconds,
      trimEndSeconds = trimEndSeconds,
      splitPointSeconds = splitPointSeconds,
      musicTrackName = musicTrackName,
      musicVolume = musicVolume,
      musicStartSeconds = musicStartSeconds,
      textOverlay = textOverlay,
      textColor = textColor,
      textSize = textSize,
      textPositionX = textPositionX,
      textPositionY = textPositionY,
      textAnimation = textAnimation,
      textFont = textFont,
      stickerName = stickerName,
      effectName = effectName,
      transitionName = transitionName,
      lastModifiedTimestamp = System.currentTimeMillis()
    )
  }

  companion object {
    fun fromEntity(entity: ProjectEntity): ActiveEditorProject {
      return ActiveEditorProject(
        id = entity.id,
        title = entity.title,
        type = entity.type,
        mediaUri = entity.mediaUri,
        durationSeconds = entity.durationSeconds,
        aspectRatio = entity.aspectRatio,
        filterName = entity.filterName,
        filterIntensity = entity.filterIntensity,
        brightness = entity.brightness,
        contrast = entity.contrast,
        saturation = entity.saturation,
        volume = entity.volume,
        speed = entity.speed,
        rotationDegrees = entity.rotationDegrees,
        cropRatio = entity.cropRatio,
        trimStartSeconds = entity.trimStartSeconds,
        trimEndSeconds = entity.trimEndSeconds,
        splitPointSeconds = entity.splitPointSeconds,
        musicTrackName = entity.musicTrackName,
        musicVolume = entity.musicVolume,
        musicStartSeconds = entity.musicStartSeconds,
        textOverlay = entity.textOverlay,
        textColor = entity.textColor,
        textSize = entity.textSize,
        textPositionX = entity.textPositionX,
        textPositionY = entity.textPositionY,
        textAnimation = entity.textAnimation,
        textFont = entity.textFont,
        stickerName = entity.stickerName,
        effectName = entity.effectName,
        transitionName = entity.transitionName
      )
    }

    val SAMPLE_VIDEOS = listOf(
      "https://images.unsplash.com/photo-1536240478700-b869070f9279?auto=format&fit=crop&w=1080&q=80",
      "https://images.unsplash.com/photo-1518173946687-a4c8a383392e?auto=format&fit=crop&w=1080&q=80",
      "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=1080&q=80",
      "https://images.unsplash.com/photo-1534447677768-be436bb09401?auto=format&fit=crop&w=1080&q=80"
    )

    val SAMPLE_PHOTOS = listOf(
      "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=1080&q=80",
      "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=1080&q=80",
      "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=1080&q=80",
      "https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=1080&q=80"
    )
  }
}
