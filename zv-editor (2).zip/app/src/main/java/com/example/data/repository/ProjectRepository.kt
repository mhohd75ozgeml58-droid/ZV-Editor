package com.example.data.repository

import android.content.Context
import com.example.data.db.ProjectDao
import com.example.data.db.ProjectEntity
import com.example.data.db.ZvDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class ProjectRepository(private val projectDao: ProjectDao) {

  val allProjects: Flow<List<ProjectEntity>> = projectDao.getAllProjects()

  suspend fun getProjectById(id: Long): ProjectEntity? = withContext(Dispatchers.IO) {
    projectDao.getProjectById(id)
  }

  suspend fun saveProject(project: ProjectEntity): Long = withContext(Dispatchers.IO) {
    if (project.id > 0) {
      projectDao.updateProject(project.copy(lastModifiedTimestamp = System.currentTimeMillis()))
      project.id
    } else {
      projectDao.insertProject(project.copy(lastModifiedTimestamp = System.currentTimeMillis()))
    }
  }

  suspend fun deleteProject(id: Long) = withContext(Dispatchers.IO) {
    projectDao.deleteProjectById(id)
  }

  suspend fun renameProject(id: Long, newTitle: String) = withContext(Dispatchers.IO) {
    projectDao.renameProject(id, newTitle)
  }

  suspend fun duplicateProject(id: Long): Long? = withContext(Dispatchers.IO) {
    val existing = projectDao.getProjectById(id) ?: return@withContext null
    val cloned = existing.copy(
      id = 0,
      title = "${existing.title} (Copy)",
      lastModifiedTimestamp = System.currentTimeMillis()
    )
    projectDao.insertProject(cloned)
  }

  companion object {
    @Volatile
    private var INSTANCE: ProjectRepository? = null

    fun getRepository(context: Context): ProjectRepository {
      return INSTANCE ?: synchronized(this) {
        val db = ZvDatabase.getDatabase(context)
        val repo = ProjectRepository(db.projectDao())
        INSTANCE = repo
        repo
      }
    }
  }
}
