package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Room Entity storing all project attributes for Video and Photo edits.
 */
@Entity(tableName = "projects")
data class ProjectEntity(
  @PrimaryKey(autoGenerate = true)
  val id: Long = 0,
  val title: String,
  val type: String = "VIDEO", // "VIDEO" or "PHOTO"
  val mediaUri: String = "",
  val durationSeconds: Float = 15.0f,
  val aspectRatio: String = "9:16", // 9:16, 16:9, 1:1, 4:5
  val filterName: String = "Normal",
  val filterIntensity: Float = 1.0f,
  val brightness: Float = 0.0f,
  val contrast: Float = 1.0f,
  val saturation: Float = 1.0f,
  val volume: Float = 1.0f,
  val speed: Float = 1.0f,
  val rotationDegrees: Int = 0,
  val cropRatio: String = "Original",
  val trimStartSeconds: Float = 0.0f,
  val trimEndSeconds: Float = 15.0f,
  val splitPointSeconds: Float = 7.5f,
  val musicTrackName: String = "None",
  val musicVolume: Float = 0.8f,
  val musicStartSeconds: Float = 0.0f,
  val recordedVoiceUri: String? = null,
  val textOverlay: String = "",
  val textColor: Long = 0xFFFFFFFF,
  val textSize: Float = 22.0f,
  val textPositionX: Float = 0.5f, // normalized 0..1
  val textPositionY: Float = 0.5f,
  val textAnimation: String = "None", // Fade, Pop, Slide, Typewriter
  val textFont: String = "Sans",
  val stickerName: String = "",
  val effectName: String = "None", // Glitch, Lens Flare, Film Grain, Vignette, Blur
  val transitionName: String = "None", // Fade, Dissolve, Zoom In, Wipe
  val lastModifiedTimestamp: Long = System.currentTimeMillis()
)
