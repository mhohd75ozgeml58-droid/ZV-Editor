package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [ProjectEntity::class], version = 1, exportSchema = false)
abstract class ZvDatabase : RoomDatabase() {
  abstract fun projectDao(): ProjectDao

  companion object {
    @Volatile
    private var INSTANCE: ZvDatabase? = null

    fun getDatabase(context: Context): ZvDatabase {
      return INSTANCE ?: synchronized(this) {
        val instance = Room.databaseBuilder(
          context.applicationContext,
          ZvDatabase::class.java,
          "zv_editor_database"
        )
          .fallbackToDestructiveMigration()
          .build()
        INSTANCE = instance
        instance
      }
    }
  }
}
