package com.example.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.GlowBackground
import com.example.ui.components.ZvBrandHeader
import com.example.ui.components.ZvLogoBadge
import com.example.ui.components.ZvTagline
import com.example.ui.components.ZvWordmark
import com.example.ui.theme.ZvBlack
import com.example.ui.theme.ZvOrangeBright
import com.example.ui.theme.ZvOrangeDeep
import com.example.ui.theme.ZvOrangeGradientEnd
import com.example.ui.theme.ZvOrangePrimary
import com.example.ui.theme.ZvTextMuted
import com.example.ui.theme.ZvTextSecondary
import com.example.ui.theme.ZvWhite
import kotlinx.coroutines.delay

/**
 * Splash Screen featuring:
 * - Animated ZV logo & badge
 * - Radiant Black + Orange theme
 * - Automatic transition to Welcome Screen after a few seconds
 * - Interactive Skip affordance
 */
@Composable
fun SplashScreen(
  onFinishSplash: () -> Unit,
  modifier: Modifier = Modifier
) {
  val scaleAnim = remember { Animatable(0.72f) }
  val alphaAnim = remember { Animatable(0f) }
  val progressAnim = remember { Animatable(0f) }

  // Auto transition after ~2.8 seconds
  LaunchedEffect(Unit) {
    // Entrance animations
    scaleAnim.animateTo(
      targetValue = 1f,
      animationSpec = tween(durationMillis = 800, easing = FastOutSlowInEasing)
    )
    alphaAnim.animateTo(
      targetValue = 1f,
      animationSpec = tween(durationMillis = 600)
    )

    // Progress bar fill
    progressAnim.animateTo(
      targetValue = 1f,
      animationSpec = tween(durationMillis = 2000, easing = LinearEasing)
    )

    // Small delay before transition
    delay(200)
    onFinishSplash()
  }

  val infiniteTransition = rememberInfiniteTransition(label = "splash_halo")
  val haloScale by infiniteTransition.animateFloat(
    initialValue = 1f,
    targetValue = 1.15f,
    animationSpec = infiniteRepeatable(
      animation = tween(1200, easing = FastOutSlowInEasing),
      repeatMode = RepeatMode.Reverse
    ),
    label = "halo_scale"
  )
  val haloAlpha by infiniteTransition.animateFloat(
    initialValue = 0.25f,
    targetValue = 0.65f,
    animationSpec = infiniteRepeatable(
      animation = tween(1200, easing = FastOutSlowInEasing),
      repeatMode = RepeatMode.Reverse
    ),
    label = "halo_alpha"
  )

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(ZvBlack)
      .testTag("splash_screen")
      .clickable(
        interactionSource = remember { MutableInteractionSource() },
        indication = null
      ) {
        onFinishSplash()
      }
  ) {
    // Luminous black & orange wave canvas
    GlowBackground(animated = true)

    // Top action bar with Skip button
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .statusBarsPadding()
        .padding(horizontal = 20.dp, vertical = 14.dp),
      horizontalArrangement = Arrangement.End,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Box(
        modifier = Modifier
          .clip(RoundedCornerShape(20.dp))
          .background(Color(0x33000000))
          .border(1.dp, Color(0x44FF6A00), RoundedCornerShape(20.dp))
          .clickable { onFinishSplash() }
          .padding(horizontal = 14.dp, vertical = 6.dp)
          .testTag("skip_splash_button")
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(
            text = "Skip",
            color = ZvOrangeBright,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold
          )
          Spacer(modifier = Modifier.width(4.dp))
          Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
            contentDescription = "Skip to Welcome Screen",
            tint = ZvOrangeBright,
            modifier = Modifier.size(14.dp)
          )
        }
      }
    }

    // Main Center Logo Presentation
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(horizontal = 28.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center
    ) {
      Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
          .scale(scaleAnim.value)
          .alpha(alphaAnim.value)
      ) {
        // Ambient neon pulsing halo behind logo
        Box(
          modifier = Modifier
            .size(140.dp)
            .scale(haloScale)
            .alpha(haloAlpha)
            .clip(CircleShape)
            .background(
              Brush.radialGradient(
                colors = listOf(
                  ZvOrangePrimary.copy(alpha = 0.5f),
                  Color.Transparent
                )
              )
            )
        )

        // The stylized ZV badge
        ZvLogoBadge(
          size = 88.dp,
          pulsingGlow = true
        )
      }

      Spacer(modifier = Modifier.height(24.dp))

      // ZV Wordmark (Orange Z, White V)
      ZvWordmark(
        modifier = Modifier
          .scale(scaleAnim.value)
          .alpha(alphaAnim.value),
        fontSize = 52f
      )

      Spacer(modifier = Modifier.height(6.dp))

      // Tagline
      ZvTagline(
        modifier = Modifier.alpha(alphaAnim.value),
        fontSize = 15f
      )

      Spacer(modifier = Modifier.height(36.dp))

      // Subtitle badge
      Box(
        modifier = Modifier
          .clip(RoundedCornerShape(30.dp))
          .background(Color(0x22FF6A00))
          .border(1.dp, Color(0x33FF6A00), RoundedCornerShape(30.dp))
          .padding(horizontal = 16.dp, vertical = 7.dp)
          .alpha(alphaAnim.value)
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = Icons.Default.AutoAwesome,
            contentDescription = null,
            tint = ZvOrangeBright,
            modifier = Modifier.size(14.dp)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = "Video & Photo Editor",
            color = ZvWhite,
            fontSize = 12.5.sp,
            fontWeight = FontWeight.Medium,
            letterSpacing = 0.5.sp
          )
        }
      }
    }

    // Bottom loading progress section
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .align(Alignment.BottomCenter)
        .navigationBarsPadding()
        .padding(horizontal = 36.dp, vertical = 28.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = "Starting Studio...",
          color = ZvTextSecondary,
          fontSize = 12.sp,
          fontWeight = FontWeight.Medium
        )
        Text(
          text = "${(progressAnim.value * 100).toInt()}%",
          color = ZvOrangeBright,
          fontSize = 12.sp,
          fontWeight = FontWeight.Bold
        )
      }

      Spacer(modifier = Modifier.height(8.dp))

      // Sleek gradient progress track
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(5.dp)
          .clip(RoundedCornerShape(3.dp))
          .background(Color(0x332E1A0E))
      ) {
        Box(
          modifier = Modifier
            .fillMaxWidth(progressAnim.value)
            .height(5.dp)
            .clip(RoundedCornerShape(3.dp))
            .background(
              Brush.horizontalGradient(
                colors = listOf(
                  ZvOrangeDeep,
                  ZvOrangePrimary,
                  ZvOrangeGradientEnd
                )
              )
            )
            .shadow(4.dp, shape = RoundedCornerShape(3.dp), spotColor = ZvOrangePrimary)
        )
      }

      Spacer(modifier = Modifier.height(14.dp))

      Text(
        text = "Tap anywhere to continue",
        color = ZvTextMuted,
        fontSize = 11.sp,
        fontWeight = FontWeight.Normal
      )
    }
  }
}
