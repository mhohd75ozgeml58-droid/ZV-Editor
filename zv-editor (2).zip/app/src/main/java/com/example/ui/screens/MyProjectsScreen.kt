package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.db.ProjectEntity
import com.example.data.repository.ProjectRepository
import com.example.ui.components.GlowBackground
import com.example.ui.theme.ZvBlack
import com.example.ui.theme.ZvBlackCard
import com.example.ui.theme.ZvBlackSurface
import com.example.ui.theme.ZvOrangeBright
import com.example.ui.theme.ZvOrangePrimary
import com.example.ui.theme.ZvTextMuted
import com.example.ui.theme.ZvTextSecondary
import com.example.ui.theme.ZvWhite
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 12. My Projects Screen
 * Real Room Database management:
 * - Open
 * - Edit
 * - Rename
 * - Duplicate
 * - Delete
 */
@Composable
fun MyProjectsScreen(
  onBack: () -> Unit,
  onOpenProject: (ProjectEntity) -> Unit,
  onNewProject: () -> Unit,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val repository = remember { ProjectRepository.getRepository(context) }
  val projects by repository.allProjects.collectAsState(initial = emptyList())
  val coroutineScope = rememberCoroutineScope()

  var searchQuery by remember { mutableStateOf("") }
  var filterType by remember { mutableStateOf("ALL") } // "ALL", "VIDEO", "PHOTO"

  var projectToRename by remember { mutableStateOf<ProjectEntity?>(null) }
  var projectToDelete by remember { mutableStateOf<ProjectEntity?>(null) }
  var renameInput by remember { mutableStateOf("") }

  val filteredProjects = remember(projects, searchQuery, filterType) {
    projects.filter { p ->
      val matchesQuery = searchQuery.isBlank() || p.title.contains(searchQuery, ignoreCase = true)
      val matchesType = filterType == "ALL" || p.type.equals(filterType, ignoreCase = true)
      matchesQuery && matchesType
    }
  }

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(ZvBlack)
      .testTag("my_projects_screen")
  ) {
    GlowBackground(animated = false)

    // Outer Neon Orange Container
    Box(
      modifier = Modifier
        .fillMaxSize()
        .statusBarsPadding()
        .navigationBarsPadding()
        .padding(6.dp)
        .border(
          width = 2.dp,
          brush = Brush.verticalGradient(
            colors = listOf(Color(0xFFFF7A00), Color(0xFFFF5200), Color(0xFFFF8800))
          ),
          shape = RoundedCornerShape(20.dp)
        )
        .clip(RoundedCornerShape(20.dp))
        .background(Color(0xFF0A0A0C))
    ) {
      Column(modifier = Modifier.fillMaxSize()) {
        // --- Top Bar ---
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 10.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(
              onClick = onBack,
              modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(Color(0x331F1F24))
                .testTag("projects_back_button")
            ) {
              Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = "Back",
                tint = ZvOrangePrimary,
                modifier = Modifier.size(18.dp)
              )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = "My Projects",
                color = ZvWhite,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
              )
              Text(
                text = "${projects.size} saved projects",
                color = ZvTextMuted,
                fontSize = 11.sp
              )
            }
          }

          // New Project button
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(16.dp))
              .background(ZvOrangePrimary)
              .clickable { onNewProject() }
              .padding(horizontal = 12.dp, vertical = 6.dp)
              .testTag("btn_new_project_in_list")
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Default.Add, contentDescription = null, tint = ZvWhite, modifier = Modifier.size(14.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("New Project", color = ZvWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
          }
        }

        // Search Bar
        OutlinedTextField(
          value = searchQuery,
          onValueChange = { searchQuery = it },
          placeholder = { Text("Search projects by name...", fontSize = 13.sp) },
          leadingIcon = {
            Icon(Icons.Default.Search, contentDescription = null, tint = ZvOrangeBright, modifier = Modifier.size(18.dp))
          },
          singleLine = true,
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 4.dp),
          colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = ZvWhite,
            unfocusedTextColor = ZvWhite,
            focusedBorderColor = ZvOrangePrimary,
            unfocusedBorderColor = Color(0x33FF6A00),
            focusedPlaceholderColor = ZvTextMuted,
            unfocusedPlaceholderColor = ZvTextMuted
          ),
          shape = RoundedCornerShape(12.dp)
        )

        // Type Filter Chips: All, Video, Photo
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp, vertical = 6.dp),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          listOf("ALL" to "All", "VIDEO" to "🎬 Videos", "PHOTO" to "🖼️ Photos").forEach { (typeKey, label) ->
            val isSelected = filterType == typeKey
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(16.dp))
                .background(if (isSelected) ZvOrangePrimary else ZvBlackCard)
                .border(
                  width = 1.dp,
                  color = if (isSelected) ZvOrangePrimary else Color(0x33FF6A00),
                  shape = RoundedCornerShape(16.dp)
                )
                .clickable { filterType = typeKey }
                .padding(horizontal = 14.dp, vertical = 6.dp)
            ) {
              Text(
                text = label,
                color = if (isSelected) ZvWhite else ZvTextSecondary,
                fontSize = 11.5.sp,
                fontWeight = FontWeight.Bold
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Projects List
        if (filteredProjects.isEmpty()) {
          Box(
            modifier = Modifier
              .fillMaxSize()
              .padding(32.dp),
            contentAlignment = Alignment.Center
          ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              Icon(
                imageVector = Icons.Default.Folder,
                contentDescription = null,
                tint = Color(0x66FF6A00),
                modifier = Modifier.size(48.dp)
              )
              Spacer(modifier = Modifier.height(12.dp))
              Text(
                text = if (searchQuery.isNotBlank()) "No matching projects found" else "No saved projects yet",
                color = ZvWhite,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold
              )
              Text(
                text = "Tap '+ New Project' to start creating in ZV Editor",
                color = ZvTextMuted,
                fontSize = 12.sp,
                textAlign = TextAlign.Center
              )
            }
          }
        } else {
          LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 14.dp, end = 14.dp, bottom = 80.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            items(filteredProjects, key = { it.id }) { project ->
              ProjectListItemCard(
                project = project,
                onOpen = { onOpenProject(project) },
                onRename = {
                  projectToRename = project
                  renameInput = project.title
                },
                onDuplicate = {
                  coroutineScope.launch {
                    repository.duplicateProject(project.id)
                  }
                },
                onDelete = {
                  projectToDelete = project
                }
              )
            }
          }
        }
      }

      // Floating New Project Button
      FloatingActionButton(
        onClick = onNewProject,
        containerColor = ZvOrangePrimary,
        contentColor = ZvWhite,
        shape = CircleShape,
        modifier = Modifier
          .align(Alignment.BottomEnd)
          .padding(20.dp)
      ) {
        Icon(Icons.Default.Add, contentDescription = "Create", modifier = Modifier.size(26.dp))
      }
    }

    // Rename Dialog
    if (projectToRename != null) {
      AlertDialog(
        onDismissRequest = { projectToRename = null },
        containerColor = ZvBlackSurface,
        shape = RoundedCornerShape(18.dp),
        title = {
          Text("Rename Project", color = ZvWhite, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        },
        text = {
          Column {
            Text("Enter a new title for this project:", color = ZvTextSecondary, fontSize = 12.sp)
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
              value = renameInput,
              onValueChange = { renameInput = it },
              singleLine = true,
              colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = ZvWhite,
                unfocusedTextColor = ZvWhite,
                focusedBorderColor = ZvOrangePrimary,
                unfocusedBorderColor = Color(0x44FF6A00)
              ),
              shape = RoundedCornerShape(10.dp)
            )
          }
        },
        confirmButton = {
          Button(
            onClick = {
              val current = projectToRename
              if (current != null && renameInput.isNotBlank()) {
                coroutineScope.launch {
                  repository.renameProject(current.id, renameInput.trim())
                  projectToRename = null
                }
              }
            },
            colors = ButtonDefaults.buttonColors(containerColor = ZvOrangePrimary),
            shape = RoundedCornerShape(10.dp)
          ) {
            Text("Save", color = ZvWhite, fontWeight = FontWeight.Bold)
          }
        },
        dismissButton = {
          TextButton(onClick = { projectToRename = null }) {
            Text("Cancel", color = ZvTextMuted)
          }
        }
      )
    }

    // Delete Confirmation Dialog
    if (projectToDelete != null) {
      AlertDialog(
        onDismissRequest = { projectToDelete = null },
        containerColor = ZvBlackSurface,
        shape = RoundedCornerShape(18.dp),
        title = {
          Text("Delete Project?", color = ZvWhite, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        },
        text = {
          Text(
            text = "Are you sure you want to delete \"${projectToDelete?.title}\"? This action cannot be undone.",
            color = ZvTextSecondary,
            fontSize = 13.sp
          )
        },
        confirmButton = {
          Button(
            onClick = {
              val current = projectToDelete
              if (current != null) {
                coroutineScope.launch {
                  repository.deleteProject(current.id)
                  projectToDelete = null
                }
              }
            },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF3D00)),
            shape = RoundedCornerShape(10.dp)
          ) {
            Text("Delete", color = ZvWhite, fontWeight = FontWeight.Bold)
          }
        },
        dismissButton = {
          TextButton(onClick = { projectToDelete = null }) {
            Text("Cancel", color = ZvTextMuted)
          }
        }
      )
    }
  }
}

/**
 * Individual Project List Item with 3-dot dropdown (Open, Edit, Rename, Duplicate, Delete)
 */
@Composable
fun ProjectListItemCard(
  project: ProjectEntity,
  onOpen: () -> Unit,
  onRename: () -> Unit,
  onDuplicate: () -> Unit,
  onDelete: () -> Unit
) {
  var menuExpanded by remember { mutableStateOf(false) }

  val dateFormatted = remember(project.lastModifiedTimestamp) {
    SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date(project.lastModifiedTimestamp))
  }

  Box(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(14.dp))
      .background(ZvBlackCard)
      .border(1.2.dp, Color(0x33FF6A00), RoundedCornerShape(14.dp))
      .clickable { onOpen() }
      .padding(10.dp)
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically
    ) {
      // Thumbnail
      Box(
        modifier = Modifier
          .size(72.dp)
          .clip(RoundedCornerShape(10.dp))
          .background(Color(0xFF18181B))
      ) {
        if (project.mediaUri.isNotBlank()) {
          AsyncImage(
            model = project.mediaUri,
            contentDescription = project.title,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
          )
        } else {
          Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Icon(
              imageVector = if (project.type == "VIDEO") Icons.Default.VideoLibrary else Icons.Default.Image,
              contentDescription = null,
              tint = ZvOrangePrimary,
              modifier = Modifier.size(28.dp)
            )
          }
        }

        // Type & aspect ratio badge
        Box(
          modifier = Modifier
            .align(Alignment.BottomStart)
            .padding(3.dp)
            .clip(RoundedCornerShape(4.dp))
            .background(Color(0xDD000000))
            .padding(horizontal = 4.dp, vertical = 2.dp)
        ) {
          Text(
            text = "${project.aspectRatio} • ${project.durationSeconds.toInt()}s",
            color = ZvWhite,
            fontSize = 8.5.sp,
            fontWeight = FontWeight.Bold
          )
        }
      }

      Spacer(modifier = Modifier.width(12.dp))

      // Info
      Column(modifier = Modifier.weight(1f)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(
            text = project.title,
            color = ZvWhite,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
          )
        }
        Spacer(modifier = Modifier.height(2.dp))
        Text(
          text = "Modified $dateFormatted",
          color = ZvTextMuted,
          fontSize = 10.5.sp
        )
        Spacer(modifier = Modifier.height(4.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          if (project.filterName != "Normal") {
            MiniFeatureTag(project.filterName)
          }
          if (project.musicTrackName != "None") {
            MiniFeatureTag("🎵 " + project.musicTrackName)
          }
          if (project.effectName != "None") {
            MiniFeatureTag("✨ " + project.effectName)
          }
        }
      }

      // 3-dot dropdown menu
      Box {
        IconButton(
          onClick = { menuExpanded = true },
          modifier = Modifier.size(36.dp)
        ) {
          Icon(Icons.Default.MoreVert, contentDescription = "Options", tint = ZvTextSecondary)
        }

        DropdownMenu(
          expanded = menuExpanded,
          onDismissRequest = { menuExpanded = false },
          modifier = Modifier
            .background(ZvBlackSurface)
            .border(1.dp, Color(0x33FF6A00), RoundedCornerShape(8.dp))
        ) {
          DropdownMenuItem(
            text = { Text("Open / Edit", color = ZvWhite, fontSize = 13.sp) },
            leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null, tint = ZvOrangeBright, modifier = Modifier.size(16.dp)) },
            onClick = {
              menuExpanded = false
              onOpen()
            }
          )
          DropdownMenuItem(
            text = { Text("Rename", color = ZvWhite, fontSize = 13.sp) },
            leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null, tint = ZvWhite, modifier = Modifier.size(16.dp)) },
            onClick = {
              menuExpanded = false
              onRename()
            }
          )
          DropdownMenuItem(
            text = { Text("Duplicate", color = ZvWhite, fontSize = 13.sp) },
            leadingIcon = { Icon(Icons.Default.ContentCopy, contentDescription = null, tint = ZvWhite, modifier = Modifier.size(16.dp)) },
            onClick = {
              menuExpanded = false
              onDuplicate()
            }
          )
          HorizontalDivider(color = Color(0x22FF6A00))
          DropdownMenuItem(
            text = { Text("Delete", color = Color(0xFFFF5252), fontSize = 13.sp) },
            leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = Color(0xFFFF5252), modifier = Modifier.size(16.dp)) },
            onClick = {
              menuExpanded = false
              onDelete()
            }
          )
        }
      }
    }
  }
}

@Composable
fun MiniFeatureTag(label: String) {
  Box(
    modifier = Modifier
      .clip(RoundedCornerShape(4.dp))
      .background(Color(0x22FF6A00))
      .padding(horizontal = 5.dp, vertical = 2.dp)
  ) {
    Text(label, color = ZvOrangeBright, fontSize = 9.sp, fontWeight = FontWeight.Medium)
  }
}
