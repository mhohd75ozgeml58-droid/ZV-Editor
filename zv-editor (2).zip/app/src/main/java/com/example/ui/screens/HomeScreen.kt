package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.outlined.EmojiEmotions
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.db.ProjectEntity
import com.example.data.repository.ProjectRepository
import com.example.model.ActiveEditorProject
import com.example.model.UserProfile
import com.example.ui.components.GlowBackground
import com.example.ui.components.ZvLogoBadge
import com.example.ui.components.ZvWordmark
import com.example.ui.theme.ZvBlack
import com.example.ui.theme.ZvBlackCard
import com.example.ui.theme.ZvBlackSurface
import com.example.ui.theme.ZvOrangeBright
import com.example.ui.theme.ZvOrangeDeep
import com.example.ui.theme.ZvOrangePrimary
import com.example.ui.theme.ZvTextMuted
import com.example.ui.theme.ZvTextSecondary
import com.example.ui.theme.ZvWhite
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 8 Core Buttons specification requested by user:
 * 1. 🎬 Video Editor
 * 2. 🖼️ Photo Editor
 * 3. 🎵 Music
 * 4. ✨ Effects
 * 5. 📝 Text
 * 6. 🖼️ Stickers
 * 7. 📁 My Projects
 * 8. ⚙️ Settings
 */
data class HomeTileItem(
  val id: String,
  val title: String,
  val subtitle: String,
  val icon: ImageVector,
  val emoji: String,
  val accentColor: Color = ZvOrangePrimary
)

val HOME_TILES = listOf(
  HomeTileItem("video_editor", "Video Editor", "Cut, Trim, Speed & Music", Icons.Default.VideoLibrary, "🎬"),
  HomeTileItem("photo_editor", "Photo Editor", "Crop, Filters, Resize & Text", Icons.Default.Image, "🖼️"),
  HomeTileItem("music", "Music Studio", "Add, Trim, Extract & Voice", Icons.Default.MusicNote, "🎵"),
  HomeTileItem("effects", "Effects & Filters", "Visual FX, Blur & Transitions", Icons.Default.AutoAwesome, "✨"),
  HomeTileItem("text", "Text Studio", "Fonts, Colors & Animations", Icons.Default.TextFields, "📝"),
  HomeTileItem("stickers", "Stickers", "Emojis, Badges & Overlays", Icons.Outlined.EmojiEmotions, "🖼️"),
  HomeTileItem("my_projects", "My Projects", "Saved Drafts & Exports", Icons.Default.Folder, "📁"),
  HomeTileItem("settings", "Settings", "Account, Theme & Quality", Icons.Default.Settings, "⚙️")
)

@Composable
fun HomeScreen(
  userProfile: UserProfile,
  onNavigateToVideoEditor: (mediaUri: String?) -> Unit,
  onNavigateToPhotoEditor: (photoUri: String?) -> Unit,
  onNavigateToMusicStudio: () -> Unit,
  onNavigateToEffectsStudio: () -> Unit,
  onNavigateToTextStudio: () -> Unit,
  onNavigateToStickersStudio: () -> Unit,
  onNavigateToMyProjects: () -> Unit,
  onNavigateToSettings: () -> Unit,
  onOpenProject: (ProjectEntity) -> Unit,
  onOpenAuth: () -> Unit,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val repository = remember { ProjectRepository.getRepository(context) }
  val projects by repository.allProjects.collectAsState(initial = emptyList())

  // Android Photo Picker for Video Selection
  val videoPickerLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.PickVisualMedia()
  ) { uri: Uri? ->
    if (uri != null) {
      onNavigateToVideoEditor(uri.toString())
    }
  }

  // Android Photo Picker for Photo Selection
  val photoPickerLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.PickVisualMedia()
  ) { uri: Uri? ->
    if (uri != null) {
      onNavigateToPhotoEditor(uri.toString())
    }
  }

  var showNewProjectDialog by remember { mutableStateOf(false) }

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(ZvBlack)
      .testTag("home_screen")
  ) {
    // Ambient glowing backdrop
    GlowBackground(animated = true)

    // Outer Neon Orange Framing Container
    Box(
      modifier = Modifier
        .fillMaxSize()
        .statusBarsPadding()
        .navigationBarsPadding()
        .padding(6.dp)
        .border(
          width = 2.dp,
          brush = Brush.verticalGradient(
            colors = listOf(
              Color(0xFFFF7A00),
              Color(0xFFFF5200),
              Color(0xFFFF8800)
            )
          ),
          shape = RoundedCornerShape(20.dp)
        )
        .clip(RoundedCornerShape(20.dp))
        .background(Color(0xFF09090B))
    ) {
      LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 80.dp)
      ) {
        // --- Top Bar: Brand, User Profile, Settings ---
        item {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              ZvLogoBadge(size = 36.dp, pulsingGlow = false)
              Column {
                ZvWordmark(fontSize = 22f)
                Text(
                  text = "Simple • Smart • Super Editing",
                  color = ZvTextMuted,
                  fontSize = 9.5.sp,
                  fontWeight = FontWeight.Medium
                )
              }
            }

            // User Profile / Login chip
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(20.dp))
                .background(Color(0x2218181B))
                .border(
                  width = 1.2.dp,
                  color = if (userProfile.isAuthenticated && !userProfile.isGuest) Color(0xFF00E676) else ZvOrangePrimary,
                  shape = RoundedCornerShape(20.dp)
                )
                .clickable {
                  if (userProfile.isAuthenticated && !userProfile.isGuest) {
                    onNavigateToSettings()
                  } else {
                    onOpenAuth()
                  }
                }
                .padding(horizontal = 10.dp, vertical = 5.dp)
                .testTag("home_user_chip")
            ) {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(5.dp)
              ) {
                Icon(
                  imageVector = Icons.Default.Person,
                  contentDescription = null,
                  tint = if (userProfile.isAuthenticated && !userProfile.isGuest) Color(0xFF00E676) else ZvOrangePrimary,
                  modifier = Modifier.size(15.dp)
                )
                Text(
                  text = if (userProfile.isAuthenticated && !userProfile.isGuest) {
                    userProfile.name.split(" ").firstOrNull() ?: "Creator"
                  } else if (userProfile.isGuest) {
                    "Guest"
                  } else {
                    "Login"
                  },
                  color = ZvWhite,
                  fontSize = 11.5.sp,
                  fontWeight = FontWeight.Bold
                )
              }
            }
          }
        }

        // --- Hero "New Video Project" Quick Launch Banner ---
        item {
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 14.dp, vertical = 6.dp)
              .shadow(12.dp, RoundedCornerShape(18.dp), spotColor = ZvOrangePrimary)
              .clip(RoundedCornerShape(18.dp))
              .background(
                Brush.horizontalGradient(
                  colors = listOf(
                    Color(0xFF241005),
                    Color(0xFF140A04),
                    Color(0xFF1F0E04)
                  )
                )
              )
              .border(
                1.5.dp,
                Brush.horizontalGradient(
                  colors = listOf(
                    Color(0xFFFF7A00),
                    Color(0xFFFF3D00),
                    Color(0xFFFF8800)
                  )
                ),
                RoundedCornerShape(18.dp)
              )
              .padding(16.dp)
          ) {
            Column {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
              ) {
                Column(modifier = Modifier.weight(1f)) {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                      text = "NEW PROJECT",
                      color = ZvOrangeBright,
                      fontSize = 11.sp,
                      fontWeight = FontWeight.ExtraBold,
                      letterSpacing = 1.2.sp
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(
                      modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0x33FF6A00))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                      Text("4K / 60FPS", color = ZvWhite, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }
                  }
                  Spacer(modifier = Modifier.height(4.dp))
                  Text(
                    text = "Create. Edit. Share.",
                    color = ZvWhite,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                  )
                  Text(
                    text = "Pick videos or photos from gallery to begin editing with multi-track timeline",
                    color = ZvTextSecondary,
                    fontSize = 11.5.sp,
                    lineHeight = 16.sp
                  )
                }

                // Neon Action Button
                Box(
                  modifier = Modifier
                    .size(52.dp)
                    .clip(CircleShape)
                    .background(
                      Brush.linearGradient(
                        colors = listOf(Color(0xFFFF7A00), Color(0xFFFF3D00))
                      )
                    )
                    .clickable {
                      videoPickerLauncher.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                      )
                    }
                    .testTag("hero_new_project_button"),
                  contentAlignment = Alignment.Center
                ) {
                  Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "New Project",
                    tint = ZvWhite,
                    modifier = Modifier.size(28.dp)
                  )
                }
              }

              Spacer(modifier = Modifier.height(14.dp))

              // Direct Gallery & Sample Clips buttons
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
              ) {
                // Select from Gallery button
                Box(
                  modifier = Modifier
                    .weight(1f)
                    .height(38.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(ZvOrangePrimary)
                    .clickable {
                      videoPickerLauncher.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo)
                      )
                    }
                    .testTag("gallery_picker_btn"),
                  contentAlignment = Alignment.Center
                ) {
                  Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                  ) {
                    Icon(Icons.Default.VideoLibrary, contentDescription = null, tint = ZvWhite, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Select from Gallery", color = ZvWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                  }
                }

                // Sample Template
                Box(
                  modifier = Modifier
                    .weight(1f)
                    .height(38.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0x22FFFFFF))
                    .border(1.dp, Color(0x33FF6A00), RoundedCornerShape(10.dp))
                    .clickable {
                      onNavigateToVideoEditor(ActiveEditorProject.SAMPLE_VIDEOS.first())
                    }
                    .testTag("sample_template_btn"),
                  contentAlignment = Alignment.Center
                ) {
                  Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                  ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null, tint = ZvOrangeBright, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Use Demo Clip", color = ZvWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                  }
                }
              }
            }
          }
        }

        // --- 8 Main Buttons Section Header ---
        item {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(start = 16.dp, end = 16.dp, top = 18.dp, bottom = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = "ZV STUDIO TOOLS",
              color = ZvWhite,
              fontSize = 14.sp,
              fontWeight = FontWeight.ExtraBold,
              letterSpacing = 1.sp
            )
            Text(
              text = "8 Core Modules",
              color = ZvOrangeBright,
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold
            )
          }
        }

        // --- 8 Main Tiles Grid ---
        item {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            // Row 1: Video Editor & Photo Editor
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
              HomeToolCard(
                tile = HOME_TILES[0],
                modifier = Modifier.weight(1f),
                onClick = {
                  videoPickerLauncher.launch(
                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo)
                  )
                }
              )
              HomeToolCard(
                tile = HOME_TILES[1],
                modifier = Modifier.weight(1f),
                onClick = {
                  photoPickerLauncher.launch(
                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                  )
                }
              )
            }

            // Row 2: Music & Effects
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
              HomeToolCard(
                tile = HOME_TILES[2],
                modifier = Modifier.weight(1f),
                onClick = onNavigateToMusicStudio
              )
              HomeToolCard(
                tile = HOME_TILES[3],
                modifier = Modifier.weight(1f),
                onClick = onNavigateToEffectsStudio
              )
            }

            // Row 3: Text & Stickers
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
              HomeToolCard(
                tile = HOME_TILES[4],
                modifier = Modifier.weight(1f),
                onClick = onNavigateToTextStudio
              )
              HomeToolCard(
                tile = HOME_TILES[5],
                modifier = Modifier.weight(1f),
                onClick = onNavigateToStickersStudio
              )
            }

            // Row 4: My Projects & Settings
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
              HomeToolCard(
                tile = HOME_TILES[6],
                modifier = Modifier.weight(1f),
                badge = if (projects.isNotEmpty()) "${projects.size}" else null,
                onClick = onNavigateToMyProjects
              )
              HomeToolCard(
                tile = HOME_TILES[7],
                modifier = Modifier.weight(1f),
                onClick = onNavigateToSettings
              )
            }
          }
        }

        // --- My Projects Section (Room Database) ---
        item {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(start = 16.dp, end = 16.dp, top = 22.dp, bottom = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Text(
                text = "MY PROJECTS",
                color = ZvWhite,
                fontSize = 14.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 1.sp
              )
              if (projects.isNotEmpty()) {
                Spacer(modifier = Modifier.width(8.dp))
                Box(
                  modifier = Modifier
                    .clip(CircleShape)
                    .background(ZvOrangePrimary)
                    .padding(horizontal = 7.dp, vertical = 2.dp)
                ) {
                  Text(
                    text = "${projects.size}",
                    color = ZvWhite,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                  )
                }
              }
            }

            Text(
              text = "View All →",
              color = ZvOrangeBright,
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold,
              modifier = Modifier
                .clickable { onNavigateToMyProjects() }
                .padding(vertical = 4.dp)
            )
          }
        }

        if (projects.isEmpty()) {
          item {
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(ZvBlackCard)
                .border(1.dp, Color(0x22FF6A00), RoundedCornerShape(14.dp))
                .padding(20.dp),
              contentAlignment = Alignment.Center
            ) {
              Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                  imageVector = Icons.Default.Folder,
                  contentDescription = null,
                  tint = Color(0x66FF6A00),
                  modifier = Modifier.size(36.dp)
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                  text = "No Saved Projects Yet",
                  color = ZvWhite,
                  fontSize = 13.5.sp,
                  fontWeight = FontWeight.Bold
                )
                Text(
                  text = "Click 'Video Editor' or '+ New Project' above to create your first video!",
                  color = ZvTextMuted,
                  fontSize = 11.sp,
                  textAlign = TextAlign.Center
                )
              }
            }
          }
        } else {
          item {
            LazyRow(
              modifier = Modifier.fillMaxWidth(),
              contentPadding = PaddingValues(horizontal = 14.dp),
              horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
              items(projects.take(6)) { project ->
                RecentProjectMiniCard(
                  project = project,
                  onClick = { onOpenProject(project) }
                )
              }
            }
          }
        }
      }

      // Bottom Right Floating New Project Action Button
      FloatingActionButton(
        onClick = {
          videoPickerLauncher.launch(
            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo)
          )
        },
        containerColor = ZvOrangePrimary,
        contentColor = ZvWhite,
        shape = CircleShape,
        modifier = Modifier
          .align(Alignment.BottomEnd)
          .padding(20.dp)
          .shadow(8.dp, CircleShape, spotColor = ZvOrangePrimary)
          .testTag("fab_new_project")
      ) {
        Icon(Icons.Default.Add, contentDescription = "Create New Project", modifier = Modifier.size(28.dp))
      }
    }
  }
}

/**
 * Individual High-Polished Tool Card
 */
@Composable
fun HomeToolCard(
  tile: HomeTileItem,
  modifier: Modifier = Modifier,
  badge: String? = null,
  onClick: () -> Unit
) {
  Box(
    modifier = modifier
      .height(88.dp)
      .shadow(4.dp, RoundedCornerShape(14.dp))
      .clip(RoundedCornerShape(14.dp))
      .background(ZvBlackCard)
      .border(1.2.dp, Color(0x33FF6A00), RoundedCornerShape(14.dp))
      .clickable { onClick() }
      .padding(12.dp)
      .testTag("tile_${tile.id}")
  ) {
    Column(
      modifier = Modifier.fillMaxSize(),
      verticalArrangement = Arrangement.SpaceBetween
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Top
      ) {
        Box(
          modifier = Modifier
            .size(34.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0x33FF6A00)),
          contentAlignment = Alignment.Center
        ) {
          Text(text = tile.emoji, fontSize = 18.sp)
        }

        if (badge != null) {
          Box(
            modifier = Modifier
              .clip(CircleShape)
              .background(ZvOrangePrimary)
              .padding(horizontal = 6.dp, vertical = 2.dp)
          ) {
            Text(badge, color = ZvWhite, fontSize = 10.sp, fontWeight = FontWeight.Bold)
          }
        } else {
          Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
            contentDescription = null,
            tint = Color(0x66FF6A00),
            modifier = Modifier.size(14.dp)
          )
        }
      }

      Column {
        Text(
          text = tile.title,
          color = ZvWhite,
          fontSize = 13.sp,
          fontWeight = FontWeight.Bold,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
        )
        Text(
          text = tile.subtitle,
          color = ZvTextMuted,
          fontSize = 10.sp,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
        )
      }
    }
  }
}

/**
 * Recent Project Mini Horizontal Card
 */
@Composable
fun RecentProjectMiniCard(
  project: ProjectEntity,
  onClick: () -> Unit
) {
  val dateFormatted = remember(project.lastModifiedTimestamp) {
    SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(project.lastModifiedTimestamp))
  }

  Box(
    modifier = Modifier
      .width(140.dp)
      .clip(RoundedCornerShape(12.dp))
      .background(ZvBlackSurface)
      .border(1.dp, Color(0x33FF6A00), RoundedCornerShape(12.dp))
      .clickable { onClick() }
      .testTag("recent_project_${project.id}")
  ) {
    Column {
      // Media Thumbnail preview
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(84.dp)
          .background(Color(0xFF18181B))
      ) {
        if (project.mediaUri.isNotBlank()) {
          AsyncImage(
            model = project.mediaUri,
            contentDescription = project.title,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
          )
        } else {
          Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Icon(
              imageVector = if (project.type == "VIDEO") Icons.Default.VideoLibrary else Icons.Default.Image,
              contentDescription = null,
              tint = ZvOrangePrimary,
              modifier = Modifier.size(28.dp)
            )
          }
        }

        // Duration / Aspect ratio badge
        Box(
          modifier = Modifier
            .align(Alignment.BottomEnd)
            .padding(4.dp)
            .clip(RoundedCornerShape(4.dp))
            .background(Color(0xCC000000))
            .padding(horizontal = 4.dp, vertical = 2.dp)
        ) {
          Text(
            text = "${project.aspectRatio} • ${project.durationSeconds.toInt()}s",
            color = ZvWhite,
            fontSize = 8.5.sp,
            fontWeight = FontWeight.Bold
          )
        }
      }

      // Title & Date
      Column(modifier = Modifier.padding(8.dp)) {
        Text(
          text = project.title,
          color = ZvWhite,
          fontSize = 12.sp,
          fontWeight = FontWeight.Bold,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
        )
        Text(
          text = dateFormatted,
          color = ZvTextMuted,
          fontSize = 9.sp,
          maxLines = 1
        )
      }
    }
  }
}
