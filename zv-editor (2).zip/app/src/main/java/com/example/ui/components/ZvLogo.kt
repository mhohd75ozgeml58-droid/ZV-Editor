package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ZvBlack
import com.example.ui.theme.ZvOrangeBright
import com.example.ui.theme.ZvOrangeDeep
import com.example.ui.theme.ZvOrangePrimary
import com.example.ui.theme.ZvTextSecondary
import com.example.ui.theme.ZvWhite

/**
 * The iconic ZV Logo Badge:
 * Orange rounded-corner badge featuring film strip sprockets on the left edge,
 * bold "ZV" lettering, and scissors cutting across the base.
 */
@Composable
fun ZvLogoBadge(
  modifier: Modifier = Modifier,
  size: Dp = 68.dp,
  pulsingGlow: Boolean = false
) {
  val infiniteTransition = rememberInfiniteTransition(label = "badge_pulse")
  val glowAlpha by if (pulsingGlow) {
    infiniteTransition.animateFloat(
      initialValue = 0.3f,
      targetValue = 0.85f,
      animationSpec = infiniteRepeatable(
        animation = tween(1200, easing = FastOutSlowInEasing),
        repeatMode = RepeatMode.Reverse
      ),
      label = "glow_alpha"
    )
  } else {
    androidx.compose.runtime.remember { androidx.compose.runtime.mutableFloatStateOf(0.4f) }
  }

  Box(
    modifier = modifier
      .size(size)
      .shadow(
        elevation = 16.dp,
        shape = RoundedCornerShape(16.dp),
        ambientColor = ZvOrangePrimary,
        spotColor = ZvOrangePrimary
      )
      .clip(RoundedCornerShape(16.dp))
      .background(
        Brush.linearGradient(
          colors = listOf(
            Color(0xFFFF7A00),
            Color(0xFFFF5200),
            Color(0xFFE04000)
          ),
          start = Offset(0f, 0f),
          end = Offset(100f, 100f)
        )
      )
      .border(
        width = 1.5.dp,
        brush = Brush.verticalGradient(
          colors = listOf(
            Color(0xFFFFB366).copy(alpha = glowAlpha),
            Color(0xFFFF5500).copy(alpha = 0.7f)
          )
        ),
        shape = RoundedCornerShape(16.dp)
      ),
    contentAlignment = Alignment.Center
  ) {
    // Custom Canvas to draw film sprocket holes and scissor/ZV badge details
    Canvas(modifier = Modifier.fillMaxSize().padding(horizontal = 7.dp, vertical = 6.dp)) {
      val w = this.size.width
      val h = this.size.height

      // Film reel left-side sprocket notches
      val sprocketH = h * 0.12f
      val sprocketW = w * 0.10f
      val numSprockets = 4
      val spacing = (h - (numSprockets * sprocketH)) / (numSprockets + 1)

      for (i in 0 until numSprockets) {
        val y = spacing + i * (sprocketH + spacing)
        drawRoundRect(
          color = Color.White.copy(alpha = 0.95f),
          topLeft = Offset(0f, y),
          size = Size(sprocketW, sprocketH),
          cornerRadius = CornerRadius(4f, 4f)
        )
      }

      // Divider line next to sprockets
      drawLine(
        color = Color.White.copy(alpha = 0.6f),
        start = Offset(sprocketW + 5f, 4f),
        end = Offset(sprocketW + 5f, h - 4f),
        strokeWidth = 2.5f,
        cap = StrokeCap.Round
      )
    }

    // Centered ZV and Scissor element
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(start = 14.dp, end = 4.dp, top = 2.dp, bottom = 4.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center
    ) {
      Text(
        text = "ZV",
        fontSize = (size.value * 0.42f).sp,
        fontWeight = FontWeight.Black,
        color = Color.White,
        letterSpacing = 1.sp,
        fontFamily = FontFamily.SansSerif
      )

      Icon(
        imageVector = Icons.Default.ContentCut,
        contentDescription = null,
        tint = Color.White,
        modifier = Modifier
          .size((size.value * 0.28f).dp)
          .padding(top = 1.dp)
      )
    }
  }
}

/**
 * The large stylized "ZV" brand wordmark:
 * 'Z' in vibrant orange gradient, 'V' in crisp white.
 */
@Composable
fun ZvWordmark(
  modifier: Modifier = Modifier,
  fontSize: Float = 44f
) {
  Row(
    modifier = modifier,
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.Center
  ) {
    Text(
      text = "Z",
      fontSize = fontSize.sp,
      fontWeight = FontWeight.Black,
      color = ZvOrangePrimary,
      letterSpacing = (-1).sp
    )
    Spacer(modifier = Modifier.width(2.dp))
    Text(
      text = "V",
      fontSize = fontSize.sp,
      fontWeight = FontWeight.Black,
      color = ZvWhite,
      letterSpacing = (-1).sp
    )
  }
}

/**
 * Tagline: "Simple • Smart • Super Editing"
 */
@Composable
fun ZvTagline(
  modifier: Modifier = Modifier,
  fontSize: Float = 14f
) {
  Row(
    modifier = modifier,
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.Center
  ) {
    Text(
      text = "Simple",
      fontSize = fontSize.sp,
      fontWeight = FontWeight.Medium,
      color = ZvWhite
    )
    Box(
      modifier = Modifier
        .padding(horizontal = 6.dp)
        .size(4.dp)
        .clip(CircleShape)
        .background(ZvOrangePrimary)
    )
    Text(
      text = "Smart",
      fontSize = fontSize.sp,
      fontWeight = FontWeight.Medium,
      color = ZvWhite
    )
    Box(
      modifier = Modifier
        .padding(horizontal = 6.dp)
        .size(4.dp)
        .clip(CircleShape)
        .background(ZvOrangePrimary)
    )
    Text(
      text = "Super Editing",
      fontSize = fontSize.sp,
      fontWeight = FontWeight.Medium,
      color = ZvWhite
    )
  }
}

/**
 * Full Brand Header with Badge, Wordmark, and Tagline.
 */
@Composable
fun ZvBrandHeader(
  modifier: Modifier = Modifier,
  badgeSize: Dp = 64.dp,
  wordmarkSize: Float = 38f,
  taglineSize: Float = 13.5f,
  pulsingGlow: Boolean = false
) {
  Column(
    modifier = modifier,
    horizontalAlignment = Alignment.CenterHorizontally
  ) {
    ZvLogoBadge(
      size = badgeSize,
      pulsingGlow = pulsingGlow
    )
    Spacer(modifier = Modifier.height(6.dp))
    ZvWordmark(fontSize = wordmarkSize)
    Spacer(modifier = Modifier.height(2.dp))
    ZvTagline(fontSize = taglineSize)
  }
}
