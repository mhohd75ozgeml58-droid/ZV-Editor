package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.FastRewind
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Upload
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.RangeSlider
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.R
import com.example.ui.components.GlowBackground
import com.example.ui.components.ZvLogoBadge
import com.example.ui.components.ZvWordmark
import com.example.ui.theme.ZvBlack
import com.example.ui.theme.ZvBlackCard
import com.example.ui.theme.ZvBlackSurface
import com.example.ui.theme.ZvOrangeBright
import com.example.ui.theme.ZvOrangeDeep
import com.example.ui.theme.ZvOrangePrimary
import com.example.ui.theme.ZvTextMuted
import com.example.ui.theme.ZvTextSecondary
import com.example.ui.theme.ZvWhite
import kotlinx.coroutines.delay

enum class StudioTool {
  TRIM,
  EFFECTS,
  MUSIC,
  SHARE
}

data class EffectFilter(
  val id: String,
  val name: String,
  val tintColor: Color,
  val overlayAlpha: Float,
  val description: String
)

data class MusicTrack(
  val title: String,
  val artist: String,
  val duration: String,
  val bpm: String
)

/**
 * ZV Studio Screen:
 * Accessible directly by clicking "Next →" from the Welcome Screen.
 * Provides the four promised creative tools:
 * 1. Cut & Trim (Trim slider, split, speed control)
 * 2. Amazing Effects (Live color filters & glow overlays)
 * 3. Add Music (Soundtrack selector, volume, visualizer)
 * 4. Easy Share (Export resolutions, social presets)
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudioScreen(
  onBackToWelcome: () -> Unit,
  modifier: Modifier = Modifier
) {
  var activeTool by remember { mutableStateOf(StudioTool.TRIM) }
  var isPlaying by remember { mutableStateOf(false) }
  var playbackPosition by remember { mutableFloatStateOf(0.18f) }
  var userMediaUri by remember { mutableStateOf<Uri?>(null) }
  var showExportSuccessDialog by remember { mutableStateOf(false) }
  var isExporting by remember { mutableStateOf(false) }

  // Cut & Trim parameters
  var trimRange by remember { mutableStateOf(0.1f..0.9f) }
  var videoSpeed by remember { mutableFloatStateOf(1.0f) }

  // Effects parameters
  val filterList = remember {
    listOf(
      EffectFilter("normal", "Original", Color.Transparent, 0f, "Natural raw profile"),
      EffectFilter("neon_orange", "ZV Neon", ZvOrangePrimary, 0.28f, "Signature high-energy orange glow"),
      EffectFilter("cinematic", "Cinematic", Color(0xFF0091EA), 0.22f, "Teal & orange block-buster LUT"),
      EffectFilter("sunset", "Warm Sunset", Color(0xFFFF3D00), 0.32f, "Golden hour radiance"),
      EffectFilter("cyberpunk", "Cyber Magenta", Color(0xFFE040FB), 0.25f, "Tokyo night neon vibes"),
      EffectFilter("noir", "Noir Classic", Color(0xFF101010), 0.50f, "Deep contrast monochrome")
    )
  }
  var selectedFilter by remember { mutableStateOf(filterList[1]) }
  var effectIntensity by remember { mutableFloatStateOf(0.75f) }

  // Music parameters
  val musicTracks = remember {
    listOf(
      MusicTrack("Neon Horizon", "ZV Audio Lab", "02:45", "124 BPM"),
      MusicTrack("Sunset Beats", "Lo-Fi Collective", "01:58", "88 BPM"),
      MusicTrack("Cyber Pulse", "Synthwave Club", "03:12", "130 BPM"),
      MusicTrack("Acoustic Story", "Studio Acoustics", "02:20", "96 BPM")
    )
  }
  var selectedTrack by remember { mutableStateOf(musicTracks[0]) }
  var musicVolume by remember { mutableFloatStateOf(0.85f) }

  // Media Picker
  val photoPickerLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.PickVisualMedia()
  ) { uri: Uri? ->
    if (uri != null) {
      userMediaUri = uri
    }
  }

  // Simulated video playback timer
  LaunchedEffect(isPlaying) {
    while (isPlaying) {
      delay(80)
      playbackPosition += (0.015f * videoSpeed)
      if (playbackPosition > trimRange.endInclusive) {
        playbackPosition = trimRange.start
      }
    }
  }

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(ZvBlack)
      .testTag("studio_screen")
  ) {
    GlowBackground(animated = false)

    // Outer Orange Border Frame matching brand identity
    Box(
      modifier = Modifier
        .fillMaxSize()
        .statusBarsPadding()
        .navigationBarsPadding()
        .padding(8.dp)
        .border(
          width = 2.dp,
          brush = Brush.verticalGradient(
            colors = listOf(
              Color(0xFFFF7A00),
              Color(0xFFFF5200),
              Color(0xFFFF8800)
            )
          ),
          shape = RoundedCornerShape(22.dp)
        )
        .clip(RoundedCornerShape(22.dp))
        .background(Color(0xFF0A0A0C))
    ) {
      Column(
        modifier = Modifier
          .fillMaxSize()
          .padding(horizontal = 14.dp, vertical = 12.dp)
      ) {
        // --- Top Bar: Back Button, ZV Branding, Export CTA ---
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 8.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          // Back to Welcome Screen
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
              .clip(RoundedCornerShape(20.dp))
              .clickable { onBackToWelcome() }
              .background(Color(0x331F1F24))
              .border(1.dp, Color(0x44FF6A00), RoundedCornerShape(20.dp))
              .padding(horizontal = 10.dp, vertical = 6.dp)
              .testTag("back_to_welcome_button")
          ) {
            Icon(
              imageVector = Icons.AutoMirrored.Filled.ArrowBack,
              contentDescription = "Back",
              tint = ZvOrangePrimary,
              modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = "Welcome",
              color = ZvWhite,
              fontSize = 12.5.sp,
              fontWeight = FontWeight.Bold
            )
          }

          // Center ZV Badge + Wordmark
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            ZvLogoBadge(size = 32.dp)
            ZvWordmark(fontSize = 22f)
          }

          // Export / Share Pill
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(20.dp))
              .background(
                Brush.horizontalGradient(
                  listOf(Color(0xFFFF7A00), Color(0xFFFF4500))
                )
              )
              .clickable {
                isExporting = true
              }
              .padding(horizontal = 12.dp, vertical = 6.dp)
              .testTag("export_button")
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
              Icon(
                imageVector = Icons.Default.Download,
                contentDescription = "Export",
                tint = ZvWhite,
                modifier = Modifier.size(15.dp)
              )
              Text(
                text = "Export",
                color = ZvWhite,
                fontSize = 12.5.sp,
                fontWeight = FontWeight.Bold
              )
            }
          }
        }

        // --- Video Preview Player Canvas ---
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .weight(1f)
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFF000000))
            .border(1.5.dp, ZvOrangePrimary.copy(alpha = 0.7f), RoundedCornerShape(16.dp))
            .testTag("video_preview_container"),
          contentAlignment = Alignment.Center
        ) {
          // Media Display with live filter tint
          Box(modifier = Modifier.fillMaxSize()) {
            if (userMediaUri != null) {
              AsyncImage(
                model = userMediaUri,
                contentDescription = "Editing Canvas",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
              )
            } else {
              Image(
                painter = painterResource(id = R.drawable.sample_portrait),
                contentDescription = "Sample Editing Canvas",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
              )
            }

            // Real-time filter tint overlay
            if (selectedFilter.tintColor != Color.Transparent) {
              Box(
                modifier = Modifier
                  .fillMaxSize()
                  .background(
                    selectedFilter.tintColor.copy(
                      alpha = selectedFilter.overlayAlpha * effectIntensity
                    )
                  )
              )
            }

            // Top Overlay: Camera Picker Button & Active Tool Label
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Box(
                modifier = Modifier
                  .clip(RoundedCornerShape(14.dp))
                  .background(Color(0x99000000))
                  .border(1.dp, ZvOrangePrimary.copy(alpha = 0.5f), RoundedCornerShape(14.dp))
                  .clickable {
                    photoPickerLauncher.launch(
                      PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                    )
                  }
                  .padding(horizontal = 10.dp, vertical = 5.dp)
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(
                    imageVector = Icons.Default.PhotoCamera,
                    contentDescription = "Pick Media",
                    tint = ZvOrangeBright,
                    modifier = Modifier.size(14.dp)
                  )
                  Spacer(modifier = Modifier.width(6.dp))
                  Text(
                    text = if (userMediaUri != null) "Change Photo" else "Pick Photo/Video",
                    color = ZvWhite,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium
                  )
                }
              }

              // Active Filter Indicator
              Box(
                modifier = Modifier
                  .clip(RoundedCornerShape(14.dp))
                  .background(Color(0x99000000))
                  .padding(horizontal = 8.dp, vertical = 4.dp)
              ) {
                Text(
                  text = "FX: ${selectedFilter.name}",
                  color = ZvOrangeBright,
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold
                )
              }
            }

            // Play / Pause Floating Center Overlay
            IconButton(
              onClick = { isPlaying = !isPlaying },
              modifier = Modifier
                .align(Alignment.Center)
                .size(54.dp)
                .clip(CircleShape)
                .background(Color(0x88000000))
                .border(2.dp, ZvOrangePrimary, CircleShape)
                .testTag("play_pause_button")
            ) {
              Icon(
                imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                contentDescription = if (isPlaying) "Pause" else "Play",
                tint = ZvWhite,
                modifier = Modifier.size(32.dp)
              )
            }

            // Bottom Scrubber Bar Overlay
            Box(
              modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .background(
                  Brush.verticalGradient(
                    listOf(Color.Transparent, Color(0xCC000000))
                  )
                )
                .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
              Column {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween
                ) {
                  Text(
                    text = String.format("00:%02d", (playbackPosition * 30).toInt()),
                    color = ZvWhite,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold
                  )
                  Text(
                    text = "00:30 • 4K 60FPS",
                    color = ZvTextMuted,
                    fontSize = 11.sp
                  )
                }
                Slider(
                  value = playbackPosition,
                  onValueChange = {
                    playbackPosition = it
                    isPlaying = false
                  },
                  colors = SliderDefaults.colors(
                    thumbColor = ZvOrangePrimary,
                    activeTrackColor = ZvOrangeBright,
                    inactiveTrackColor = Color(0x44444444)
                  ),
                  modifier = Modifier.height(24.dp)
                )
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // --- Tool Tabs: The 4 Core Features from Welcome Screen ---
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(ZvBlackSurface)
            .border(1.dp, Color(0x33FF6A00), RoundedCornerShape(14.dp))
            .padding(4.dp),
          horizontalArrangement = Arrangement.SpaceEvenly
        ) {
          StudioToolTab(
            title = "Cut & Trim",
            icon = Icons.Default.ContentCut,
            isSelected = activeTool == StudioTool.TRIM,
            onClick = { activeTool = StudioTool.TRIM },
            modifier = Modifier.weight(1f)
          )
          StudioToolTab(
            title = "Effects",
            icon = Icons.Default.AutoAwesome,
            isSelected = activeTool == StudioTool.EFFECTS,
            onClick = { activeTool = StudioTool.EFFECTS },
            modifier = Modifier.weight(1f)
          )
          StudioToolTab(
            title = "Music",
            icon = Icons.Default.MusicNote,
            isSelected = activeTool == StudioTool.MUSIC,
            onClick = { activeTool = StudioTool.MUSIC },
            modifier = Modifier.weight(1f)
          )
          StudioToolTab(
            title = "Share",
            icon = Icons.Default.Upload,
            isSelected = activeTool == StudioTool.SHARE,
            onClick = { activeTool = StudioTool.SHARE },
            modifier = Modifier.weight(1f)
          )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // --- Active Tool Control Panel ---
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .height(140.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(ZvBlackCard)
            .border(1.dp, Color(0x44FF6A00), RoundedCornerShape(16.dp))
            .padding(12.dp)
        ) {
          when (activeTool) {
            StudioTool.TRIM -> {
              TrimToolPanel(
                trimRange = trimRange,
                onTrimRangeChange = { trimRange = it },
                speed = videoSpeed,
                onSpeedChange = { videoSpeed = it }
              )
            }
            StudioTool.EFFECTS -> {
              EffectsToolPanel(
                filters = filterList,
                selectedFilter = selectedFilter,
                onSelectFilter = { selectedFilter = it },
                intensity = effectIntensity,
                onIntensityChange = { effectIntensity = it }
              )
            }
            StudioTool.MUSIC -> {
              MusicToolPanel(
                tracks = musicTracks,
                selectedTrack = selectedTrack,
                onSelectTrack = { selectedTrack = it },
                volume = musicVolume,
                onVolumeChange = { musicVolume = it }
              )
            }
            StudioTool.SHARE -> {
              ShareToolPanel(
                onTriggerExport = { isExporting = true }
              )
            }
          }
        }
      }
    }

    // Export progress sheet
    if (isExporting) {
      ExportingDialog(
        onDismiss = { isExporting = false },
        onComplete = {
          isExporting = false
          showExportSuccessDialog = true
        }
      )
    }

    if (showExportSuccessDialog) {
      AlertDialog(
        onDismissRequest = { showExportSuccessDialog = false },
        containerColor = ZvBlackSurface,
        shape = RoundedCornerShape(22.dp),
        icon = {
          Box(
            modifier = Modifier
              .size(54.dp)
              .clip(CircleShape)
              .background(Color(0x3300E676))
              .border(2.dp, Color(0xFF00E676), CircleShape),
            contentAlignment = Alignment.Center
          ) {
            Icon(Icons.Default.Check, contentDescription = null, tint = Color(0xFF00E676), modifier = Modifier.size(30.dp))
          }
        },
        title = {
          Text("Export Complete!", color = ZvWhite, fontWeight = FontWeight.Bold, fontSize = 20.sp, textAlign = TextAlign.Center)
        },
        text = {
          Text(
            "Your story has been rendered in Ultra HD with ZV effects and is saved to your gallery.",
            color = ZvTextSecondary,
            fontSize = 13.5.sp,
            textAlign = TextAlign.Center
          )
        },
        confirmButton = {
          Button(
            onClick = { showExportSuccessDialog = false },
            colors = ButtonDefaults.buttonColors(containerColor = ZvOrangePrimary),
            shape = RoundedCornerShape(16.dp)
          ) {
            Text("Done", color = ZvWhite, fontWeight = FontWeight.Bold)
          }
        }
      )
    }
  }
}

@Composable
private fun StudioToolTab(
  title: String,
  icon: ImageVector,
  isSelected: Boolean,
  onClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  val backgroundColor = if (isSelected) ZvOrangePrimary else Color.Transparent
  val contentColor = if (isSelected) ZvWhite else ZvTextMuted

  Box(
    modifier = modifier
      .clip(RoundedCornerShape(10.dp))
      .background(backgroundColor)
      .clickable { onClick() }
      .padding(vertical = 8.dp),
    contentAlignment = Alignment.Center
  ) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
      Icon(
        imageVector = icon,
        contentDescription = title,
        tint = contentColor,
        modifier = Modifier.size(18.dp)
      )
      Spacer(modifier = Modifier.height(3.dp))
      Text(
        text = title,
        color = contentColor,
        fontSize = 10.5.sp,
        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
      )
    }
  }
}

@Composable
private fun TrimToolPanel(
  trimRange: ClosedFloatingPointRange<Float>,
  onTrimRangeChange: (ClosedFloatingPointRange<Float>) -> Unit,
  speed: Float,
  onSpeedChange: (Float) -> Unit
) {
  Column(
    modifier = Modifier.fillMaxSize(),
    verticalArrangement = Arrangement.SpaceBetween
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        text = "Trim Timeline (In/Out Points)",
        color = ZvWhite,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold
      )
      Text(
        text = "${((trimRange.endInclusive - trimRange.start) * 30).toInt()}s duration",
        color = ZvOrangeBright,
        fontSize = 11.sp,
        fontWeight = FontWeight.SemiBold
      )
    }

    RangeSlider(
      value = trimRange,
      onValueChange = onTrimRangeChange,
      colors = SliderDefaults.colors(
        thumbColor = ZvOrangePrimary,
        activeTrackColor = ZvOrangeBright,
        inactiveTrackColor = Color(0x33444444)
      ),
      modifier = Modifier.height(24.dp)
    )

    // Speed Controls
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.Speed, contentDescription = null, tint = ZvOrangeBright, modifier = Modifier.size(15.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text("Playback Speed", color = ZvTextSecondary, fontSize = 11.5.sp)
      }

      Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        listOf(0.5f, 1.0f, 1.5f, 2.0f).forEach { s ->
          val isSelected = speed == s
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(8.dp))
              .background(if (isSelected) ZvOrangePrimary else Color(0x332E1A0E))
              .border(1.dp, if (isSelected) ZvOrangeBright else Color(0x22FFFFFF), RoundedCornerShape(8.dp))
              .clickable { onSpeedChange(s) }
              .padding(horizontal = 8.dp, vertical = 3.dp)
          ) {
            Text(
              text = "${s}x",
              color = if (isSelected) ZvWhite else ZvTextMuted,
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold
            )
          }
        }
      }
    }
  }
}

@Composable
private fun EffectsToolPanel(
  filters: List<EffectFilter>,
  selectedFilter: EffectFilter,
  onSelectFilter: (EffectFilter) -> Unit,
  intensity: Float,
  onIntensityChange: (Float) -> Unit
) {
  Column(
    modifier = Modifier.fillMaxSize(),
    verticalArrangement = Arrangement.SpaceBetween
  ) {
    LazyRow(
      horizontalArrangement = Arrangement.spacedBy(8.dp),
      modifier = Modifier.fillMaxWidth()
    ) {
      items(filters) { filter ->
        val isSelected = filter.id == selectedFilter.id
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(if (isSelected) ZvOrangePrimary else Color(0x331F1F24))
            .border(
              1.dp,
              if (isSelected) ZvOrangeBright else Color(0x33FF6A00),
              RoundedCornerShape(10.dp)
            )
            .clickable { onSelectFilter(filter) }
            .padding(horizontal = 10.dp, vertical = 6.dp)
        ) {
          Text(
            text = filter.name,
            color = if (isSelected) ZvWhite else ZvTextSecondary,
            fontSize = 11.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
          )
        }
      }
    }

    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        text = "Filter Intensity",
        color = ZvWhite,
        fontSize = 11.5.sp,
        fontWeight = FontWeight.Medium
      )
      Text(
        text = "${(intensity * 100).toInt()}%",
        color = ZvOrangeBright,
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold
      )
    }

    Slider(
      value = intensity,
      onValueChange = onIntensityChange,
      colors = SliderDefaults.colors(
        thumbColor = ZvOrangePrimary,
        activeTrackColor = ZvOrangeBright,
        inactiveTrackColor = Color(0x33444444)
      ),
      modifier = Modifier.height(24.dp)
    )
  }
}

@Composable
private fun MusicToolPanel(
  tracks: List<MusicTrack>,
  selectedTrack: MusicTrack,
  onSelectTrack: (MusicTrack) -> Unit,
  volume: Float,
  onVolumeChange: (Float) -> Unit
) {
  Column(
    modifier = Modifier.fillMaxSize(),
    verticalArrangement = Arrangement.SpaceBetween
  ) {
    LazyRow(
      horizontalArrangement = Arrangement.spacedBy(8.dp),
      modifier = Modifier.fillMaxWidth()
    ) {
      items(tracks) { track ->
        val isSelected = track.title == selectedTrack.title
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(if (isSelected) ZvOrangePrimary else Color(0x331F1F24))
            .border(1.dp, if (isSelected) ZvOrangeBright else Color(0x33FF6A00), RoundedCornerShape(10.dp))
            .clickable { onSelectTrack(track) }
            .padding(horizontal = 10.dp, vertical = 5.dp)
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              Icons.Default.GraphicEq,
              contentDescription = null,
              tint = if (isSelected) ZvWhite else ZvOrangeBright,
              modifier = Modifier.size(13.dp)
            )
            Spacer(modifier = Modifier.width(5.dp))
            Text(
              text = track.title,
              color = if (isSelected) ZvWhite else ZvTextSecondary,
              fontSize = 11.sp,
              fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
            )
          }
        }
      }
    }

    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.VolumeUp, contentDescription = null, tint = ZvOrangeBright, modifier = Modifier.size(15.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text("Soundtrack Volume", color = ZvWhite, fontSize = 11.5.sp)
      }
      Text(
        text = "${(volume * 100).toInt()}%",
        color = ZvOrangeBright,
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold
      )
    }

    Slider(
      value = volume,
      onValueChange = onVolumeChange,
      colors = SliderDefaults.colors(
        thumbColor = ZvOrangePrimary,
        activeTrackColor = ZvOrangeBright,
        inactiveTrackColor = Color(0x33444444)
      ),
      modifier = Modifier.height(24.dp)
    )
  }
}

@Composable
private fun ShareToolPanel(
  onTriggerExport: () -> Unit
) {
  Row(
    modifier = Modifier.fillMaxSize(),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically
  ) {
    Column(modifier = Modifier.weight(1f)) {
      Text(
        text = "Export Preset",
        color = ZvWhite,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold
      )
      Spacer(modifier = Modifier.height(2.dp))
      Text(
        text = "4K 60FPS • H.265 HDR • 9:16 Vertical Reel format",
        color = ZvTextSecondary,
        fontSize = 11.sp,
        lineHeight = 14.sp
      )
    }

    Button(
      onClick = onTriggerExport,
      colors = ButtonDefaults.buttonColors(containerColor = ZvOrangePrimary),
      shape = RoundedCornerShape(12.dp),
      modifier = Modifier.testTag("quick_render_button")
    ) {
      Icon(Icons.Default.Upload, contentDescription = null, tint = ZvWhite, modifier = Modifier.size(16.dp))
      Spacer(modifier = Modifier.width(6.dp))
      Text("Render Story", color = ZvWhite, fontWeight = FontWeight.Bold, fontSize = 12.sp)
    }
  }
}

@Composable
fun ExportingDialog(
  onDismiss: () -> Unit,
  onComplete: () -> Unit
) {
  var progress by remember { mutableFloatStateOf(0f) }

  LaunchedEffect(Unit) {
    while (progress < 1f) {
      delay(70)
      progress += 0.05f
    }
    delay(200)
    onComplete()
  }

  AlertDialog(
    onDismissRequest = onDismiss,
    containerColor = ZvBlackSurface,
    shape = RoundedCornerShape(20.dp),
    icon = {
      Box(
        modifier = Modifier
          .size(54.dp)
          .clip(CircleShape)
          .background(Color(0x33FF6A00))
          .border(1.5.dp, ZvOrangePrimary, CircleShape),
        contentAlignment = Alignment.Center
      ) {
        Icon(Icons.Default.Download, contentDescription = null, tint = ZvOrangePrimary, modifier = Modifier.size(28.dp))
      }
    },
    title = {
      Text("Rendering ZV Video...", color = ZvWhite, fontSize = 18.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
    },
    text = {
      Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
        Text("Encoding frame-accurate 4K cuts and applying neon LUTs.", color = ZvTextSecondary, fontSize = 12.5.sp, textAlign = TextAlign.Center)
        Spacer(modifier = Modifier.height(14.dp))
        Slider(
          value = progress,
          onValueChange = {},
          colors = SliderDefaults.colors(
            thumbColor = ZvOrangePrimary,
            activeTrackColor = ZvOrangeBright,
            inactiveTrackColor = Color(0x33444444)
          ),
          modifier = Modifier.height(20.dp)
        )
        Text("${(progress * 100).toInt()}%", color = ZvOrangeBright, fontSize = 13.sp, fontWeight = FontWeight.Bold)
      }
    },
    confirmButton = {}
  )
}
