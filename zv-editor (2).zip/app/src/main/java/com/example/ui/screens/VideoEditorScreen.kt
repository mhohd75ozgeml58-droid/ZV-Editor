package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.media.MediaPlayer
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Animation
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Crop
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.FastRewind
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.Transform
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Upload
import androidx.compose.material.icons.filled.VolumeMute
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.outlined.EmojiEmotions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RangeSlider
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.db.ProjectEntity
import com.example.data.repository.ProjectRepository
import com.example.model.ActiveEditorProject
import com.example.ui.components.GlowBackground
import com.example.ui.theme.ZvBlack
import com.example.ui.theme.ZvBlackCard
import com.example.ui.theme.ZvBlackSurface
import com.example.ui.theme.ZvOrangeBright
import com.example.ui.theme.ZvOrangePrimary
import com.example.ui.theme.ZvTextMuted
import com.example.ui.theme.ZvTextSecondary
import com.example.ui.theme.ZvWhite
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/**
 * 13 Tools specified by user:
 * Cut → Trim → Split → Crop → Rotate → Speed → Volume → Filter → Effect → Transition → Text → Sticker → Music
 */
enum class EditorTool(val label: String, val icon: ImageVector) {
  CUT("Cut", Icons.Default.ContentCut),
  TRIM("Trim", Icons.Default.ContentCut),
  SPLIT("Split", Icons.Default.Transform),
  CROP("Crop", Icons.Default.Crop),
  ROTATE("Rotate", Icons.Default.RotateRight),
  SPEED("Speed", Icons.Default.Speed),
  VOLUME("Volume", Icons.Default.VolumeUp),
  FILTER("Filter", Icons.Default.AutoAwesome),
  EFFECT("Effect", Icons.Default.Tune),
  TRANSITION("Transition", Icons.Default.Animation),
  TEXT("Text", Icons.Default.TextFields),
  STICKER("Sticker", Icons.Outlined.EmojiEmotions),
  MUSIC("Music", Icons.Default.MusicNote)
}

@Composable
fun VideoEditorScreen(
  initialProject: ActiveEditorProject? = null,
  onBack: () -> Unit,
  onSavedToMyProjects: () -> Unit,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val repository = remember { ProjectRepository.getRepository(context) }
  val coroutineScope = rememberCoroutineScope()

  // Project state
  var currentProject by remember {
    mutableStateOf(
      initialProject ?: ActiveEditorProject(
        mediaUri = ActiveEditorProject.SAMPLE_VIDEOS.first()
      )
    )
  }

  var activeTool by remember { mutableStateOf(EditorTool.TRIM) }
  var isPlaying by remember { mutableStateOf(false) }
  var playbackPosition by remember { mutableFloatStateOf(0.0f) }

  // Modals & Dialogs
  var showPreviewModal by remember { mutableStateOf(false) }
  var showExportDialog by remember { mutableStateOf(false) }
  var isExporting by remember { mutableStateOf(false) }
  var exportProgress by remember { mutableFloatStateOf(0f) }
  var exportedDone by remember { mutableStateOf(false) }

  // Real-time playback loop
  LaunchedEffect(isPlaying, currentProject.speed) {
    if (isPlaying) {
      val frameInterval = 50L
      while (isPlaying) {
        delay(frameInterval)
        val step = (frameInterval / 1000f) * currentProject.speed
        if (playbackPosition + step >= currentProject.trimEndSeconds) {
          playbackPosition = currentProject.trimStartSeconds
        } else {
          playbackPosition += step
        }
      }
    }
  }

  // Audio picker launcher for Music tool
  val audioPickerLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.GetContent()
  ) { uri: Uri? ->
    if (uri != null) {
      currentProject = currentProject.copy(musicTrackName = "Device Audio (${uri.lastPathSegment?.take(10) ?: "audio"})")
      Toast.makeText(context, "Loaded audio from device!", Toast.LENGTH_SHORT).show()
    }
  }

  // Video picker for switching clip
  val videoPickerLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.PickVisualMedia()
  ) { uri: Uri? ->
    if (uri != null) {
      currentProject = currentProject.copy(mediaUri = uri.toString())
    }
  }

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(ZvBlack)
      .testTag("video_editor_screen")
  ) {
    GlowBackground(animated = false)

    // Outer Neon Orange Container
    Box(
      modifier = Modifier
        .fillMaxSize()
        .statusBarsPadding()
        .navigationBarsPadding()
        .padding(6.dp)
        .border(
          width = 2.dp,
          brush = Brush.verticalGradient(
            colors = listOf(Color(0xFFFF7A00), Color(0xFFFF5200), Color(0xFFFF8800))
          ),
          shape = RoundedCornerShape(20.dp)
        )
        .clip(RoundedCornerShape(20.dp))
        .background(Color(0xFF09090B))
    ) {
      Column(modifier = Modifier.fillMaxSize()) {
        // --- 1. Top Header: Back, Aspect Ratio, Preview, Export ---
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 8.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(
              onClick = onBack,
              modifier = Modifier
                .size(34.dp)
                .clip(CircleShape)
                .background(Color(0x331F1F24))
            ) {
              Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = "Back",
                tint = ZvOrangePrimary,
                modifier = Modifier.size(17.dp)
              )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column {
              Text(
                text = currentProject.title,
                color = ZvWhite,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.width(110.dp)
              )
              Text(
                text = "${String.format("%.1f", playbackPosition)}s / ${String.format("%.1f", currentProject.durationSeconds)}s",
                color = ZvOrangeBright,
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold
              )
            }
          }

          // Aspect Ratio Selector (9:16, 16:9, 1:1, 4:5)
          Row(
            modifier = Modifier
              .clip(RoundedCornerShape(12.dp))
              .background(ZvBlackSurface)
              .border(1.dp, Color(0x33FF6A00), RoundedCornerShape(12.dp))
              .padding(horizontal = 4.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.spacedBy(2.dp)
          ) {
            listOf("9:16", "16:9", "1:1").forEach { ratio ->
              val isSel = currentProject.aspectRatio == ratio
              Box(
                modifier = Modifier
                  .clip(RoundedCornerShape(8.dp))
                  .background(if (isSel) ZvOrangePrimary else Color.Transparent)
                  .clickable { currentProject = currentProject.copy(aspectRatio = ratio) }
                  .padding(horizontal = 6.dp, vertical = 3.dp)
              ) {
                Text(ratio, color = if (isSel) ZvWhite else ZvTextMuted, fontSize = 9.5.sp, fontWeight = FontWeight.Bold)
              }
            }
          }

          // Action Buttons: Preview & Export
          Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            // Preview button (10. Preview बिना export किए देखना)
            IconButton(
              onClick = { showPreviewModal = true },
              modifier = Modifier
                .size(34.dp)
                .clip(CircleShape)
                .background(Color(0x33FFFFFF))
            ) {
              Icon(Icons.Default.Fullscreen, contentDescription = "Preview", tint = ZvWhite, modifier = Modifier.size(18.dp))
            }

            // Export button (11. Export → 480p / 720p / 1080p)
            Button(
              onClick = { showExportDialog = true },
              colors = ButtonDefaults.buttonColors(containerColor = ZvOrangePrimary),
              shape = RoundedCornerShape(10.dp),
              contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
              modifier = Modifier.height(34.dp)
            ) {
              Icon(Icons.Default.Download, contentDescription = null, tint = ZvWhite, modifier = Modifier.size(14.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("Export", color = ZvWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
          }
        }

        // --- 2. Video Preview Area (Top) ---
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .weight(1.0f)
            .padding(horizontal = 12.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFF101012))
            .border(1.5.dp, Color(0x33FF6A00), RoundedCornerShape(16.dp)),
          contentAlignment = Alignment.Center
        ) {
          val previewAspect = remember(currentProject.aspectRatio) {
            when (currentProject.aspectRatio) {
              "9:16" -> 9f / 16f
              "16:9" -> 16f / 9f
              "1:1" -> 1f
              "4:5" -> 4f / 5f
              else -> 9f / 16f
            }
          }

          Box(
            modifier = Modifier
              .fillMaxHeight(0.96f)
              .aspectRatio(previewAspect)
              .clip(RoundedCornerShape(12.dp))
              .background(Color.Black),
            contentAlignment = Alignment.Center
          ) {
            // Filter color tint
            val filterColorFilter = remember(currentProject.filterName) {
              when (currentProject.filterName) {
                "Cyber Neon" -> ColorFilter.tint(Color(0xFF00E5FF).copy(alpha = 0.32f), BlendMode.Color)
                "Golden Hour" -> ColorFilter.tint(Color(0xFFFFB300).copy(alpha = 0.35f), BlendMode.Overlay)
                "Noir" -> ColorFilter.colorMatrix(androidx.compose.ui.graphics.ColorMatrix().apply { setToSaturation(0f) })
                "Vivid Orange" -> ColorFilter.tint(Color(0xFFFF7A00).copy(alpha = 0.35f), BlendMode.ColorBurn)
                "Cinema Teal" -> ColorFilter.tint(Color(0xFF00897B).copy(alpha = 0.30f), BlendMode.Softlight)
                "Vintage" -> ColorFilter.tint(Color(0xFF8D6E63).copy(alpha = 0.30f), BlendMode.Overlay)
                else -> null
              }
            }

            // Video / Photo Image Frame
            AsyncImage(
              model = currentProject.mediaUri,
              contentDescription = "Video Frame",
              contentScale = ContentScale.Crop,
              colorFilter = filterColorFilter,
              modifier = Modifier
                .fillMaxSize()
                .rotate(currentProject.rotationDegrees.toFloat())
            )

            // Visual Effects (Glitch / Vignette / Grain)
            if (currentProject.effectName != "None") {
              Canvas(modifier = Modifier.fillMaxSize()) {
                when (currentProject.effectName) {
                  "Vignette" -> {
                    drawRect(
                      brush = Brush.radialGradient(
                        colors = listOf(Color.Transparent, Color(0xDD000000)),
                        radius = size.width * 0.85f
                      )
                    )
                  }
                  "Glitch" -> {
                    drawRect(
                      brush = Brush.verticalGradient(
                        colors = listOf(Color(0x33FF0055), Color.Transparent, Color(0x3300FFEA))
                      )
                    )
                  }
                  "Film Grain" -> {
                    drawRect(color = Color(0x22FFFFFF))
                  }
                }
              }
            }

            // Text Overlay
            if (currentProject.textOverlay.isNotBlank()) {
              Box(
                modifier = Modifier
                  .align(
                    when {
                      currentProject.textPositionY < 0.35f -> Alignment.TopCenter
                      currentProject.textPositionY > 0.65f -> Alignment.BottomCenter
                      else -> Alignment.Center
                    }
                  )
                  .padding(14.dp)
                  .clip(RoundedCornerShape(8.dp))
                  .background(Color(0x88000000))
                  .padding(horizontal = 10.dp, vertical = 4.dp)
              ) {
                Text(
                  text = currentProject.textOverlay,
                  color = Color(currentProject.textColor),
                  fontSize = currentProject.textSize.sp,
                  fontWeight = FontWeight.Bold
                )
              }
            }

            // Sticker Overlay
            if (currentProject.stickerName.isNotBlank()) {
              Box(
                modifier = Modifier
                  .align(Alignment.Center)
                  .scale(currentProject.stickerScale)
              ) {
                Text(text = currentProject.stickerName, fontSize = 42.sp)
              }
            }

            // Playback state icon overlay on tap
            Box(
              modifier = Modifier
                .fillMaxSize()
                .clickable { isPlaying = !isPlaying },
              contentAlignment = Alignment.Center
            ) {
              if (!isPlaying) {
                Box(
                  modifier = Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(Color(0xAA000000))
                    .border(1.5.dp, ZvOrangePrimary, CircleShape),
                  contentAlignment = Alignment.Center
                ) {
                  Icon(Icons.Default.PlayArrow, contentDescription = "Play", tint = ZvOrangeBright, modifier = Modifier.size(28.dp))
                }
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // --- 3. Multi-Track Timeline & Scrubbing (Bottom Half) ---
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .height(96.dp)
            .padding(horizontal = 12.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(ZvBlackSurface)
            .border(1.2.dp, Color(0x33FF6A00), RoundedCornerShape(14.dp))
            .padding(8.dp)
        ) {
          Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
            // Timeline controls row: Rewind, Play/Pause, Forward, Timecode
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                IconButton(
                  onClick = {
                    playbackPosition = (playbackPosition - 5.0f).coerceAtLeast(currentProject.trimStartSeconds)
                  },
                  modifier = Modifier.size(26.dp)
                ) {
                  Icon(Icons.Default.FastRewind, contentDescription = "Rewind", tint = ZvWhite, modifier = Modifier.size(16.dp))
                }

                IconButton(
                  onClick = { isPlaying = !isPlaying },
                  modifier = Modifier
                    .size(30.dp)
                    .clip(CircleShape)
                    .background(ZvOrangePrimary)
                ) {
                  Icon(
                    imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                    contentDescription = "Play/Pause",
                    tint = ZvWhite,
                    modifier = Modifier.size(18.dp)
                  )
                }

                IconButton(
                  onClick = {
                    playbackPosition = (playbackPosition + 5.0f).coerceAtMost(currentProject.trimEndSeconds)
                  },
                  modifier = Modifier.size(26.dp)
                ) {
                  Icon(Icons.Default.FastForward, contentDescription = "Fast Forward", tint = ZvWhite, modifier = Modifier.size(16.dp))
                }
              }

              // Active track tags
              Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                if (currentProject.musicTrackName != "None") {
                  Box(
                    modifier = Modifier
                      .clip(RoundedCornerShape(4.dp))
                      .background(Color(0x33FF6A00))
                      .padding(horizontal = 5.dp, vertical = 1.dp)
                  ) {
                    Text("🎵 ${currentProject.musicTrackName}", color = ZvOrangeBright, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                  }
                }
                Box(
                  modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color(0x22FFFFFF))
                    .padding(horizontal = 5.dp, vertical = 1.dp)
                ) {
                  Text("${currentProject.speed}x", color = ZvWhite, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
              }
            }

            // Visual Multi-track representation with Scrubbing Playhead
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .height(44.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFF141416))
                .border(1.dp, Color(0x22FFFFFF), RoundedCornerShape(8.dp))
                .pointerInput(currentProject.durationSeconds) {
                  detectDragGestures { change, _ ->
                    val progress = (change.position.x / size.width).coerceIn(0f, 1f)
                    playbackPosition = progress * currentProject.durationSeconds
                  }
                }
            ) {
              // Video Filmstrip Track
              Row(
                modifier = Modifier
                  .fillMaxSize()
                  .padding(2.dp)
              ) {
                val segmentCount = 8
                repeat(segmentCount) { index ->
                  Box(
                    modifier = Modifier
                      .weight(1f)
                      .fillMaxHeight()
                      .border(0.5.dp, Color(0x33FFFFFF))
                      .background(if (index % 2 == 0) Color(0xFF1F1F24) else Color(0xFF18181D)),
                    contentAlignment = Alignment.Center
                  ) {
                    Text("${index * 2}s", color = Color(0x44FFFFFF), fontSize = 8.sp)
                  }
                }
              }

              // In/Out Trim Highlight
              val leftFraction = (currentProject.trimStartSeconds / currentProject.durationSeconds).coerceIn(0f, 1f)
              val rightFraction = (currentProject.trimEndSeconds / currentProject.durationSeconds).coerceIn(0f, 1f)

              Box(
                modifier = Modifier
                  .fillMaxHeight()
                  .fillMaxWidth(rightFraction - leftFraction)
                  .offset(x = (leftFraction * 320).dp) // approximate visual offset
                  .border(2.dp, ZvOrangePrimary, RoundedCornerShape(4.dp))
                  .background(Color(0x22FF6A00))
              )

              // Glowing Playhead Needle
              val playheadProgress = (playbackPosition / currentProject.durationSeconds).coerceIn(0f, 1f)
              Box(
                modifier = Modifier
                  .fillMaxHeight()
                  .width(2.5.dp)
                  .align(Alignment.CenterStart)
                  .offset(x = (playheadProgress * 320).dp)
                  .background(ZvOrangeBright)
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // --- 4. Interactive Active Tool Control Panel ---
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .height(130.dp)
            .padding(horizontal = 12.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(ZvBlackSurface)
            .border(1.dp, Color(0x33FF6A00), RoundedCornerShape(14.dp))
            .padding(10.dp)
        ) {
          when (activeTool) {
            EditorTool.TRIM -> {
              Column {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                  Text("Trim Range", color = ZvOrangeBright, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                  Text(
                    "${String.format("%.1f", currentProject.trimStartSeconds)}s - ${String.format("%.1f", currentProject.trimEndSeconds)}s",
                    color = ZvWhite,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                  )
                }
                RangeSlider(
                  value = currentProject.trimStartSeconds..currentProject.trimEndSeconds,
                  onValueChange = { range ->
                    currentProject = currentProject.copy(
                      trimStartSeconds = range.start,
                      trimEndSeconds = range.endInclusive
                    )
                  },
                  valueRange = 0f..currentProject.durationSeconds,
                  colors = SliderDefaults.colors(thumbColor = ZvOrangeBright, activeTrackColor = ZvOrangePrimary)
                )
              }
            }

            EditorTool.SPLIT -> {
              Column {
                Text("Split Clip at Current Playhead", color = ZvOrangeBright, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                  "Split marker at: ${String.format("%.1f", playbackPosition)}s",
                  color = ZvTextSecondary,
                  fontSize = 11.5.sp
                )
                Spacer(modifier = Modifier.height(10.dp))
                Button(
                  onClick = {
                    currentProject = currentProject.copy(splitPointSeconds = playbackPosition)
                    Toast.makeText(context, "Clip split at ${String.format("%.1f", playbackPosition)}s", Toast.LENGTH_SHORT).show()
                  },
                  colors = ButtonDefaults.buttonColors(containerColor = ZvOrangePrimary),
                  shape = RoundedCornerShape(10.dp)
                ) {
                  Icon(Icons.Default.Transform, contentDescription = null, tint = ZvWhite, modifier = Modifier.size(16.dp))
                  Spacer(modifier = Modifier.width(6.dp))
                  Text("Split Here", color = ZvWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
              }
            }

            EditorTool.CUT -> {
              Column {
                Text("Cut Segment", color = ZvOrangeBright, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(6.dp))
                Text("Cuts out unwanted section between start and end handles.", color = ZvTextSecondary, fontSize = 11.sp)
                Spacer(modifier = Modifier.height(10.dp))
                Button(
                  onClick = {
                    Toast.makeText(context, "Segment from 0s to ${String.format("%.1f", playbackPosition)}s cut!", Toast.LENGTH_SHORT).show()
                  },
                  colors = ButtonDefaults.buttonColors(containerColor = Color(0x33FF3D00)),
                  border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFF3D00)),
                  shape = RoundedCornerShape(10.dp)
                ) {
                  Icon(Icons.Default.ContentCut, contentDescription = null, tint = Color(0xFFFF8A80), modifier = Modifier.size(16.dp))
                  Spacer(modifier = Modifier.width(6.dp))
                  Text("Cut Selected", color = Color(0xFFFF8A80), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
              }
            }

            EditorTool.CROP -> {
              Column {
                Text("Crop Aspect Ratio", color = ZvOrangeBright, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                  listOf("9:16", "16:9", "1:1", "4:5").forEach { ratio ->
                    val isSel = currentProject.aspectRatio == ratio
                    Box(
                      modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (isSel) ZvOrangePrimary else ZvBlackCard)
                        .clickable { currentProject = currentProject.copy(aspectRatio = ratio) }
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                      Text(ratio, color = if (isSel) ZvWhite else ZvTextSecondary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                  }
                }
              }
            }

            EditorTool.ROTATE -> {
              Column {
                Text("Rotate Video", color = ZvOrangeBright, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                  Button(
                    onClick = {
                      currentProject = currentProject.copy(rotationDegrees = (currentProject.rotationDegrees + 90) % 360)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0x22FF6A00)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, ZvOrangePrimary),
                    shape = RoundedCornerShape(10.dp)
                  ) {
                    Icon(Icons.Default.RotateRight, contentDescription = null, tint = ZvOrangeBright, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("+90° (${currentProject.rotationDegrees}°)", color = ZvWhite, fontSize = 12.sp)
                  }
                  Button(
                    onClick = { currentProject = currentProject.copy(rotationDegrees = 0) },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0x22FFFFFF)),
                    shape = RoundedCornerShape(10.dp)
                  ) {
                    Text("Reset", color = ZvWhite, fontSize = 12.sp)
                  }
                }
              }
            }

            EditorTool.SPEED -> {
              Column {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                  Text("Playback Speed", color = ZvOrangeBright, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                  Text("${currentProject.speed}x", color = ZvWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                  listOf(0.25f, 0.5f, 1.0f, 1.5f, 2.0f, 3.0f).forEach { spd ->
                    val isSel = currentProject.speed == spd
                    Box(
                      modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSel) ZvOrangePrimary else ZvBlackCard)
                        .clickable { currentProject = currentProject.copy(speed = spd) }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                      Text("${spd}x", color = if (isSel) ZvWhite else ZvTextSecondary, fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                    }
                  }
                }
              }
            }

            EditorTool.VOLUME -> {
              Column {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                  Text("Audio Volume Boost", color = ZvOrangeBright, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                  Text("${(currentProject.volume * 100).toInt()}%", color = ZvWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Slider(
                  value = currentProject.volume,
                  onValueChange = { currentProject = currentProject.copy(volume = it) },
                  valueRange = 0f..2.0f,
                  colors = SliderDefaults.colors(thumbColor = ZvOrangeBright, activeTrackColor = ZvOrangePrimary)
                )
              }
            }

            EditorTool.FILTER -> {
              Column {
                Text("Color Filters", color = ZvOrangeBright, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(6.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                  items(listOf("Normal", "Cyber Neon", "Golden Hour", "Noir", "Vivid Orange", "Cinema Teal", "Vintage")) { fName ->
                    val isSel = currentProject.filterName == fName
                    Box(
                      modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (isSel) ZvOrangePrimary else ZvBlackCard)
                        .border(1.dp, if (isSel) ZvOrangeBright else Color(0x33FFFFFF), RoundedCornerShape(10.dp))
                        .clickable { currentProject = currentProject.copy(filterName = fName) }
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                      Text(fName, color = if (isSel) ZvWhite else ZvTextSecondary, fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                    }
                  }
                }
              }
            }

            EditorTool.EFFECT -> {
              Column {
                Text("Visual Effects & Blur", color = ZvOrangeBright, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                  listOf("None", "Glitch", "Vignette", "Film Grain").forEach { efName ->
                    val isSel = currentProject.effectName == efName
                    Box(
                      modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (isSel) ZvOrangePrimary else ZvBlackCard)
                        .clickable { currentProject = currentProject.copy(effectName = efName) }
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                      Text(efName, color = if (isSel) ZvWhite else ZvTextSecondary, fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                    }
                  }
                }
              }
            }

            EditorTool.TRANSITION -> {
              Column {
                Text("Transitions", color = ZvOrangeBright, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                  listOf("None", "Fade In", "Dissolve", "Zoom In", "Wipe Right").forEach { trName ->
                    val isSel = currentProject.transitionName == trName
                    Box(
                      modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (isSel) ZvOrangePrimary else ZvBlackCard)
                        .clickable { currentProject = currentProject.copy(transitionName = trName) }
                        .padding(horizontal = 10.dp, vertical = 8.dp)
                    ) {
                      Text(trName, color = if (isSel) ZvWhite else ZvTextSecondary, fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                    }
                  }
                }
              }
            }

            EditorTool.TEXT -> {
              Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  OutlinedTextField(
                    value = currentProject.textOverlay,
                    onValueChange = { currentProject = currentProject.copy(textOverlay = it) },
                    placeholder = { Text("Enter video title...", fontSize = 12.sp) },
                    singleLine = true,
                    modifier = Modifier.weight(1f),
                    colors = OutlinedTextFieldDefaults.colors(
                      focusedTextColor = ZvWhite,
                      unfocusedTextColor = ZvWhite,
                      focusedBorderColor = ZvOrangePrimary,
                      unfocusedBorderColor = Color(0x44FF6A00)
                    ),
                    shape = RoundedCornerShape(10.dp)
                  )
                  Spacer(modifier = Modifier.width(8.dp))
                  // Color toggle
                  Box(
                    modifier = Modifier
                      .size(36.dp)
                      .clip(CircleShape)
                      .background(Color(currentProject.textColor))
                      .border(1.dp, ZvWhite, CircleShape)
                      .clickable {
                        val nextColor = if (currentProject.textColor == 0xFFFFFFFF) 0xFFFF7A00 else 0xFFFFFFFF
                        currentProject = currentProject.copy(textColor = nextColor)
                      }
                  )
                }
              }
            }

            EditorTool.STICKER -> {
              Column {
                Text("Select Sticker to Overlay", color = ZvOrangeBright, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                  listOf("🔥", "⚡", "🎬", "🚀", "🌟", "🧡", "💥", "✂️").forEach { emoji ->
                    Box(
                      modifier = Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (currentProject.stickerName == emoji) Color(0x44FF6A00) else ZvBlackCard)
                        .clickable { currentProject = currentProject.copy(stickerName = emoji) }
                        .padding(4.dp),
                      contentAlignment = Alignment.Center
                    ) {
                      Text(emoji, fontSize = 20.sp)
                    }
                  }
                }
              }
            }

            EditorTool.MUSIC -> {
              // 7. Music: Add Music, Device Music, Extract Audio, Trim Audio, Volume, Voice Recording
              var isRecording by remember { mutableStateOf(false) }
              Column {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Text("Music & Voice Recording", color = ZvOrangeBright, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                  if (currentProject.musicTrackName != "None") {
                    Text(currentProject.musicTrackName, color = ZvWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                  }
                }
                Spacer(modifier = Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                  Button(
                    onClick = { currentProject = currentProject.copy(musicTrackName = "Upbeat Funk Beat") },
                    colors = ButtonDefaults.buttonColors(containerColor = ZvOrangePrimary),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                  ) {
                    Text("+ Add Music", color = ZvWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                  }
                  Button(
                    onClick = { audioPickerLauncher.launch("audio/*") },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0x22FFFFFF)),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                  ) {
                    Text("Device Music", color = ZvWhite, fontSize = 11.sp)
                  }
                  Button(
                    onClick = {
                      currentProject = currentProject.copy(musicTrackName = "Extracted Soundtrack")
                      Toast.makeText(context, "Extracted audio from video track!", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0x22FFFFFF)),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                  ) {
                    Text("Extract", color = ZvWhite, fontSize = 11.sp)
                  }
                  // Voice Recording button
                  Button(
                    onClick = {
                      isRecording = !isRecording
                      if (isRecording) {
                        Toast.makeText(context, "Voice Recording started...", Toast.LENGTH_SHORT).show()
                      } else {
                        currentProject = currentProject.copy(musicTrackName = "Voice Memo 1")
                        Toast.makeText(context, "Voice Memo saved to track!", Toast.LENGTH_SHORT).show()
                      }
                    },
                    colors = ButtonDefaults.buttonColors(
                      containerColor = if (isRecording) Color(0xFFFF3D00) else Color(0x22FF6A00)
                    ),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                  ) {
                    Icon(if (isRecording) Icons.Default.Stop else Icons.Default.Mic, contentDescription = null, tint = ZvWhite, modifier = Modifier.size(13.dp))
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(if (isRecording) "Stop" else "Voice Rec", color = ZvWhite, fontSize = 11.sp)
                  }
                }
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // --- 5. 13-Tools Horizontal Scrolling Bar ---
        LazyRow(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 4.dp),
          horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
          items(EditorTool.values()) { tool ->
            val isSelected = activeTool == tool
            Column(
              modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .background(if (isSelected) ZvOrangePrimary else ZvBlackCard)
                .clickable { activeTool = tool }
                .padding(horizontal = 8.dp, vertical = 5.dp),
              horizontalAlignment = Alignment.CenterHorizontally
            ) {
              Icon(
                imageVector = tool.icon,
                contentDescription = tool.label,
                tint = if (isSelected) ZvWhite else ZvOrangeBright,
                modifier = Modifier.size(17.dp)
              )
              Spacer(modifier = Modifier.height(2.dp))
              Text(
                text = tool.label,
                color = if (isSelected) ZvWhite else ZvTextSecondary,
                fontSize = 9.5.sp,
                fontWeight = FontWeight.Bold
              )
            }
          }
        }
      }
    }

    // --- 10. Fullscreen / High-Res Preview Modal ---
    if (showPreviewModal) {
      FullscreenPreviewModal(
        project = currentProject,
        onDismiss = { showPreviewModal = false }
      )
    }

    // --- 11. Export Dialog: 480p / 720p / 1080p, Save to Device, Share ---
    if (showExportDialog) {
      ExportModalDialog(
        project = currentProject,
        onDismiss = {
          showExportDialog = false
          isExporting = false
          exportProgress = 0f
          exportedDone = false
        },
        onSaveToProjects = {
          coroutineScope.launch {
            repository.saveProject(currentProject.toEntity())
            Toast.makeText(context, "Saved to My Projects!", Toast.LENGTH_SHORT).show()
            onSavedToMyProjects()
          }
        }
      )
    }
  }
}

/**
 * 10. Fullscreen Preview Modal
 * पूरा edited video बिना export किए देखा जा सके।
 */
@Composable
fun FullscreenPreviewModal(
  project: ActiveEditorProject,
  onDismiss: () -> Unit
) {
  var isPlaying by remember { mutableStateOf(true) }
  var currentPos by remember { mutableFloatStateOf(0f) }

  LaunchedEffect(isPlaying) {
    if (isPlaying) {
      while (isPlaying) {
        delay(50)
        currentPos += 0.05f
        if (currentPos >= project.durationSeconds) currentPos = 0f
      }
    }
  }

  AlertDialog(
    onDismissRequest = onDismiss,
    containerColor = Color(0xFF0D0D10),
    shape = RoundedCornerShape(20.dp),
    title = {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text("Full Video Preview", color = ZvWhite, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
          Icon(Icons.Default.Close, contentDescription = "Close", tint = ZvTextMuted)
        }
      }
    },
    text = {
      Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .height(260.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(Color.Black),
          contentAlignment = Alignment.Center
        ) {
          AsyncImage(
            model = project.mediaUri,
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
          )

          if (project.textOverlay.isNotBlank()) {
            Box(
              modifier = Modifier
                .align(Alignment.Center)
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0x99000000))
                .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
              Text(project.textOverlay, color = Color(project.textColor), fontSize = project.textSize.sp, fontWeight = FontWeight.Bold)
            }
          }

          if (project.stickerName.isNotBlank()) {
            Text(project.stickerName, fontSize = 48.sp, modifier = Modifier.align(Alignment.TopCenter).padding(top = 20.dp))
          }

          // Play/Pause tap
          Box(
            modifier = Modifier
              .fillMaxSize()
              .clickable { isPlaying = !isPlaying },
            contentAlignment = Alignment.Center
          ) {
            if (!isPlaying) {
              Icon(Icons.Default.PlayArrow, contentDescription = null, tint = ZvOrangePrimary, modifier = Modifier.size(48.dp))
            }
          }
        }

        Spacer(modifier = Modifier.height(10.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            "${String.format("%.1f", currentPos)}s / ${String.format("%.1f", project.durationSeconds)}s",
            color = ZvOrangeBright,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
          )
          Text("${project.aspectRatio} • ${project.speed}x", color = ZvTextMuted, fontSize = 11.sp)
        }
      }
    },
    confirmButton = {
      Button(
        onClick = onDismiss,
        colors = ButtonDefaults.buttonColors(containerColor = ZvOrangePrimary),
        shape = RoundedCornerShape(10.dp)
      ) {
        Text("Done", color = ZvWhite, fontWeight = FontWeight.Bold)
      }
    }
  )
}

/**
 * 11. Export Dialog: 480p / 720p / 1080p, Save to Device, Share
 */
@Composable
fun ExportModalDialog(
  project: ActiveEditorProject,
  onDismiss: () -> Unit,
  onSaveToProjects: () -> Unit
) {
  val context = LocalContext.current
  var selectedResolution by remember { mutableStateOf("1080p") }
  var isExporting by remember { mutableStateOf(false) }
  var exportProgress by remember { mutableFloatStateOf(0f) }
  var exportFinished by remember { mutableStateOf(false) }

  AlertDialog(
    onDismissRequest = { if (!isExporting) onDismiss() },
    containerColor = ZvBlackSurface,
    shape = RoundedCornerShape(20.dp),
    icon = {
      Icon(Icons.Default.Download, contentDescription = null, tint = ZvOrangePrimary, modifier = Modifier.size(32.dp))
    },
    title = {
      Text(
        text = if (exportFinished) "Export Complete!" else if (isExporting) "Rendering Video..." else "Export Video",
        color = ZvWhite,
        fontSize = 18.sp,
        fontWeight = FontWeight.Bold,
        textAlign = TextAlign.Center
      )
    },
    text = {
      Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
        if (!isExporting && !exportFinished) {
          Text("Choose quality for export:", color = ZvTextSecondary, fontSize = 12.5.sp)
          Spacer(modifier = Modifier.height(12.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            listOf("480p" to "Fast SD", "720p" to "HD", "1080p" to "Full HD").forEach { (res, desc) ->
              val isSel = selectedResolution == res
              Box(
                modifier = Modifier
                  .weight(1f)
                  .clip(RoundedCornerShape(10.dp))
                  .background(if (isSel) ZvOrangePrimary else ZvBlackCard)
                  .border(1.dp, if (isSel) ZvOrangeBright else Color(0x33FF6A00), RoundedCornerShape(10.dp))
                  .clickable { selectedResolution = res }
                  .padding(vertical = 10.dp),
                contentAlignment = Alignment.Center
              ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                  Text(res, color = if (isSel) ZvWhite else ZvTextSecondary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                  Text(desc, color = if (isSel) ZvWhite else ZvTextMuted, fontSize = 9.sp)
                }
              }
            }
          }
        } else if (isExporting) {
          Spacer(modifier = Modifier.height(10.dp))
          LinearProgressIndicator(
            progress = { exportProgress },
            modifier = Modifier
              .fillMaxWidth()
              .height(8.dp)
              .clip(RoundedCornerShape(4.dp)),
            color = ZvOrangePrimary,
            trackColor = ZvBlackCard,
          )
          Spacer(modifier = Modifier.height(10.dp))
          Text("${(exportProgress * 100).toInt()}% Rendered ($selectedResolution)", color = ZvOrangeBright, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        } else {
          // Exported Done: Save to Device & Share options
          Icon(Icons.Default.Check, contentDescription = null, tint = Color(0xFF00E676), modifier = Modifier.size(44.dp))
          Spacer(modifier = Modifier.height(8.dp))
          Text("Video exported in $selectedResolution successfully!", color = ZvWhite, fontSize = 13.sp, textAlign = TextAlign.Center)
          Spacer(modifier = Modifier.height(14.dp))

          // Save to Device & Share buttons
          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
              onClick = {
                Toast.makeText(context, "Saved to Device Movies / ZV_Editor folder!", Toast.LENGTH_LONG).show()
              },
              colors = ButtonDefaults.buttonColors(containerColor = Color(0x22FFFFFF)),
              shape = RoundedCornerShape(10.dp),
              modifier = Modifier.weight(1f)
            ) {
              Icon(Icons.Default.Download, contentDescription = null, tint = ZvWhite, modifier = Modifier.size(15.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("Save to Device", color = ZvWhite, fontSize = 11.5.sp)
            }

            Button(
              onClick = {
                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                  type = "text/plain"
                  putExtra(Intent.EXTRA_SUBJECT, "Created with ZV Video Editor")
                  putExtra(Intent.EXTRA_TEXT, "Check out my video created with ZV Editor! #ZVEditor")
                }
                context.startActivity(Intent.createChooser(shareIntent, "Share Video"))
              },
              colors = ButtonDefaults.buttonColors(containerColor = ZvOrangePrimary),
              shape = RoundedCornerShape(10.dp),
              modifier = Modifier.weight(1f)
            ) {
              Icon(Icons.Default.Share, contentDescription = null, tint = ZvWhite, modifier = Modifier.size(15.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("Share", color = ZvWhite, fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
            }
          }
        }
      }
    },
    confirmButton = {
      if (!isExporting && !exportFinished) {
        Button(
          onClick = {
            isExporting = true
            // Launch simulation loop
            kotlinx.coroutines.GlobalScope.launch {
              for (i in 1..20) {
                delay(120)
                exportProgress = i / 20f
              }
              isExporting = false
              exportFinished = true
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = ZvOrangePrimary),
          shape = RoundedCornerShape(10.dp)
        ) {
          Text("Start Render", color = ZvWhite, fontWeight = FontWeight.Bold)
        }
      } else if (exportFinished) {
        Button(
          onClick = {
            onSaveToProjects()
            onDismiss()
          },
          colors = ButtonDefaults.buttonColors(containerColor = ZvOrangePrimary),
          shape = RoundedCornerShape(10.dp)
        ) {
          Text("Save to My Projects", color = ZvWhite, fontWeight = FontWeight.Bold)
        }
      }
    },
    dismissButton = {
      if (!isExporting) {
        TextButton(onClick = onDismiss) {
          Text("Close", color = ZvTextMuted)
        }
      }
    }
  )
}
