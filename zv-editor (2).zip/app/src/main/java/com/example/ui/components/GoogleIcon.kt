package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Standard 4-color Google "G" logo drawn crisply on Canvas.
 */
@Composable
fun GoogleLogoIcon(
  modifier: Modifier = Modifier,
  size: Dp = 20.dp
) {
  Canvas(modifier = modifier.size(size)) {
    val w = this.size.width
    val h = this.size.height
    val strokeW = w * 0.20f
    val r = (w - strokeW) / 2f
    val center = Offset(w / 2f, h / 2f)
    val rect = Rect(center.x - r, center.y - r, center.x + r, center.y + r)

    // Red arc (top-left)
    val redPath = Path().apply {
      arcTo(rect, 200f, 80f, false)
    }
    drawPath(
      path = redPath,
      color = Color(0xFFEA4335),
      style = Stroke(width = strokeW, cap = StrokeCap.Round)
    )

    // Yellow arc (bottom-left)
    val yellowPath = Path().apply {
      arcTo(rect, 130f, 75f, false)
    }
    drawPath(
      path = yellowPath,
      color = Color(0xFFFBBC05),
      style = Stroke(width = strokeW, cap = StrokeCap.Round)
    )

    // Green arc (bottom-right)
    val greenPath = Path().apply {
      arcTo(rect, 35f, 95f, false)
    }
    drawPath(
      path = greenPath,
      color = Color(0xFF34A853),
      style = Stroke(width = strokeW, cap = StrokeCap.Round)
    )

    // Blue arc + center cross bar (right)
    val bluePath = Path().apply {
      arcTo(rect, 305f, 60f, false)
    }
    drawPath(
      path = bluePath,
      color = Color(0xFF4285F4),
      style = Stroke(width = strokeW, cap = StrokeCap.Round)
    )

    // Blue horizontal crossbar
    drawLine(
      color = Color(0xFF4285F4),
      start = Offset(center.x - (w * 0.05f), center.y),
      end = Offset(center.x + r + (strokeW / 4f), center.y),
      strokeWidth = strokeW,
      cap = StrokeCap.Square
    )
  }
}
