package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val ZvBlack = Color(0xFF080808)
val ZvBlackSurface = Color(0xFF121214)
val ZvBlackCard = Color(0xFF18181B)
val ZvBlackBorder = Color(0xFF2E1A0E)

val ZvOrangePrimary = Color(0xFFFF6A00)
val ZvOrangeBright = Color(0xFFFF7A1A)
val ZvOrangeDeep = Color(0xFFE55A00)
val ZvOrangeGradientEnd = Color(0xFFFF9500)
val ZvOrangeGlow = Color(0x55FF6A00)

val ZvWhite = Color(0xFFFFFFFF)
val ZvTextSecondary = Color(0xFFCCCCCC)
val ZvTextMuted = Color(0xFF8E8E93)
val ZvBorderGlow = Color(0xFFFF6A00)

