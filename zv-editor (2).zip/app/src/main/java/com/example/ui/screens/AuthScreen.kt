package com.example.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PersonOutline
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.UserProfile
import com.example.ui.components.GlowBackground
import com.example.ui.components.GoogleLogoIcon
import com.example.ui.components.ZvLogoBadge
import com.example.ui.components.ZvTagline
import com.example.ui.components.ZvWordmark
import com.example.ui.theme.ZvBlack
import com.example.ui.theme.ZvBlackCard
import com.example.ui.theme.ZvBlackSurface
import com.example.ui.theme.ZvOrangeBright
import com.example.ui.theme.ZvOrangeDeep
import com.example.ui.theme.ZvOrangePrimary
import com.example.ui.theme.ZvTextMuted
import com.example.ui.theme.ZvTextSecondary
import com.example.ui.theme.ZvWhite
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

enum class AuthMode {
  LOGIN,
  SIGN_UP
}

/**
 * ZV Auth Screen supporting:
 * - Sign Up / Login toggle
 * - Continue with Google (one-tap account selector)
 * - Email & Password authentication with input validation
 * - Clear "Login" / "Sign Up" actions
 * - Guest / Skip option ("Continue as Guest" / "Skip for now")
 */
@Composable
fun AuthScreen(
  onAuthSuccess: (UserProfile) -> Unit,
  onGuestSkip: () -> Unit,
  onBack: (() -> Unit)? = null,
  initialMode: AuthMode = AuthMode.LOGIN,
  modifier: Modifier = Modifier
) {
  var mode by remember { mutableStateOf(initialMode) }
  var email by remember { mutableStateOf("") }
  var password by remember { mutableStateOf("") }
  var name by remember { mutableStateOf("") }
  var isPasswordVisible by remember { mutableStateOf(false) }
  var errorMessage by remember { mutableStateOf<String?>(null) }
  var isLoading by remember { mutableStateOf(false) }
  var showGoogleDialog by remember { mutableStateOf(false) }
  var showForgotPasswordDialog by remember { mutableStateOf(false) }

  val coroutineScope = rememberCoroutineScope()

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(ZvBlack)
      .testTag("auth_screen")
  ) {
    // Ambient glowing wave background
    GlowBackground(animated = true)

    // Outer Neon Orange Border Container
    Box(
      modifier = Modifier
        .fillMaxSize()
        .statusBarsPadding()
        .navigationBarsPadding()
        .padding(8.dp)
        .border(
          width = 2.dp,
          brush = Brush.verticalGradient(
            colors = listOf(
              Color(0xFFFF7A00),
              Color(0xFFFF5200),
              Color(0xFFFF8800)
            )
          ),
          shape = RoundedCornerShape(22.dp)
        )
        .clip(RoundedCornerShape(22.dp))
        .background(Color(0xFF0A0A0C))
    ) {
      Column(
        modifier = Modifier
          .fillMaxSize()
          .verticalScroll(rememberScrollState())
          .padding(horizontal = 20.dp, vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        // --- Top Bar: Back & Skip ---
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 6.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          if (onBack != null) {
            IconButton(
              onClick = onBack,
              modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(Color(0x331F1F24))
                .testTag("auth_back_button")
            ) {
              Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = "Back",
                tint = ZvOrangePrimary,
                modifier = Modifier.size(18.dp)
              )
            }
          } else {
            Spacer(modifier = Modifier.size(36.dp))
          }

          // Guest / Skip Option on Top-Right
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(18.dp))
              .border(1.2.dp, ZvOrangePrimary.copy(alpha = 0.7f), RoundedCornerShape(18.dp))
              .background(Color(0x2218181B))
              .clickable { onGuestSkip() }
              .padding(horizontal = 12.dp, vertical = 6.dp)
              .testTag("skip_auth_button")
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
              Text(
                text = "Skip / Guest",
                color = ZvWhite,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
              )
              Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                contentDescription = "Skip to Guest",
                tint = ZvOrangePrimary,
                modifier = Modifier.size(14.dp)
              )
            }
          }
        }

        // --- ZV Header Badge & Wordmark ---
        ZvLogoBadge(
          size = 48.dp,
          pulsingGlow = true
        )

        Spacer(modifier = Modifier.height(4.dp))

        ZvWordmark(fontSize = 32f)

        Spacer(modifier = Modifier.height(2.dp))

        ZvTagline(fontSize = 11.5f)

        Spacer(modifier = Modifier.height(18.dp))

        // --- Auth Mode Switcher Tab (Sign Up / Login) ---
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .height(44.dp)
            .clip(RoundedCornerShape(22.dp))
            .background(ZvBlackSurface)
            .border(1.2.dp, Color(0x44FF6A00), RoundedCornerShape(22.dp))
            .padding(3.dp)
        ) {
          Row(
            modifier = Modifier.fillMaxSize()
          ) {
            // Login Tab
            Box(
              modifier = Modifier
                .weight(1f)
                .fillMaxSize()
                .clip(RoundedCornerShape(19.dp))
                .background(
                  if (mode == AuthMode.LOGIN) ZvOrangePrimary else Color.Transparent
                )
                .clickable {
                  mode = AuthMode.LOGIN
                  errorMessage = null
                }
                .testTag("tab_login"),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = "Log In",
                color = if (mode == AuthMode.LOGIN) ZvWhite else ZvTextSecondary,
                fontSize = 13.5.sp,
                fontWeight = FontWeight.Bold
              )
            }

            // Sign Up Tab
            Box(
              modifier = Modifier
                .weight(1f)
                .fillMaxSize()
                .clip(RoundedCornerShape(19.dp))
                .background(
                  if (mode == AuthMode.SIGN_UP) ZvOrangePrimary else Color.Transparent
                )
                .clickable {
                  mode = AuthMode.SIGN_UP
                  errorMessage = null
                }
                .testTag("tab_signup"),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = "Sign Up",
                color = if (mode == AuthMode.SIGN_UP) ZvWhite else ZvTextSecondary,
                fontSize = 13.5.sp,
                fontWeight = FontWeight.Bold
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // --- 1. Continue with Google Button ---
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .height(48.dp)
            .shadow(4.dp, RoundedCornerShape(14.dp))
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0xFFFFFFFF))
            .clickable { showGoogleDialog = true }
            .testTag("google_login_button"),
          contentAlignment = Alignment.Center
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
          ) {
            GoogleLogoIcon(size = 20.dp)
            Spacer(modifier = Modifier.width(10.dp))
            Text(
              text = if (mode == AuthMode.LOGIN) "Continue with Google" else "Sign up with Google",
              color = Color(0xFF1F1F1F),
              fontSize = 14.sp,
              fontWeight = FontWeight.Bold
            )
          }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // --- "OR WITH EMAIL" Divider ---
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically
        ) {
          HorizontalDivider(
            modifier = Modifier.weight(1f),
            color = Color(0x33FF6A00)
          )
          Text(
            text = "OR WITH EMAIL",
            color = ZvTextMuted,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 10.dp),
            letterSpacing = 1.sp
          )
          HorizontalDivider(
            modifier = Modifier.weight(1f),
            color = Color(0x33FF6A00)
          )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Error message banner if any
        if (errorMessage != null) {
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(10.dp))
              .background(Color(0x33FF3D00))
              .border(1.dp, Color(0xFFFF3D00), RoundedCornerShape(10.dp))
              .padding(10.dp)
          ) {
            Text(
              text = errorMessage!!,
              color = Color(0xFFFF8A80),
              fontSize = 12.sp,
              textAlign = TextAlign.Center,
              modifier = Modifier.fillMaxWidth()
            )
          }
          Spacer(modifier = Modifier.height(10.dp))
        }

        // --- 2. Email Fields ---
        // Name field only for Sign Up mode
        if (mode == AuthMode.SIGN_UP) {
          OutlinedTextField(
            value = name,
            onValueChange = { name = it },
            label = { Text("Full Name / Creator Handle") },
            leadingIcon = {
              Icon(Icons.Default.Person, contentDescription = null, tint = ZvOrangeBright, modifier = Modifier.size(19.dp))
            },
            singleLine = true,
            modifier = Modifier
              .fillMaxWidth()
              .testTag("auth_name_field"),
            colors = OutlinedTextFieldDefaults.colors(
              focusedTextColor = ZvWhite,
              unfocusedTextColor = ZvWhite,
              focusedBorderColor = ZvOrangePrimary,
              unfocusedBorderColor = Color(0x44FF6A00),
              focusedLabelColor = ZvOrangeBright,
              unfocusedLabelColor = ZvTextMuted
            ),
            shape = RoundedCornerShape(14.dp)
          )
          Spacer(modifier = Modifier.height(10.dp))
        }

        // Email address field
        OutlinedTextField(
          value = email,
          onValueChange = {
            email = it
            errorMessage = null
          },
          label = { Text("Email Address") },
          leadingIcon = {
            Icon(Icons.Default.Email, contentDescription = null, tint = ZvOrangeBright, modifier = Modifier.size(19.dp))
          },
          singleLine = true,
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email, imeAction = ImeAction.Next),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("auth_email_field"),
          colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = ZvWhite,
            unfocusedTextColor = ZvWhite,
            focusedBorderColor = ZvOrangePrimary,
            unfocusedBorderColor = Color(0x44FF6A00),
            focusedLabelColor = ZvOrangeBright,
            unfocusedLabelColor = ZvTextMuted
          ),
          shape = RoundedCornerShape(14.dp)
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Password field with visibility toggle
        OutlinedTextField(
          value = password,
          onValueChange = {
            password = it
            errorMessage = null
          },
          label = { Text("Password") },
          leadingIcon = {
            Icon(Icons.Default.Lock, contentDescription = null, tint = ZvOrangeBright, modifier = Modifier.size(19.dp))
          },
          trailingIcon = {
            IconButton(onClick = { isPasswordVisible = !isPasswordVisible }) {
              Icon(
                imageVector = if (isPasswordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                contentDescription = if (isPasswordVisible) "Hide password" else "Show password",
                tint = ZvTextMuted,
                modifier = Modifier.size(20.dp)
              )
            }
          },
          singleLine = true,
          visualTransformation = if (isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Done),
          keyboardActions = KeyboardActions(
            onDone = {
              performAuthSubmit(
                mode = mode,
                email = email,
                password = password,
                name = name,
                onError = { errorMessage = it },
                onStartLoading = { isLoading = true },
                onEndLoading = { isLoading = false },
                onSuccess = onAuthSuccess,
                coroutineScope = coroutineScope
              )
            }
          ),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("auth_password_field"),
          colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = ZvWhite,
            unfocusedTextColor = ZvWhite,
            focusedBorderColor = ZvOrangePrimary,
            unfocusedBorderColor = Color(0x44FF6A00),
            focusedLabelColor = ZvOrangeBright,
            unfocusedLabelColor = ZvTextMuted
          ),
          shape = RoundedCornerShape(14.dp)
        )

        // Forgot password row (in login mode)
        if (mode == AuthMode.LOGIN) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(top = 4.dp),
            horizontalArrangement = Arrangement.End
          ) {
            Text(
              text = "Forgot password?",
              color = ZvOrangeBright,
              fontSize = 12.sp,
              fontWeight = FontWeight.Medium,
              modifier = Modifier
                .clickable { showForgotPasswordDialog = true }
                .padding(vertical = 4.dp)
            )
          }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // --- 3. Primary Action Button: "Login" / "Sign Up" ---
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .height(48.dp)
            .shadow(
              elevation = 10.dp,
              shape = RoundedCornerShape(14.dp),
              spotColor = ZvOrangePrimary
            )
            .clip(RoundedCornerShape(14.dp))
            .background(
              Brush.horizontalGradient(
                colors = listOf(
                  Color(0xFFFF7A00),
                  Color(0xFFFF5200),
                  Color(0xFFFF3D00)
                )
              )
            )
            .clickable(enabled = !isLoading) {
              performAuthSubmit(
                mode = mode,
                email = email,
                password = password,
                name = name,
                onError = { errorMessage = it },
                onStartLoading = { isLoading = true },
                onEndLoading = { isLoading = false },
                onSuccess = onAuthSuccess,
                coroutineScope = coroutineScope
              )
            }
            .testTag("auth_submit_button"),
          contentAlignment = Alignment.Center
        ) {
          if (isLoading) {
            CircularProgressIndicator(
              modifier = Modifier.size(22.dp),
              color = ZvWhite,
              strokeWidth = 2.5.dp
            )
          } else {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.Center
            ) {
              Text(
                text = if (mode == AuthMode.LOGIN) "Log In" else "Create Account",
                color = ZvWhite,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp
              )
              Spacer(modifier = Modifier.width(6.dp))
              Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                contentDescription = null,
                tint = ZvWhite,
                modifier = Modifier.size(17.dp)
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // --- 4. Guest / Skip Option (Prompted explicitly) ---
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0x3318181B))
            .border(1.2.dp, Color(0x33FF6A00), RoundedCornerShape(14.dp))
            .clickable { onGuestSkip() }
            .padding(vertical = 12.dp, horizontal = 14.dp)
            .testTag("continue_as_guest_card"),
          contentAlignment = Alignment.Center
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
          ) {
            Icon(
              imageVector = Icons.Default.PersonOutline,
              contentDescription = null,
              tint = ZvOrangeBright,
              modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column(horizontalAlignment = Alignment.Start) {
              Text(
                text = "Continue as Guest / Skip",
                color = ZvWhite,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
              )
              Text(
                text = "Explore all tools & effects without creating an account",
                color = ZvTextMuted,
                fontSize = 10.5.sp
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Footer terms
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.Center
        ) {
          Icon(
            imageVector = Icons.Default.Shield,
            contentDescription = null,
            tint = ZvOrangePrimary,
            modifier = Modifier.size(13.dp)
          )
          Spacer(modifier = Modifier.width(5.dp))
          Text(
            text = "256-bit Encrypted • Safe & Private",
            color = ZvTextMuted,
            fontSize = 11.sp
          )
        }

        Spacer(modifier = Modifier.height(8.dp))
      }
    }

    // Google Sign-In Account Selector Dialog
    if (showGoogleDialog) {
      GoogleAccountSelectorModal(
        onDismiss = { showGoogleDialog = false },
        onAccountSelected = { accountName, accountEmail ->
          showGoogleDialog = false
          isLoading = true
          coroutineScope.launch {
            delay(500)
            isLoading = false
            onAuthSuccess(
              UserProfile(
                name = accountName,
                email = accountEmail,
                isGuest = false,
                isAuthenticated = true
              )
            )
          }
        }
      )
    }

    // Forgot Password Dialog
    if (showForgotPasswordDialog) {
      ForgotPasswordModal(
        initialEmail = email,
        onDismiss = { showForgotPasswordDialog = false }
      )
    }
  }
}

/**
 * Validates and submits auth flow.
 */
private fun performAuthSubmit(
  mode: AuthMode,
  email: String,
  password: String,
  name: String,
  onError: (String) -> Unit,
  onStartLoading: () -> Unit,
  onEndLoading: () -> Unit,
  onSuccess: (UserProfile) -> Unit,
  coroutineScope: kotlinx.coroutines.CoroutineScope
) {
  val cleanEmail = email.trim()
  if (cleanEmail.isBlank()) {
    onError("Please enter your email address.")
    return
  }
  if (!cleanEmail.contains("@") || !cleanEmail.contains(".")) {
    onError("Please enter a valid email address.")
    return
  }
  if (password.length < 6) {
    onError("Password must be at least 6 characters.")
    return
  }

  onStartLoading()
  coroutineScope.launch {
    delay(600)
    onEndLoading()
    val displayName = if (mode == AuthMode.SIGN_UP && name.isNotBlank()) {
      name.trim()
    } else {
      cleanEmail.substringBefore("@").replaceFirstChar { it.uppercase() }
    }
    onSuccess(
      UserProfile(
        name = displayName,
        email = cleanEmail,
        isGuest = false,
        isAuthenticated = true
      )
    )
  }
}

/**
 * Google Account Picker Sheet / Dialog
 */
@Composable
fun GoogleAccountSelectorModal(
  onDismiss: () -> Unit,
  onAccountSelected: (name: String, email: String) -> Unit
) {
  AlertDialog(
    onDismissRequest = onDismiss,
    containerColor = ZvBlackSurface,
    shape = RoundedCornerShape(20.dp),
    icon = {
      GoogleLogoIcon(size = 32.dp)
    },
    title = {
      Text(
        text = "Choose Google Account",
        color = ZvWhite,
        fontSize = 18.sp,
        fontWeight = FontWeight.Bold,
        textAlign = TextAlign.Center
      )
    },
    text = {
      Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        Text(
          text = "to continue to ZV Editor",
          color = ZvTextSecondary,
          fontSize = 12.5.sp,
          textAlign = TextAlign.Center,
          modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(4.dp))

        // Account Item 1 (From user profile)
        GoogleAccountRow(
          name = "Creator Studio",
          email = "fg8kd8ds8vcd@gmail.com",
          onClick = {
            onAccountSelected("Creator Studio", "fg8kd8ds8vcd@gmail.com")
          }
        )

        // Account Item 2 (Demo creator account)
        GoogleAccountRow(
          name = "ZV Video Creator",
          email = "creator@zveditor.app",
          onClick = {
            onAccountSelected("ZV Video Creator", "creator@zveditor.app")
          }
        )
      }
    },
    confirmButton = {},
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text("Cancel", color = ZvTextMuted)
      }
    }
  )
}

@Composable
private fun GoogleAccountRow(
  name: String,
  email: String,
  onClick: () -> Unit
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(12.dp))
      .background(ZvBlackCard)
      .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(12.dp))
      .clickable { onClick() }
      .padding(10.dp),
    verticalAlignment = Alignment.CenterVertically
  ) {
    Box(
      modifier = Modifier
        .size(34.dp)
        .clip(CircleShape)
        .background(ZvOrangePrimary),
      contentAlignment = Alignment.Center
    ) {
      Text(
        text = name.take(1).uppercase(),
        color = ZvWhite,
        fontSize = 14.sp,
        fontWeight = FontWeight.Bold
      )
    }
    Spacer(modifier = Modifier.width(10.dp))
    Column(modifier = Modifier.weight(1f)) {
      Text(text = name, color = ZvWhite, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
      Text(text = email, color = ZvTextMuted, fontSize = 11.sp)
    }
  }
}

/**
 * Forgot Password Dialog
 */
@Composable
fun ForgotPasswordModal(
  initialEmail: String,
  onDismiss: () -> Unit
) {
  var email by remember { mutableStateOf(initialEmail) }
  var isSent by remember { mutableStateOf(false) }

  AlertDialog(
    onDismissRequest = onDismiss,
    containerColor = ZvBlackSurface,
    shape = RoundedCornerShape(20.dp),
    icon = {
      Icon(Icons.Default.Lock, contentDescription = null, tint = ZvOrangePrimary, modifier = Modifier.size(30.dp))
    },
    title = {
      Text("Reset Password", color = ZvWhite, fontSize = 18.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
    },
    text = {
      if (isSent) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
          Icon(Icons.Default.Check, contentDescription = null, tint = Color(0xFF00E676), modifier = Modifier.size(36.dp))
          Spacer(modifier = Modifier.height(8.dp))
          Text("Password reset instructions sent to $email", color = ZvWhite, fontSize = 13.sp, textAlign = TextAlign.Center)
        }
      } else {
        Column(modifier = Modifier.fillMaxWidth()) {
          Text("Enter your email address to receive password recovery link.", color = ZvTextSecondary, fontSize = 12.5.sp)
          Spacer(modifier = Modifier.height(10.dp))
          OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            label = { Text("Email Address") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
              focusedTextColor = ZvWhite,
              unfocusedTextColor = ZvWhite,
              focusedBorderColor = ZvOrangePrimary,
              unfocusedBorderColor = Color(0x44FF6A00),
              focusedLabelColor = ZvOrangeBright,
              unfocusedLabelColor = ZvTextMuted
            ),
            shape = RoundedCornerShape(12.dp)
          )
        }
      }
    },
    confirmButton = {
      if (!isSent) {
        Button(
          onClick = {
            if (email.isNotBlank()) isSent = true
          },
          colors = ButtonDefaults.buttonColors(containerColor = ZvOrangePrimary),
          shape = RoundedCornerShape(14.dp)
        ) {
          Text("Send Link", color = ZvWhite, fontWeight = FontWeight.Bold)
        }
      } else {
        Button(
          onClick = onDismiss,
          colors = ButtonDefaults.buttonColors(containerColor = ZvOrangePrimary),
          shape = RoundedCornerShape(14.dp)
        ) {
          Text("Done", color = ZvWhite, fontWeight = FontWeight.Bold)
        }
      }
    },
    dismissButton = {
      if (!isSent) {
        TextButton(onClick = onDismiss) {
          Text("Cancel", color = ZvTextMuted)
        }
      }
    }
  )
}
