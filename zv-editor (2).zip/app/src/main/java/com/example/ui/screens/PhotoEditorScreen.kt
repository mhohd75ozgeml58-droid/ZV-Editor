package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material.icons.filled.Crop
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.Transform
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.outlined.EmojiEmotions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.db.ProjectEntity
import com.example.data.repository.ProjectRepository
import com.example.model.ActiveEditorProject
import com.example.ui.components.GlowBackground
import com.example.ui.theme.ZvBlack
import com.example.ui.theme.ZvBlackCard
import com.example.ui.theme.ZvBlackSurface
import com.example.ui.theme.ZvOrangeBright
import com.example.ui.theme.ZvOrangePrimary
import com.example.ui.theme.ZvTextMuted
import com.example.ui.theme.ZvTextSecondary
import com.example.ui.theme.ZvWhite
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

enum class PhotoTool {
  CROP,
  RESIZE,
  ROTATE,
  FILTERS,
  ADJUST,
  EFFECTS,
  TEXT,
  STICKERS,
  BACKGROUND
}

/**
 * 13. Photo Editor Screen
 * Tools: Crop, Resize, Rotate, Filters, Adjust, Effects, Text, Stickers, Background.
 */
@Composable
fun PhotoEditorScreen(
  initialPhotoUri: String? = null,
  onBack: () -> Unit,
  onSavedToProjects: () -> Unit,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val repository = remember { ProjectRepository.getRepository(context) }
  val coroutineScope = rememberCoroutineScope()

  var photoUri by remember {
    mutableStateOf(initialPhotoUri ?: ActiveEditorProject.SAMPLE_PHOTOS.first())
  }

  // Active Tool Selection
  var activeTool by remember { mutableStateOf(PhotoTool.FILTERS) }

  // 1. Crop Ratio
  var cropRatioName by remember { mutableStateOf("1:1") }
  val cropAspectRatio = remember(cropRatioName) {
    when (cropRatioName) {
      "1:1" -> 1f
      "4:5" -> 4f / 5f
      "16:9" -> 16f / 9f
      "9:16" -> 9f / 16f
      else -> 1f
    }
  }

  // 2. Resize / Scale
  var imageScale by remember { mutableFloatStateOf(1.0f) }

  // 3. Rotate & Flip
  var rotationAngle by remember { mutableIntStateOf(0) }
  var flipH by remember { mutableStateOf(false) }
  var flipV by remember { mutableStateOf(false) }

  // 4. Filters
  var activeFilterName by remember { mutableStateOf("Normal") }

  // 5. Adjustments
  var brightness by remember { mutableFloatStateOf(0f) }
  var contrast by remember { mutableFloatStateOf(1f) }
  var saturation by remember { mutableFloatStateOf(1f) }

  // 6. Effects
  var activeEffectName by remember { mutableStateOf("None") }

  // 7. Text Overlay
  var textOverlay by remember { mutableStateOf("") }
  var textColor by remember { mutableStateOf(Color.White) }
  var textSize by remember { mutableFloatStateOf(24f) }
  var textOffset by remember { mutableStateOf(Offset.Zero) }

  // 8. Stickers
  var activeSticker by remember { mutableStateOf("") }
  var stickerOffset by remember { mutableStateOf(Offset.Zero) }
  var stickerScale by remember { mutableFloatStateOf(1.2f) }

  // 9. Background Style
  var backgroundStyle by remember { mutableStateOf("Dark Surface") }

  // Photo Picker Launcher
  val photoPickerLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.PickVisualMedia()
  ) { uri: Uri? ->
    if (uri != null) {
      photoUri = uri.toString()
    }
  }

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(ZvBlack)
      .testTag("photo_editor_screen")
  ) {
    GlowBackground(animated = false)

    // Outer Neon Border
    Box(
      modifier = Modifier
        .fillMaxSize()
        .statusBarsPadding()
        .navigationBarsPadding()
        .padding(6.dp)
        .border(
          width = 2.dp,
          brush = Brush.verticalGradient(
            colors = listOf(Color(0xFFFF7A00), Color(0xFFFF5200), Color(0xFFFF8800))
          ),
          shape = RoundedCornerShape(20.dp)
        )
        .clip(RoundedCornerShape(20.dp))
        .background(Color(0xFF09090B))
    ) {
      Column(modifier = Modifier.fillMaxSize()) {
        // --- Top Bar: Back, Select Photo, Save to Projects, Share ---
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 10.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(
              onClick = onBack,
              modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(Color(0x331F1F24))
            ) {
              Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = "Back",
                tint = ZvOrangePrimary,
                modifier = Modifier.size(18.dp)
              )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text("Photo Editor", color = ZvWhite, fontSize = 17.sp, fontWeight = FontWeight.Bold)
          }

          Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            // Pick other photo button
            IconButton(
              onClick = {
                photoPickerLauncher.launch(
                  PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                )
              },
              modifier = Modifier
                .size(34.dp)
                .clip(CircleShape)
                .background(Color(0x22FF6A00))
            ) {
              Icon(Icons.Default.PhotoCamera, contentDescription = "Pick Photo", tint = ZvOrangeBright, modifier = Modifier.size(18.dp))
            }

            // Share Intent
            IconButton(
              onClick = {
                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                  type = "text/plain"
                  putExtra(Intent.EXTRA_SUBJECT, "Created with ZV Photo Editor")
                  putExtra(Intent.EXTRA_TEXT, "Check out my photo edited with ZV Editor! #ZVEditor")
                }
                context.startActivity(Intent.createChooser(shareIntent, "Share Photo"))
              },
              modifier = Modifier
                .size(34.dp)
                .clip(CircleShape)
                .background(Color(0x22FFFFFF))
            ) {
              Icon(Icons.Default.Share, contentDescription = "Share", tint = ZvWhite, modifier = Modifier.size(17.dp))
            }

            // Save to Projects button
            Button(
              onClick = {
                coroutineScope.launch {
                  val newProject = ProjectEntity(
                    title = "Photo_${System.currentTimeMillis() % 10000}",
                    type = "PHOTO",
                    mediaUri = photoUri,
                    aspectRatio = cropRatioName,
                    filterName = activeFilterName,
                    brightness = brightness,
                    contrast = contrast,
                    saturation = saturation,
                    rotationDegrees = rotationAngle,
                    cropRatio = cropRatioName,
                    textOverlay = textOverlay,
                    stickerName = activeSticker,
                    effectName = activeEffectName
                  )
                  repository.saveProject(newProject)
                  Toast.makeText(context, "Saved to My Projects!", Toast.LENGTH_SHORT).show()
                  onSavedToProjects()
                }
              },
              colors = ButtonDefaults.buttonColors(containerColor = ZvOrangePrimary),
              shape = RoundedCornerShape(10.dp),
              contentPadding = PaddingValues(horizontal = 10.dp, vertical = 5.dp)
            ) {
              Icon(Icons.Default.Save, contentDescription = null, tint = ZvWhite, modifier = Modifier.size(14.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("Save", color = ZvWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
          }
        }

        // --- Photo Canvas / Preview Area ---
        Box(
          modifier = Modifier
            .weight(1f)
            .fillMaxWidth()
            .padding(horizontal = 12.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(
              when (backgroundStyle) {
                "Orange Glow" -> Color(0xFF2B1202)
                "Studio White" -> Color(0xFFE5E5E5)
                "Deep Purple" -> Color(0xFF160924)
                else -> Color(0xFF121214)
              }
            )
            .border(
              1.5.dp,
              if (backgroundStyle == "Orange Glow") ZvOrangePrimary else Color(0x33FF6A00),
              RoundedCornerShape(16.dp)
            ),
          contentAlignment = Alignment.Center
        ) {
          // Crop framing container
          Box(
            modifier = Modifier
              .fillMaxWidth(0.92f)
              .aspectRatio(cropAspectRatio)
              .clip(RoundedCornerShape(12.dp))
              .background(Color.Black),
            contentAlignment = Alignment.Center
          ) {
            // Filter color overlay
            val filterColorFilter = remember(activeFilterName) {
              when (activeFilterName) {
                "Vivid Orange" -> ColorFilter.tint(Color(0xFFFF7A00).copy(alpha = 0.28f), BlendMode.ColorBurn)
                "Cyberpunk" -> ColorFilter.tint(Color(0xFF00E5FF).copy(alpha = 0.32f), BlendMode.Color)
                "Noir B&W" -> ColorFilter.colorMatrix(androidx.compose.ui.graphics.ColorMatrix().apply { setToSaturation(0f) })
                "Golden Hour" -> ColorFilter.tint(Color(0xFFFFB300).copy(alpha = 0.35f), BlendMode.Overlay)
                "Warm Amber" -> ColorFilter.tint(Color(0xFFFF7043).copy(alpha = 0.25f), BlendMode.Softlight)
                "Cool Blue" -> ColorFilter.tint(Color(0xFF42A5F5).copy(alpha = 0.30f), BlendMode.Overlay)
                else -> null
              }
            }

            // Photo image
            AsyncImage(
              model = photoUri,
              contentDescription = "Editing Photo",
              contentScale = ContentScale.Crop,
              colorFilter = filterColorFilter,
              modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                  scaleX = (if (flipH) -1f else 1f) * imageScale
                  scaleY = (if (flipV) -1f else 1f) * imageScale
                  rotationZ = rotationAngle.toFloat()
                }
            )

            // Visual Effect Overlay (Vignette, Glitch, etc.)
            if (activeEffectName != "None") {
              Canvas(modifier = Modifier.fillMaxSize()) {
                when (activeEffectName) {
                  "Vignette" -> {
                    drawRect(
                      brush = Brush.radialGradient(
                        colors = listOf(Color.Transparent, Color(0xCC000000)),
                        radius = size.width * 0.8f
                      )
                    )
                  }
                  "Cyber Glow" -> {
                    drawRect(
                      brush = Brush.verticalGradient(
                        colors = listOf(Color(0x33FF6A00), Color.Transparent, Color(0x3300E5FF))
                      )
                    )
                  }
                  "Film Grain" -> {
                    drawRect(color = Color(0x22FFFFFF))
                  }
                }
              }
            }

            // Draggable Text Overlay
            if (textOverlay.isNotBlank()) {
              Box(
                modifier = Modifier
                  .offset { IntOffset(textOffset.x.roundToInt(), textOffset.y.roundToInt()) }
                  .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                      change.consume()
                      textOffset += dragAmount
                    }
                  }
                  .clip(RoundedCornerShape(8.dp))
                  .background(Color(0x88000000))
                  .padding(horizontal = 10.dp, vertical = 4.dp)
              ) {
                Text(
                  text = textOverlay,
                  color = textColor,
                  fontSize = textSize.sp,
                  fontWeight = FontWeight.Bold
                )
              }
            }

            // Draggable Sticker Overlay
            if (activeSticker.isNotBlank()) {
              Box(
                modifier = Modifier
                  .offset { IntOffset(stickerOffset.x.roundToInt(), stickerOffset.y.roundToInt()) }
                  .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                      change.consume()
                      stickerOffset += dragAmount
                    }
                  }
                  .scale(stickerScale)
              ) {
                Text(text = activeSticker, fontSize = 42.sp)
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // --- Active Tool Control Subpanel ---
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .height(130.dp)
            .padding(horizontal = 12.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(ZvBlackSurface)
            .border(1.dp, Color(0x33FF6A00), RoundedCornerShape(14.dp))
            .padding(10.dp)
        ) {
          when (activeTool) {
            PhotoTool.CROP -> {
              Column {
                Text("Crop Aspect Ratio", color = ZvOrangeBright, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                  listOf("1:1", "4:5", "16:9", "9:16").forEach { ratio ->
                    val isSel = cropRatioName == ratio
                    Box(
                      modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (isSel) ZvOrangePrimary else ZvBlackCard)
                        .clickable { cropRatioName = ratio }
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                      Text(ratio, color = if (isSel) ZvWhite else ZvTextSecondary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                  }
                }
              }
            }

            PhotoTool.RESIZE -> {
              Column {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                  Text("Image Zoom & Resize Scale", color = ZvOrangeBright, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                  Text("${(imageScale * 100).toInt()}%", color = ZvWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                Slider(
                  value = imageScale,
                  onValueChange = { imageScale = it },
                  valueRange = 0.5f..2.0f,
                  colors = SliderDefaults.colors(thumbColor = ZvOrangeBright, activeTrackColor = ZvOrangePrimary)
                )
              }
            }

            PhotoTool.ROTATE -> {
              Column {
                Text("Rotate & Flip Controls", color = ZvOrangeBright, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                  Button(
                    onClick = { rotationAngle = (rotationAngle + 90) % 360 },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0x22FF6A00)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, ZvOrangePrimary),
                    shape = RoundedCornerShape(10.dp)
                  ) {
                    Icon(Icons.Default.RotateRight, contentDescription = null, tint = ZvOrangeBright, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("+90°", color = ZvWhite, fontSize = 12.sp)
                  }

                  Button(
                    onClick = { flipH = !flipH },
                    colors = ButtonDefaults.buttonColors(containerColor = if (flipH) ZvOrangePrimary else Color(0x22FFFFFF)),
                    shape = RoundedCornerShape(10.dp)
                  ) {
                    Text("Flip H", color = ZvWhite, fontSize = 12.sp)
                  }

                  Button(
                    onClick = { flipV = !flipV },
                    colors = ButtonDefaults.buttonColors(containerColor = if (flipV) ZvOrangePrimary else Color(0x22FFFFFF)),
                    shape = RoundedCornerShape(10.dp)
                  ) {
                    Text("Flip V", color = ZvWhite, fontSize = 12.sp)
                  }
                }
              }
            }

            PhotoTool.FILTERS -> {
              Column {
                Text("Filters Preset", color = ZvOrangeBright, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(6.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                  items(listOf("Normal", "Vivid Orange", "Cyberpunk", "Noir B&W", "Golden Hour", "Warm Amber", "Cool Blue")) { fName ->
                    val isSel = activeFilterName == fName
                    Box(
                      modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (isSel) ZvOrangePrimary else ZvBlackCard)
                        .border(1.dp, if (isSel) ZvOrangeBright else Color(0x33FFFFFF), RoundedCornerShape(10.dp))
                        .clickable { activeFilterName = fName }
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                      Text(fName, color = if (isSel) ZvWhite else ZvTextSecondary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                  }
                }
              }
            }

            PhotoTool.ADJUST -> {
              Column {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                  Text("Brightness & Contrast", color = ZvOrangeBright, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                  Text("Bright: ${(brightness * 100).toInt()}%", color = ZvWhite, fontSize = 11.sp)
                }
                Slider(
                  value = brightness,
                  onValueChange = { brightness = it },
                  valueRange = -0.5f..0.5f,
                  colors = SliderDefaults.colors(thumbColor = ZvOrangeBright, activeTrackColor = ZvOrangePrimary)
                )
              }
            }

            PhotoTool.EFFECTS -> {
              Column {
                Text("Visual Effects", color = ZvOrangeBright, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                  listOf("None", "Vignette", "Cyber Glow", "Film Grain").forEach { efName ->
                    val isSel = activeEffectName == efName
                    Box(
                      modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (isSel) ZvOrangePrimary else ZvBlackCard)
                        .clickable { activeEffectName = efName }
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                      Text(efName, color = if (isSel) ZvWhite else ZvTextSecondary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                  }
                }
              }
            }

            PhotoTool.TEXT -> {
              Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  OutlinedTextField(
                    value = textOverlay,
                    onValueChange = { textOverlay = it },
                    placeholder = { Text("Type text overlay...", fontSize = 12.sp) },
                    singleLine = true,
                    modifier = Modifier.weight(1f),
                    colors = OutlinedTextFieldDefaults.colors(
                      focusedTextColor = ZvWhite,
                      unfocusedTextColor = ZvWhite,
                      focusedBorderColor = ZvOrangePrimary,
                      unfocusedBorderColor = Color(0x44FF6A00)
                    ),
                    shape = RoundedCornerShape(10.dp)
                  )
                  Spacer(modifier = Modifier.width(8.dp))
                  Box(
                    modifier = Modifier
                      .size(34.dp)
                      .clip(CircleShape)
                      .background(textColor)
                      .border(1.dp, ZvWhite, CircleShape)
                      .clickable {
                        textColor = if (textColor == Color.White) Color(0xFFFF7A00) else Color.White
                      }
                  )
                }
              }
            }

            PhotoTool.STICKERS -> {
              Column {
                Text("Tap Sticker to Overlay (Drag on canvas)", color = ZvOrangeBright, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                  listOf("🔥", "⚡", "🎬", "🚀", "🌟", "🧡", "💥", "✂️").forEach { emoji ->
                    Box(
                      modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (activeSticker == emoji) Color(0x44FF6A00) else ZvBlackCard)
                        .clickable { activeSticker = emoji }
                        .padding(4.dp),
                      contentAlignment = Alignment.Center
                    ) {
                      Text(emoji, fontSize = 22.sp)
                    }
                  }
                }
              }
            }

            PhotoTool.BACKGROUND -> {
              Column {
                Text("Background Style", color = ZvOrangeBright, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                  listOf("Dark Surface", "Orange Glow", "Studio White", "Deep Purple").forEach { bgStyle ->
                    val isSel = backgroundStyle == bgStyle
                    Box(
                      modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (isSel) ZvOrangePrimary else ZvBlackCard)
                        .clickable { backgroundStyle = bgStyle }
                        .padding(horizontal = 10.dp, vertical = 8.dp)
                    ) {
                      Text(bgStyle, color = if (isSel) ZvWhite else ZvTextSecondary, fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
                    }
                  }
                }
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // --- Bottom 9-Tools Scrollable Bar ---
        LazyRow(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 6.dp),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          items(
            listOf(
              PhotoTool.CROP to ("Crop" to Icons.Default.Crop),
              PhotoTool.RESIZE to ("Resize" to Icons.Default.Transform),
              PhotoTool.ROTATE to ("Rotate" to Icons.Default.RotateRight),
              PhotoTool.FILTERS to ("Filters" to Icons.Default.AutoAwesome),
              PhotoTool.ADJUST to ("Adjust" to Icons.Default.Tune),
              PhotoTool.EFFECTS to ("Effects" to Icons.Default.AutoAwesome),
              PhotoTool.TEXT to ("Text" to Icons.Default.TextFields),
              PhotoTool.STICKERS to ("Stickers" to Icons.Outlined.EmojiEmotions),
              PhotoTool.BACKGROUND to ("Background" to Icons.Default.ColorLens)
            )
          ) { (tool, labelPair) ->
            val isSelected = activeTool == tool
            Column(
              modifier = Modifier
                .clip(RoundedCornerShape(10.dp))
                .background(if (isSelected) ZvOrangePrimary else ZvBlackCard)
                .clickable { activeTool = tool }
                .padding(horizontal = 10.dp, vertical = 6.dp),
              horizontalAlignment = Alignment.CenterHorizontally
            ) {
              Icon(
                imageVector = labelPair.second,
                contentDescription = labelPair.first,
                tint = if (isSelected) ZvWhite else ZvOrangeBright,
                modifier = Modifier.size(18.dp)
              )
              Spacer(modifier = Modifier.height(2.dp))
              Text(
                text = labelPair.first,
                color = if (isSelected) ZvWhite else ZvTextSecondary,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
              )
            }
          }
        }
      }
    }
  }
}
