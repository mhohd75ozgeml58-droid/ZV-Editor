package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material.icons.filled.HighQuality
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.UserProfile
import com.example.ui.components.GlowBackground
import com.example.ui.components.ZvLogoBadge
import com.example.ui.components.ZvWordmark
import com.example.ui.theme.ZvBlack
import com.example.ui.theme.ZvBlackCard
import com.example.ui.theme.ZvBlackSurface
import com.example.ui.theme.ZvOrangeBright
import com.example.ui.theme.ZvOrangePrimary
import com.example.ui.theme.ZvTextMuted
import com.example.ui.theme.ZvTextSecondary
import com.example.ui.theme.ZvWhite

/**
 * 14. Settings Screen
 * Covers:
 * - Account
 * - Language (English, Hindi, Spanish)
 * - Theme (Black + Orange, High-Contrast Neon)
 * - Export Settings (Default 1080p, 60fps, Hardware Acceleration)
 * - Storage (Cache, Clear storage)
 * - Privacy (Data security)
 * - About ZV (Version, developer)
 */
@Composable
fun SettingsScreen(
  userProfile: UserProfile,
  onBack: () -> Unit,
  onOpenAuth: () -> Unit,
  onSignOut: () -> Unit,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current

  var selectedLanguage by remember { mutableStateOf("English") }
  var selectedTheme by remember { mutableStateOf("Black + Orange (Default)") }
  var defaultResolution by remember { mutableStateOf("1080p (Full HD)") }
  var hardwareAccelerationEnabled by remember { mutableStateOf(true) }
  var cacheCleared by remember { mutableStateOf(false) }

  var showLanguageDialog by remember { mutableStateOf(false) }
  var showExportDialog by remember { mutableStateOf(false) }
  var showAboutDialog by remember { mutableStateOf(false) }
  var showPrivacyDialog by remember { mutableStateOf(false) }

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(ZvBlack)
      .testTag("settings_screen")
  ) {
    GlowBackground(animated = false)

    // Outer Neon Orange Container
    Box(
      modifier = Modifier
        .fillMaxSize()
        .statusBarsPadding()
        .navigationBarsPadding()
        .padding(6.dp)
        .border(
          width = 2.dp,
          brush = Brush.verticalGradient(
            colors = listOf(Color(0xFFFF7A00), Color(0xFFFF5200), Color(0xFFFF8800))
          ),
          shape = RoundedCornerShape(20.dp)
        )
        .clip(RoundedCornerShape(20.dp))
        .background(Color(0xFF0A0A0C))
    ) {
      LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 40.dp)
      ) {
        // Top Header
        item {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            IconButton(
              onClick = onBack,
              modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(Color(0x331F1F24))
                .testTag("settings_back_button")
            ) {
              Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = "Back",
                tint = ZvOrangePrimary,
                modifier = Modifier.size(18.dp)
              )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Text(
              text = "Settings",
              color = ZvWhite,
              fontSize = 20.sp,
              fontWeight = FontWeight.Bold
            )
          }
        }

        // Section: Account
        item {
          SettingsSectionHeader(title = "ACCOUNT")
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 14.dp, vertical = 4.dp)
              .clip(RoundedCornerShape(14.dp))
              .background(ZvBlackCard)
              .border(1.dp, Color(0x33FF6A00), RoundedCornerShape(14.dp))
              .padding(14.dp)
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                  modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(if (userProfile.isAuthenticated && !userProfile.isGuest) Color(0xFF00E676) else ZvOrangePrimary),
                  contentAlignment = Alignment.Center
                ) {
                  Text(
                    text = if (userProfile.isAuthenticated && !userProfile.isGuest) {
                      userProfile.name.take(1).uppercase()
                    } else "Z",
                    color = if (userProfile.isAuthenticated && !userProfile.isGuest) Color.Black else ZvWhite,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                  )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                  Text(
                    text = if (userProfile.isAuthenticated && !userProfile.isGuest) {
                      userProfile.name
                    } else if (userProfile.isGuest) {
                      "Guest Creator"
                    } else {
                      "Not Signed In"
                    },
                    color = ZvWhite,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                  )
                  Text(
                    text = if (userProfile.isAuthenticated && !userProfile.isGuest) {
                      userProfile.email
                    } else {
                      "Sign in for cloud sync & pro features"
                    },
                    color = ZvTextMuted,
                    fontSize = 11.sp
                  )
                }
              }

              if (userProfile.isAuthenticated && !userProfile.isGuest) {
                TextButton(onClick = onSignOut) {
                  Text("Sign Out", color = Color(0xFFFF5252), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
              } else {
                Button(
                  onClick = onOpenAuth,
                  colors = ButtonDefaults.buttonColors(containerColor = ZvOrangePrimary),
                  shape = RoundedCornerShape(10.dp),
                  contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                  Text("Sign In", color = ZvWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
              }
            }
          }
        }

        // Section: Preferences
        item {
          Spacer(modifier = Modifier.height(14.dp))
          SettingsSectionHeader(title = "PREFERENCES")
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 14.dp, vertical = 4.dp)
              .clip(RoundedCornerShape(14.dp))
              .background(ZvBlackCard)
              .border(1.dp, Color(0x33FF6A00), RoundedCornerShape(14.dp))
          ) {
            SettingsItemRow(
              icon = Icons.Default.Language,
              title = "Language",
              subtitle = selectedLanguage,
              onClick = { showLanguageDialog = true }
            )
            HorizontalDivider(color = Color(0x22FF6A00), modifier = Modifier.padding(horizontal = 12.dp))
            SettingsItemRow(
              icon = Icons.Default.ColorLens,
              title = "Theme",
              subtitle = selectedTheme,
              onClick = {
                selectedTheme = if (selectedTheme.contains("Default")) {
                  "High-Contrast Neon"
                } else {
                  "Black + Orange (Default)"
                }
                Toast.makeText(context, "Theme set to $selectedTheme", Toast.LENGTH_SHORT).show()
              }
            )
          }
        }

        // Section: Export Settings
        item {
          Spacer(modifier = Modifier.height(14.dp))
          SettingsSectionHeader(title = "EXPORT SETTINGS")
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 14.dp, vertical = 4.dp)
              .clip(RoundedCornerShape(14.dp))
              .background(ZvBlackCard)
              .border(1.dp, Color(0x33FF6A00), RoundedCornerShape(14.dp))
          ) {
            SettingsItemRow(
              icon = Icons.Default.HighQuality,
              title = "Default Resolution",
              subtitle = defaultResolution,
              onClick = { showExportDialog = true }
            )
            HorizontalDivider(color = Color(0x22FF6A00), modifier = Modifier.padding(horizontal = 12.dp))
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Column(modifier = Modifier.weight(1f)) {
                Text("Hardware Acceleration", color = ZvWhite, fontSize = 13.5.sp, fontWeight = FontWeight.SemiBold)
                Text("Faster rendering using GPU codec pipeline", color = ZvTextMuted, fontSize = 11.sp)
              }
              Switch(
                checked = hardwareAccelerationEnabled,
                onCheckedChange = { hardwareAccelerationEnabled = it },
                colors = SwitchDefaults.colors(
                  checkedThumbColor = ZvWhite,
                  checkedTrackColor = ZvOrangePrimary,
                  uncheckedThumbColor = ZvTextMuted,
                  uncheckedTrackColor = ZvBlackSurface
                )
              )
            }
          }
        }

        // Section: Storage
        item {
          Spacer(modifier = Modifier.height(14.dp))
          SettingsSectionHeader(title = "STORAGE")
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 14.dp, vertical = 4.dp)
              .clip(RoundedCornerShape(14.dp))
              .background(ZvBlackCard)
              .border(1.dp, Color(0x33FF6A00), RoundedCornerShape(14.dp))
              .padding(14.dp)
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Storage, contentDescription = null, tint = ZvOrangeBright, modifier = Modifier.size(22.dp))
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                  Text("Cache & Temp Media", color = ZvWhite, fontSize = 13.5.sp, fontWeight = FontWeight.SemiBold)
                  Text(if (cacheCleared) "0 MB (Clean)" else "24.6 MB cached data", color = ZvTextMuted, fontSize = 11.sp)
                }
              }

              Button(
                onClick = {
                  cacheCleared = true
                  Toast.makeText(context, "Storage Cache Cleared!", Toast.LENGTH_SHORT).show()
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0x22FF6A00)),
                border = androidx.compose.foundation.BorderStroke(1.dp, ZvOrangePrimary),
                shape = RoundedCornerShape(10.dp),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 5.dp)
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(Icons.Default.CleaningServices, contentDescription = null, tint = ZvOrangeBright, modifier = Modifier.size(14.dp))
                  Spacer(modifier = Modifier.width(4.dp))
                  Text("Clear", color = ZvWhite, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
              }
            }
          }
        }

        // Section: About & Privacy
        item {
          Spacer(modifier = Modifier.height(14.dp))
          SettingsSectionHeader(title = "ABOUT & LEGAL")
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 14.dp, vertical = 4.dp)
              .clip(RoundedCornerShape(14.dp))
              .background(ZvBlackCard)
              .border(1.dp, Color(0x33FF6A00), RoundedCornerShape(14.dp))
          ) {
            SettingsItemRow(
              icon = Icons.Default.Lock,
              title = "Privacy Policy & Safety",
              subtitle = "100% offline-ready and private editing",
              onClick = { showPrivacyDialog = true }
            )
            HorizontalDivider(color = Color(0x22FF6A00), modifier = Modifier.padding(horizontal = 12.dp))
            SettingsItemRow(
              icon = Icons.Default.Info,
              title = "About ZV Editor",
              subtitle = "v2.4.0 • Build 2401",
              onClick = { showAboutDialog = true }
            )
          }
        }
      }
    }

    // Language Selector Dialog
    if (showLanguageDialog) {
      val languages = listOf("English", "हिन्दी (Hindi)", "Español (Spanish)")
      AlertDialog(
        onDismissRequest = { showLanguageDialog = false },
        containerColor = ZvBlackSurface,
        shape = RoundedCornerShape(18.dp),
        title = { Text("Select Language", color = ZvWhite, fontSize = 17.sp, fontWeight = FontWeight.Bold) },
        text = {
          Column {
            languages.forEach { lang ->
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .clickable {
                    selectedLanguage = lang
                    showLanguageDialog = false
                    Toast.makeText(context, "Language set to $lang", Toast.LENGTH_SHORT).show()
                  }
                  .padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                RadioButton(
                  selected = selectedLanguage.startsWith(lang.take(5)),
                  onClick = {
                    selectedLanguage = lang
                    showLanguageDialog = false
                  },
                  colors = RadioButtonDefaults.colors(selectedColor = ZvOrangePrimary)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(lang, color = ZvWhite, fontSize = 14.sp)
              }
            }
          }
        },
        confirmButton = {},
        dismissButton = {
          TextButton(onClick = { showLanguageDialog = false }) {
            Text("Cancel", color = ZvTextMuted)
          }
        }
      )
    }

    // Export Resolution Dialog
    if (showExportDialog) {
      val resolutions = listOf("480p (Fast SD)", "720p (Standard HD)", "1080p (Full HD)", "4K (Ultra HD)")
      AlertDialog(
        onDismissRequest = { showExportDialog = false },
        containerColor = ZvBlackSurface,
        shape = RoundedCornerShape(18.dp),
        title = { Text("Default Resolution", color = ZvWhite, fontSize = 17.sp, fontWeight = FontWeight.Bold) },
        text = {
          Column {
            resolutions.forEach { res ->
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .clickable {
                    defaultResolution = res
                    showExportDialog = false
                  }
                  .padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                RadioButton(
                  selected = defaultResolution == res,
                  onClick = {
                    defaultResolution = res
                    showExportDialog = false
                  },
                  colors = RadioButtonDefaults.colors(selectedColor = ZvOrangePrimary)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(res, color = ZvWhite, fontSize = 14.sp)
              }
            }
          }
        },
        confirmButton = {},
        dismissButton = {
          TextButton(onClick = { showExportDialog = false }) {
            Text("Cancel", color = ZvTextMuted)
          }
        }
      )
    }

    // About Dialog
    if (showAboutDialog) {
      AlertDialog(
        onDismissRequest = { showAboutDialog = false },
        containerColor = ZvBlackSurface,
        shape = RoundedCornerShape(20.dp),
        icon = {
          ZvLogoBadge(size = 48.dp, pulsingGlow = false)
        },
        title = {
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            ZvWordmark(fontSize = 24f)
            Text("Version 2.4.0", color = ZvOrangeBright, fontSize = 12.sp, fontWeight = FontWeight.Bold)
          }
        },
        text = {
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
              text = "Simple • Smart • Super Editing",
              color = ZvWhite,
              fontSize = 13.sp,
              fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
              text = "ZV Editor is crafted with high-performance Jetpack Compose, Room database, multi-track timeline, visual effects, and black + orange neon aesthetics.",
              color = ZvTextSecondary,
              fontSize = 12.sp,
              lineHeight = 16.sp
            )
          }
        },
        confirmButton = {
          Button(
            onClick = { showAboutDialog = false },
            colors = ButtonDefaults.buttonColors(containerColor = ZvOrangePrimary),
            shape = RoundedCornerShape(10.dp)
          ) {
            Text("OK", color = ZvWhite, fontWeight = FontWeight.Bold)
          }
        }
      )
    }

    // Privacy Dialog
    if (showPrivacyDialog) {
      AlertDialog(
        onDismissRequest = { showPrivacyDialog = false },
        containerColor = ZvBlackSurface,
        shape = RoundedCornerShape(20.dp),
        title = { Text("Privacy & Security", color = ZvWhite, fontSize = 17.sp, fontWeight = FontWeight.Bold) },
        text = {
          Column {
            Text("• Zero-Cloud Media Processing: Your videos, audio, and photos are processed strictly on-device.", color = ZvTextSecondary, fontSize = 12.sp)
            Spacer(modifier = Modifier.height(6.dp))
            Text("• Photo Picker Privacy: We access only the media you explicitly select.", color = ZvTextSecondary, fontSize = 12.sp)
            Spacer(modifier = Modifier.height(6.dp))
            Text("• Local Database Storage: All your project edits are safely kept in your local SQLite/Room database.", color = ZvTextSecondary, fontSize = 12.sp)
          }
        },
        confirmButton = {
          Button(
            onClick = { showPrivacyDialog = false },
            colors = ButtonDefaults.buttonColors(containerColor = ZvOrangePrimary),
            shape = RoundedCornerShape(10.dp)
          ) {
            Text("Got it", color = ZvWhite, fontWeight = FontWeight.Bold)
          }
        }
      )
    }
  }
}

@Composable
fun SettingsSectionHeader(title: String) {
  Text(
    text = title,
    color = ZvOrangeBright,
    fontSize = 11.sp,
    fontWeight = FontWeight.ExtraBold,
    letterSpacing = 1.sp,
    modifier = Modifier.padding(horizontal = 18.dp, vertical = 4.dp)
  )
}

@Composable
fun SettingsItemRow(
  icon: ImageVector,
  title: String,
  subtitle: String,
  onClick: () -> Unit
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .clickable { onClick() }
      .padding(14.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Row(verticalAlignment = Alignment.CenterVertically) {
      Icon(icon, contentDescription = null, tint = ZvOrangeBright, modifier = Modifier.size(20.dp))
      Spacer(modifier = Modifier.width(12.dp))
      Column {
        Text(title, color = ZvWhite, fontSize = 13.5.sp, fontWeight = FontWeight.SemiBold)
        Text(subtitle, color = ZvTextMuted, fontSize = 11.sp)
      }
    }
    Text("Edit ›", color = ZvTextSecondary, fontSize = 12.sp)
  }
}
