package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Upload
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.VerticalDivider
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.R
import com.example.model.UserProfile
import com.example.ui.components.GlowBackground
import com.example.ui.components.ZvBrandHeader
import com.example.ui.components.ZvLogoBadge
import com.example.ui.components.ZvTagline
import com.example.ui.components.ZvWordmark
import com.example.ui.theme.ZvBlack
import com.example.ui.theme.ZvBlackCard
import com.example.ui.theme.ZvBlackSurface
import com.example.ui.theme.ZvBorderGlow
import com.example.ui.theme.ZvOrangeBright
import com.example.ui.theme.ZvOrangeDeep
import com.example.ui.theme.ZvOrangeGradientEnd
import com.example.ui.theme.ZvOrangePrimary
import com.example.ui.theme.ZvTextMuted
import com.example.ui.theme.ZvTextSecondary
import com.example.ui.theme.ZvWhite
import kotlinx.coroutines.launch

/**
 * High-fidelity Welcome Screen based on the reference design:
 * - Neon orange outer rounded border
 * - Top-left "Sign Up" button
 * - Centered ZV Logo badge + typography + tagline
 * - "Create. Edit. Share." & "Your Story, Your Way."
 * - "Next ->" gradient pill button
 * - Glowing circular media showcase with ambient wave ribbons
 * - "What You Can Do" section with 4 interactive tool cards
 * - "Fast • Easy • Secure" footer badge
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WelcomeScreen(
  onReplaySplash: () -> Unit,
  onNavigateNext: () -> Unit = {},
  onOpenAuth: () -> Unit = {},
  userProfile: UserProfile = UserProfile.ANONYMOUS,
  onLogout: () -> Unit = {},
  modifier: Modifier = Modifier
) {
  var showSignUpSheet by remember { mutableStateOf(false) }
  var showProfileModal by remember { mutableStateOf(false) }
  var selectedFeature by remember { mutableStateOf<FeatureItem?>(null) }
  var showNextTourDialog by remember { mutableStateOf(false) }
  var userSelectedImageUri by remember { mutableStateOf<Uri?>(null) }

  // Zero-permission Android Photo Picker for changing the centerpiece photo
  val photoPickerLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.PickVisualMedia()
  ) { uri: Uri? ->
    if (uri != null) {
      userSelectedImageUri = uri
    }
  }

  // Neon pulsing ring animation for the circular showcase
  val infiniteTransition = rememberInfiniteTransition(label = "welcome_pulse")
  val ringGlowAlpha by infiniteTransition.animateFloat(
    initialValue = 0.45f,
    targetValue = 0.95f,
    animationSpec = infiniteRepeatable(
      animation = tween(1800, easing = FastOutSlowInEasing),
      repeatMode = RepeatMode.Reverse
    ),
    label = "ring_glow"
  )
  val ringScale by infiniteTransition.animateFloat(
    initialValue = 1f,
    targetValue = 1.04f,
    animationSpec = infiniteRepeatable(
      animation = tween(1800, easing = FastOutSlowInEasing),
      repeatMode = RepeatMode.Reverse
    ),
    label = "ring_scale"
  )

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(ZvBlack)
      .testTag("welcome_screen")
  ) {
    // Ambient glowing wave background
    GlowBackground(animated = true)

    // Main Outer Neon Orange Border Container (matches the reference screen frame)
    Box(
      modifier = Modifier
        .fillMaxSize()
        .statusBarsPadding()
        .navigationBarsPadding()
        .padding(8.dp)
        .border(
          width = 2.dp,
          brush = Brush.verticalGradient(
            colors = listOf(
              Color(0xFFFF7A00),
              Color(0xFFFF5200),
              Color(0xFFFF8800)
            )
          ),
          shape = RoundedCornerShape(22.dp)
        )
        .clip(RoundedCornerShape(22.dp))
        .background(Color(0xFF0A0A0C))
    ) {
      // Content layout
      Column(
        modifier = Modifier
          .fillMaxSize()
          .verticalScroll(rememberScrollState())
          .padding(horizontal = 14.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        // --- Top Bar: Sign Up (Left), ZV Logo (Center), Replay Splash (Right) ---
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .padding(top = 2.dp, bottom = 4.dp)
        ) {
          // Left: "Sign Up / Login" or Profile Chip
          Box(
            modifier = Modifier
              .align(Alignment.TopStart)
              .clip(RoundedCornerShape(24.dp))
              .border(
                width = 1.6.dp,
                color = if (userProfile.isAuthenticated && !userProfile.isGuest) Color(0xFF00E676) else ZvOrangePrimary,
                shape = RoundedCornerShape(24.dp)
              )
              .background(Color(0x2218181B))
              .clickable {
                if (userProfile.isAuthenticated && !userProfile.isGuest) {
                  showProfileModal = true
                } else {
                  onOpenAuth()
                }
              }
              .padding(horizontal = 12.dp, vertical = 7.dp)
              .testTag("auth_profile_button")
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
              if (userProfile.isAuthenticated && !userProfile.isGuest) {
                Box(
                  modifier = Modifier
                    .size(18.dp)
                    .clip(CircleShape)
                    .background(Color(0xFF00E676)),
                  contentAlignment = Alignment.Center
                ) {
                  Text(
                    text = userProfile.name.take(1).uppercase(),
                    color = Color.Black,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                  )
                }
                Text(
                  text = "Hi, " + (userProfile.name.split(" ").firstOrNull() ?: "Creator"),
                  color = ZvWhite,
                  fontSize = 12.sp,
                  fontWeight = FontWeight.Bold,
                  maxLines = 1
                )
              } else if (userProfile.isGuest) {
                Icon(
                  imageVector = Icons.Default.Person,
                  contentDescription = null,
                  tint = ZvOrangeBright,
                  modifier = Modifier.size(16.dp)
                )
                Text(
                  text = "Guest • Login",
                  color = ZvWhite,
                  fontSize = 12.sp,
                  fontWeight = FontWeight.Bold
                )
              } else {
                Icon(
                  imageVector = Icons.Default.Person,
                  contentDescription = null,
                  tint = ZvOrangePrimary,
                  modifier = Modifier.size(16.dp)
                )
                Text(
                  text = "Sign Up / Login",
                  color = ZvWhite,
                  fontSize = 12.sp,
                  fontWeight = FontWeight.Bold
                )
              }
            }
          }

          // Center: ZV App Badge Icon
          Column(
            modifier = Modifier.align(Alignment.Center),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            ZvLogoBadge(
              size = 52.dp,
              pulsingGlow = true
            )
          }

          // Right: Replay Splash / Restart icon
          IconButton(
            onClick = { onReplaySplash() },
            modifier = Modifier
              .align(Alignment.TopEnd)
              .size(38.dp)
              .testTag("replay_splash_button")
          ) {
            Icon(
              imageVector = Icons.Default.Refresh,
              contentDescription = "Replay Splash Screen",
              tint = ZvOrangePrimary.copy(alpha = 0.85f),
              modifier = Modifier.size(20.dp)
            )
          }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Large ZV Wordmark
        ZvWordmark(
          fontSize = 38f
        )

        Spacer(modifier = Modifier.height(2.dp))

        // Tagline: Simple • Smart • Super Editing
        ZvTagline(
          fontSize = 12.5f
        )

        Spacer(modifier = Modifier.height(14.dp))

        // --- Headline: Create. Edit. Share. Your Story, Your Way. ---
        Text(
          text = "Create. Edit. Share.",
          color = ZvWhite,
          fontSize = 24.sp,
          fontWeight = FontWeight.Black,
          textAlign = TextAlign.Center,
          letterSpacing = (-0.3).sp
        )
        Text(
          text = "Your Story, Your Way.",
          color = ZvOrangePrimary,
          fontSize = 24.sp,
          fontWeight = FontWeight.Black,
          textAlign = TextAlign.Center,
          letterSpacing = (-0.3).sp
        )

        Spacer(modifier = Modifier.height(6.dp))

        // Subtitle description
        Text(
          text = "Edit your videos and photos easily\nwith powerful tools and amazing effects.",
          color = ZvTextSecondary,
          fontSize = 13.sp,
          fontWeight = FontWeight.Normal,
          textAlign = TextAlign.Center,
          lineHeight = 18.sp,
          modifier = Modifier.padding(horizontal = 16.dp)
        )

        Spacer(modifier = Modifier.height(14.dp))

        // --- "Next ->" Button ---
        Box(
          modifier = Modifier
            .fillMaxWidth(0.85f)
            .height(46.dp)
            .shadow(
              elevation = 12.dp,
              shape = RoundedCornerShape(26.dp),
              spotColor = ZvOrangePrimary
            )
            .clip(RoundedCornerShape(26.dp))
            .background(
              Brush.horizontalGradient(
                colors = listOf(
                  Color(0xFFFF7A00),
                  Color(0xFFFF5200),
                  Color(0xFFFF3D00)
                )
              )
            )
            .clickable { onNavigateNext() }
            .testTag("next_button"),
          contentAlignment = Alignment.Center
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
          ) {
            Text(
              text = "Next",
              color = ZvWhite,
              fontSize = 18.sp,
              fontWeight = FontWeight.ExtraBold,
              letterSpacing = 0.5.sp
            )
            Spacer(modifier = Modifier.width(8.dp))
            Icon(
              imageVector = Icons.AutoMirrored.Filled.ArrowForward,
              contentDescription = null,
              tint = ZvWhite,
              modifier = Modifier.size(20.dp)
            )
          }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // --- Centerpiece: Glowing Circular Media Showcase ---
        Box(
          contentAlignment = Alignment.Center,
          modifier = Modifier
            .size(190.dp)
            .clickable {
              // Tap to pick image or show details
              photoPickerLauncher.launch(
                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
              )
            }
            .testTag("media_showcase_circle")
        ) {
          // Ambient glowing halo ring
          Box(
            modifier = Modifier
              .size(190.dp)
              .scale(ringScale)
              .clip(CircleShape)
              .border(
                width = 3.dp,
                brush = Brush.sweepGradient(
                  colors = listOf(
                    ZvOrangePrimary.copy(alpha = ringGlowAlpha),
                    ZvOrangeBright.copy(alpha = 0.3f),
                    ZvOrangePrimary.copy(alpha = ringGlowAlpha)
                  )
                ),
                shape = CircleShape
              )
          )

          // Inner dashed/fine decorative ring
          Box(
            modifier = Modifier
              .size(174.dp)
              .clip(CircleShape)
              .border(
                width = 1.5.dp,
                color = Color(0xFFFF9500).copy(alpha = 0.7f),
                shape = CircleShape
              )
          )

          // Center Image Container
          Box(
            modifier = Modifier
              .size(160.dp)
              .clip(CircleShape)
              .background(ZvBlackCard)
          ) {
            if (userSelectedImageUri != null) {
              AsyncImage(
                model = userSelectedImageUri,
                contentDescription = "User Portrait",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
              )
            } else {
              Image(
                painter = painterResource(id = R.drawable.sample_portrait),
                contentDescription = "Showcase Portrait",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
              )
            }

            // Subtle camera badge overlay indicating tap to change
            Box(
              modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .background(Color(0x88000000))
                .padding(vertical = 3.dp),
              contentAlignment = Alignment.Center
            ) {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
              ) {
                Icon(
                  imageVector = Icons.Default.PhotoCamera,
                  contentDescription = null,
                  tint = ZvOrangeBright,
                  modifier = Modifier.size(12.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                  text = "Tap to choose",
                  color = ZvWhite,
                  fontSize = 9.sp,
                  fontWeight = FontWeight.Medium
                )
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // --- "What You Can Do" Section Header ---
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Box(
            modifier = Modifier
              .weight(1f)
              .height(1.dp)
              .background(
                Brush.horizontalGradient(
                  colors = listOf(Color.Transparent, ZvOrangePrimary.copy(alpha = 0.8f))
                )
              )
          )
          Text(
            text = "What You Can Do",
            color = ZvOrangePrimary,
            fontSize = 15.sp,
            fontWeight = FontWeight.ExtraBold,
            modifier = Modifier.padding(horizontal = 10.dp)
          )
          Box(
            modifier = Modifier
              .weight(1f)
              .height(1.dp)
              .background(
                Brush.horizontalGradient(
                  colors = listOf(ZvOrangePrimary.copy(alpha = 0.8f), Color.Transparent)
                )
              )
          )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // --- 4 Tool Cards with vertical dividers ---
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .height(IntrinsicSize.Min)
            .padding(horizontal = 2.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.Top
        ) {
          // 1. Cut & Trim
          FeatureColumn(
            icon = Icons.Default.ContentCut,
            title = "Cut & Trim",
            subtitle = "Trim your videos\nperfectly",
            modifier = Modifier
              .weight(1f)
              .clickable {
                selectedFeature = FeatureItem(
                  title = "Cut & Trim",
                  icon = Icons.Default.ContentCut,
                  subtitle = "Trim your videos perfectly",
                  description = "Split, splice, and cut video clips with frame-accurate precision. Adjust speed, duplicate layers, and reverse footage with fluid tactile controls."
                )
              }
              .testTag("feature_cut_trim")
          )

          VerticalDivider(
            color = ZvOrangePrimary.copy(alpha = 0.5f),
            modifier = Modifier
              .fillMaxHeight(0.85f)
              .width(1.dp)
              .align(Alignment.CenterVertically)
          )

          // 2. Amazing Effects
          FeatureColumn(
            icon = Icons.Default.AutoAwesome,
            title = "Amazing Effects",
            subtitle = "Apply stunning\neffects",
            modifier = Modifier
              .weight(1f)
              .clickable {
                selectedFeature = FeatureItem(
                  title = "Amazing Effects",
                  icon = Icons.Default.AutoAwesome,
                  subtitle = "Apply stunning effects",
                  description = "Explore 100+ cinematic LUT filters, AI bokeh depth blur, neon edge lighting, chromatic aberration, and glitch transitions."
                )
              }
              .testTag("feature_effects")
          )

          VerticalDivider(
            color = ZvOrangePrimary.copy(alpha = 0.5f),
            modifier = Modifier
              .fillMaxHeight(0.85f)
              .width(1.dp)
              .align(Alignment.CenterVertically)
          )

          // 3. Add Music
          FeatureColumn(
            icon = Icons.Default.MusicNote,
            title = "Add Music",
            subtitle = "Add your favorite\nmusic",
            modifier = Modifier
              .weight(1f)
              .clickable {
                selectedFeature = FeatureItem(
                  title = "Add Music",
                  icon = Icons.Default.MusicNote,
                  subtitle = "Add your favorite music",
                  description = "Multi-track audio timeline with automatic beat-sync detection, royalty-free sound effects library, voice-over recording, and audio ducking."
                )
              }
              .testTag("feature_music")
          )

          VerticalDivider(
            color = ZvOrangePrimary.copy(alpha = 0.5f),
            modifier = Modifier
              .fillMaxHeight(0.85f)
              .width(1.dp)
              .align(Alignment.CenterVertically)
          )

          // 4. Easy Share
          FeatureColumn(
            icon = Icons.Default.Upload,
            title = "Easy Share",
            subtitle = "Save and share\nanywhere",
            modifier = Modifier
              .weight(1f)
              .clickable {
                selectedFeature = FeatureItem(
                  title = "Easy Share",
                  icon = Icons.Default.Upload,
                  subtitle = "Save and share anywhere",
                  description = "Export in ultra-sharp 4K 60FPS, HDR, or fast vertical reels format for Instagram, TikTok, and YouTube with one-tap instant publishing."
                )
              }
              .testTag("feature_share")
          )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // --- Bottom Footer: Shield + "Fast • Easy • Secure" ---
        Row(
          modifier = Modifier
            .padding(vertical = 4.dp)
            .testTag("security_badge"),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.Center
        ) {
          Icon(
            imageVector = Icons.Default.Shield,
            contentDescription = null,
            tint = ZvOrangePrimary,
            modifier = Modifier.size(16.dp)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = "Fast",
            color = ZvWhite,
            fontSize = 12.5.sp,
            fontWeight = FontWeight.Bold
          )
          Box(
            modifier = Modifier
              .padding(horizontal = 6.dp)
              .size(3.5.dp)
              .clip(CircleShape)
              .background(ZvOrangePrimary)
          )
          Text(
            text = "Easy",
            color = ZvWhite,
            fontSize = 12.5.sp,
            fontWeight = FontWeight.Bold
          )
          Box(
            modifier = Modifier
              .padding(horizontal = 6.dp)
              .size(3.5.dp)
              .clip(CircleShape)
              .background(ZvOrangePrimary)
          )
          Text(
            text = "Secure",
            color = ZvWhite,
            fontSize = 12.5.sp,
            fontWeight = FontWeight.Bold
          )
        }
      }
    }

    // --- Sign Up Modal Bottom Sheet ---
    if (showSignUpSheet) {
      ModalBottomSheet(
        onDismissRequest = { showSignUpSheet = false },
        sheetState = rememberModalBottomSheetState(),
        containerColor = ZvBlackSurface,
        dragHandle = {
          Box(
            modifier = Modifier
              .padding(vertical = 10.dp)
              .width(40.dp)
              .height(4.dp)
              .clip(RoundedCornerShape(2.dp))
              .background(ZvOrangePrimary.copy(alpha = 0.6f))
          )
        }
      ) {
        SignUpSheetContent(
          onDismiss = { showSignUpSheet = false }
        )
      }
    }

    // --- Feature Details Preview Dialog ---
    if (selectedFeature != null) {
      FeatureDetailModal(
        feature = selectedFeature!!,
        onDismiss = { selectedFeature = null },
        onOpenInStudio = {
          selectedFeature = null
          onNavigateNext()
        }
      )
    }

    // --- Next Tour / Getting Started Dialog ---
    if (showNextTourDialog) {
      StudioTourDialog(
        onDismiss = { showNextTourDialog = false },
        onOpenPicker = {
          showNextTourDialog = false
          photoPickerLauncher.launch(
            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
          )
        },
        onEnterStudio = {
          showNextTourDialog = false
          onNavigateNext()
        }
      )
    }

    // --- User Profile Account Sheet / Dialog ---
    if (showProfileModal && userProfile.isAuthenticated) {
      AlertDialog(
        onDismissRequest = { showProfileModal = false },
        containerColor = ZvBlackSurface,
        shape = RoundedCornerShape(22.dp),
        icon = {
          Box(
            modifier = Modifier
              .size(56.dp)
              .clip(CircleShape)
              .background(Color(0x3300E676))
              .border(2.dp, Color(0xFF00E676), CircleShape),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = userProfile.name.take(1).uppercase(),
              color = Color(0xFF00E676),
              fontSize = 24.sp,
              fontWeight = FontWeight.Bold
            )
          }
        },
        title = {
          Text(
            text = userProfile.name,
            color = ZvWhite,
            fontWeight = FontWeight.Bold,
            fontSize = 19.sp,
            textAlign = TextAlign.Center
          )
        },
        text = {
          Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
            Text(userProfile.email, color = ZvTextSecondary, fontSize = 13.sp)
            Spacer(modifier = Modifier.height(8.dp))
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0x2200E676))
                .border(1.dp, Color(0x6600E676), RoundedCornerShape(12.dp))
                .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
              Text("ZV Creator Account Active", color = Color(0xFF00E676), fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
          }
        },
        confirmButton = {
          Button(
            onClick = {
              showProfileModal = false
              onLogout()
            },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0x33FF3D00)),
            border = BorderStroke(1.dp, Color(0xFFFF3D00)),
            shape = RoundedCornerShape(14.dp)
          ) {
            Text("Sign Out", color = Color(0xFFFF8A80), fontWeight = FontWeight.Bold)
          }
        },
        dismissButton = {
          TextButton(onClick = { showProfileModal = false }) {
            Text("Close", color = ZvTextMuted)
          }
        }
      )
    }
  }
}

/**
 * Single feature column matching the exact icons, typography, and layout of the reference.
 */
@Composable
private fun FeatureColumn(
  icon: ImageVector,
  title: String,
  subtitle: String,
  modifier: Modifier = Modifier
) {
  Column(
    modifier = modifier
      .padding(horizontal = 4.dp, vertical = 4.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.Top
  ) {
    Icon(
      imageVector = icon,
      contentDescription = title,
      tint = ZvOrangePrimary,
      modifier = Modifier.size(24.dp)
    )
    Spacer(modifier = Modifier.height(6.dp))
    Text(
      text = title,
      color = ZvWhite,
      fontSize = 11.5.sp,
      fontWeight = FontWeight.Bold,
      textAlign = TextAlign.Center,
      maxLines = 1,
      overflow = TextOverflow.Ellipsis
    )
    Spacer(modifier = Modifier.height(2.dp))
    Text(
      text = subtitle,
      color = ZvTextSecondary,
      fontSize = 9.sp,
      fontWeight = FontWeight.Normal,
      textAlign = TextAlign.Center,
      lineHeight = 12.sp,
      maxLines = 2
    )
  }
}

data class FeatureItem(
  val title: String,
  val icon: ImageVector,
  val subtitle: String,
  val description: String
)

/**
 * Interactive preview dialog for clicked features (Cut & Trim, Effects, Music, Share).
 */
@Composable
fun FeatureDetailModal(
  feature: FeatureItem,
  onDismiss: () -> Unit,
  onOpenInStudio: () -> Unit = {}
) {
  var sliderValue by remember { mutableFloatStateOf(0.65f) }

  AlertDialog(
    onDismissRequest = onDismiss,
    containerColor = ZvBlackSurface,
    titleContentColor = ZvWhite,
    textContentColor = ZvTextSecondary,
    shape = RoundedCornerShape(20.dp),
    icon = {
      Box(
        modifier = Modifier
          .size(54.dp)
          .clip(CircleShape)
          .background(Color(0x33FF6A00))
          .border(1.5.dp, ZvOrangePrimary, CircleShape),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = feature.icon,
          contentDescription = null,
          tint = ZvOrangePrimary,
          modifier = Modifier.size(28.dp)
        )
      }
    },
    title = {
      Text(
        text = feature.title,
        color = ZvWhite,
        fontWeight = FontWeight.Bold,
        fontSize = 20.sp,
        textAlign = TextAlign.Center
      )
    },
    text = {
      Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.fillMaxWidth()
      ) {
        Text(
          text = feature.subtitle,
          color = ZvOrangeBright,
          fontSize = 13.sp,
          fontWeight = FontWeight.SemiBold,
          textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(10.dp))
        Text(
          text = feature.description,
          color = ZvTextSecondary,
          fontSize = 13.sp,
          textAlign = TextAlign.Center,
          lineHeight = 18.sp
        )
        Spacer(modifier = Modifier.height(16.dp))

        // Interactive tool demo slider
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(ZvBlackCard)
            .border(1.dp, Color(0x33FF6A00), RoundedCornerShape(12.dp))
            .padding(12.dp)
        ) {
          Column {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text(
                text = "Interactive Intensity",
                color = ZvWhite,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium
              )
              Text(
                text = "${(sliderValue * 100).toInt()}%",
                color = ZvOrangeBright,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
              )
            }
            Slider(
              value = sliderValue,
              onValueChange = { sliderValue = it },
              colors = SliderDefaults.colors(
                thumbColor = ZvOrangePrimary,
                activeTrackColor = ZvOrangeBright,
                inactiveTrackColor = Color(0x332E1A0E)
              )
            )
          }
        }
      }
    },
    confirmButton = {
      Button(
        onClick = {
          onDismiss()
          onOpenInStudio()
        },
        colors = ButtonDefaults.buttonColors(containerColor = ZvOrangePrimary),
        shape = RoundedCornerShape(20.dp)
      ) {
        Text("Try Tool", color = ZvWhite, fontWeight = FontWeight.Bold)
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text("Close", color = ZvTextMuted)
      }
    }
  )
}

/**
 * Sign Up Modal Bottom Sheet.
 */
@Composable
fun SignUpSheetContent(
  onDismiss: () -> Unit
) {
  var name by remember { mutableStateOf("") }
  var email by remember { mutableStateOf("") }
  var password by remember { mutableStateOf("") }
  var isSuccess by remember { mutableStateOf(false) }

  Column(
    modifier = Modifier
      .fillMaxWidth()
      .padding(horizontal = 24.dp, vertical = 8.dp)
      .navigationBarsPadding(),
    horizontalAlignment = Alignment.CenterHorizontally
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        ZvLogoBadge(size = 36.dp)
        Spacer(modifier = Modifier.width(10.dp))
        Text(
          text = "Join ZV Studio",
          color = ZvWhite,
          fontSize = 19.sp,
          fontWeight = FontWeight.Bold
        )
      }
      IconButton(onClick = onDismiss) {
        Icon(Icons.Default.Close, contentDescription = "Close", tint = ZvTextMuted)
      }
    }

    Spacer(modifier = Modifier.height(14.dp))

    if (isSuccess) {
      Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.padding(vertical = 24.dp)
      ) {
        Box(
          modifier = Modifier
            .size(60.dp)
            .clip(CircleShape)
            .background(Color(0x3300E676))
            .border(2.dp, Color(0xFF00E676), CircleShape),
          contentAlignment = Alignment.Center
        ) {
          Icon(Icons.Default.Check, contentDescription = null, tint = Color(0xFF00E676), modifier = Modifier.size(32.dp))
        }
        Spacer(modifier = Modifier.height(12.dp))
        Text(
          text = "Welcome to ZV, $name!",
          color = ZvWhite,
          fontSize = 18.sp,
          fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
          text = "Your creator account is ready. Start making magic.",
          color = ZvTextSecondary,
          fontSize = 13.sp,
          textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(20.dp))
        Button(
          onClick = onDismiss,
          modifier = Modifier.fillMaxWidth(),
          colors = ButtonDefaults.buttonColors(containerColor = ZvOrangePrimary),
          shape = RoundedCornerShape(12.dp)
        ) {
          Text("Get Started", color = ZvWhite, fontWeight = FontWeight.Bold)
        }
      }
    } else {
      OutlinedTextField(
        value = name,
        onValueChange = { name = it },
        label = { Text("Your Creator Name") },
        leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = ZvOrangeBright) },
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
        colors = OutlinedTextFieldDefaults.colors(
          focusedTextColor = ZvWhite,
          unfocusedTextColor = ZvWhite,
          focusedBorderColor = ZvOrangePrimary,
          unfocusedBorderColor = Color(0x44FF6A00),
          focusedLabelColor = ZvOrangeBright,
          unfocusedLabelColor = ZvTextMuted
        ),
        shape = RoundedCornerShape(14.dp)
      )

      Spacer(modifier = Modifier.height(10.dp))

      OutlinedTextField(
        value = email,
        onValueChange = { email = it },
        label = { Text("Email Address") },
        leadingIcon = { Icon(Icons.Default.Email, contentDescription = null, tint = ZvOrangeBright) },
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
        colors = OutlinedTextFieldDefaults.colors(
          focusedTextColor = ZvWhite,
          unfocusedTextColor = ZvWhite,
          focusedBorderColor = ZvOrangePrimary,
          unfocusedBorderColor = Color(0x44FF6A00),
          focusedLabelColor = ZvOrangeBright,
          unfocusedLabelColor = ZvTextMuted
        ),
        shape = RoundedCornerShape(14.dp)
      )

      Spacer(modifier = Modifier.height(10.dp))

      OutlinedTextField(
        value = password,
        onValueChange = { password = it },
        label = { Text("Password") },
        leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null, tint = ZvOrangeBright) },
        singleLine = true,
        visualTransformation = PasswordVisualTransformation(),
        modifier = Modifier.fillMaxWidth(),
        colors = OutlinedTextFieldDefaults.colors(
          focusedTextColor = ZvWhite,
          unfocusedTextColor = ZvWhite,
          focusedBorderColor = ZvOrangePrimary,
          unfocusedBorderColor = Color(0x44FF6A00),
          focusedLabelColor = ZvOrangeBright,
          unfocusedLabelColor = ZvTextMuted
        ),
        shape = RoundedCornerShape(14.dp)
      )

      Spacer(modifier = Modifier.height(18.dp))

      Button(
        onClick = {
          if (name.isBlank()) name = "Creator"
          isSuccess = true
        },
        modifier = Modifier
          .fillMaxWidth()
          .height(48.dp),
        colors = ButtonDefaults.buttonColors(containerColor = ZvOrangePrimary),
        shape = RoundedCornerShape(14.dp)
      ) {
        Text("Create Free Account", color = ZvWhite, fontSize = 15.sp, fontWeight = FontWeight.Bold)
      }

      Spacer(modifier = Modifier.height(10.dp))

      Text(
        text = "By continuing you agree to ZV Terms & Privacy.",
        color = ZvTextMuted,
        fontSize = 11.sp,
        textAlign = TextAlign.Center
      )

      Spacer(modifier = Modifier.height(14.dp))
    }
  }
}

/**
 * Studio Tour Dialog triggered by the "Next ->" button.
 */
@Composable
fun StudioTourDialog(
  onDismiss: () -> Unit,
  onOpenPicker: () -> Unit,
  onEnterStudio: () -> Unit = {}
) {
  AlertDialog(
    onDismissRequest = onDismiss,
    containerColor = ZvBlackSurface,
    shape = RoundedCornerShape(22.dp),
    icon = {
      Box(
        modifier = Modifier
          .size(56.dp)
          .clip(CircleShape)
          .background(Color(0x33FF6A00))
          .border(1.5.dp, ZvOrangePrimary, CircleShape),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = Icons.Default.PlayArrow,
          contentDescription = null,
          tint = ZvOrangePrimary,
          modifier = Modifier.size(32.dp)
        )
      }
    },
    title = {
      Text(
        text = "Ready to Create?",
        color = ZvWhite,
        fontWeight = FontWeight.Black,
        fontSize = 21.sp,
        textAlign = TextAlign.Center
      )
    },
    text = {
      Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.fillMaxWidth()
      ) {
        Text(
          text = "Your ZV Studio workspace is ready to edit high-definition videos, apply cinematic filters, and craft stories.",
          color = ZvTextSecondary,
          fontSize = 13.5.sp,
          textAlign = TextAlign.Center,
          lineHeight = 19.sp
        )
        Spacer(modifier = Modifier.height(14.dp))
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(ZvBlackCard)
            .clickable { onOpenPicker() }
            .padding(12.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(
            imageVector = Icons.Default.PhotoCamera,
            contentDescription = null,
            tint = ZvOrangeBright,
            modifier = Modifier.size(24.dp)
          )
          Spacer(modifier = Modifier.width(12.dp))
          Column {
            Text("Select Media from Device", color = ZvWhite, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Text("Pick photo or video to edit in ZV frame", color = ZvTextMuted, fontSize = 11.sp)
          }
        }
      }
    },
    confirmButton = {
      Button(
        onClick = {
          onDismiss()
          onEnterStudio()
        },
        colors = ButtonDefaults.buttonColors(containerColor = ZvOrangePrimary),
        shape = RoundedCornerShape(16.dp)
      ) {
        Text("Enter Studio", color = ZvWhite, fontWeight = FontWeight.Bold)
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text("Back", color = ZvTextMuted)
      }
    }
  )
}
