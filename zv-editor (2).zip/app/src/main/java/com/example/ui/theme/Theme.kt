package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = ZvOrangePrimary,
    onPrimary = ZvWhite,
    primaryContainer = ZvOrangeDeep,
    onPrimaryContainer = ZvWhite,
    secondary = ZvOrangeBright,
    onSecondary = ZvBlack,
    background = ZvBlack,
    onBackground = ZvWhite,
    surface = ZvBlackSurface,
    onSurface = ZvWhite,
    surfaceVariant = ZvBlackCard,
    onSurfaceVariant = ZvTextSecondary,
    outline = ZvOrangePrimary
  )

private val LightColorScheme = DarkColorScheme

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true,
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  MaterialTheme(colorScheme = DarkColorScheme, typography = Typography, content = content)
}
