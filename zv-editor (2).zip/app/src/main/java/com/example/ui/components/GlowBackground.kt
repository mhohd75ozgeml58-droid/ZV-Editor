package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import com.example.ui.theme.ZvBlack

/**
 * Luminous Black & Orange ambient background with undulating light ribbons
 * and ambient radiant glow matching the user's reference art.
 */
@Composable
fun GlowBackground(
  modifier: Modifier = Modifier,
  animated: Boolean = true
) {
  val infiniteTransition = rememberInfiniteTransition(label = "ambient_waves")
  val phase by if (animated) {
    infiniteTransition.animateFloat(
      initialValue = 0f,
      targetValue = 360f,
      animationSpec = infiniteRepeatable(
        animation = tween(12000, easing = LinearEasing),
        repeatMode = RepeatMode.Restart
      ),
      label = "wave_phase"
    )
  } else {
    androidx.compose.runtime.remember { androidx.compose.runtime.mutableFloatStateOf(0f) }
  }

  val pulseAlpha by if (animated) {
    infiniteTransition.animateFloat(
      initialValue = 0.4f,
      targetValue = 0.75f,
      animationSpec = infiniteRepeatable(
        animation = tween(2800, easing = FastOutSlowInEasing),
        repeatMode = RepeatMode.Reverse
      ),
      label = "pulse_alpha"
    )
  } else {
    androidx.compose.runtime.remember { androidx.compose.runtime.mutableFloatStateOf(0.5f) }
  }

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(ZvBlack)
  ) {
    Canvas(modifier = Modifier.fillMaxSize()) {
      val w = size.width
      val h = size.height
      val rad = Math.toRadians(phase.toDouble()).toFloat()

      // 1. Center ambient radial glow
      drawCircle(
        brush = Brush.radialGradient(
          colors = listOf(
            Color(0x38FF6A00),
            Color(0x18FF5500),
            Color.Transparent
          ),
          center = Offset(w * 0.5f, h * 0.52f),
          radius = w * 0.75f
        ),
        center = Offset(w * 0.5f, h * 0.52f),
        radius = w * 0.75f
      )

      // 2. Top-right subtle glow
      drawCircle(
        brush = Brush.radialGradient(
          colors = listOf(
            Color(0x22FF7A00),
            Color.Transparent
          ),
          center = Offset(w * 0.9f, h * 0.1f),
          radius = w * 0.45f
        ),
        center = Offset(w * 0.9f, h * 0.1f),
        radius = w * 0.45f
      )

      // 3. Flowing luminous orange wave ribbon 1 (Main crossing ribbon)
      val wave1Y = h * 0.54f + Math.sin(rad.toDouble()).toFloat() * 12f
      val path1 = Path().apply {
        moveTo(0f, wave1Y - 40f)
        cubicTo(
          w * 0.25f, wave1Y + 35f,
          w * 0.70f, wave1Y - 70f,
          w, wave1Y - 10f
        )
      }

      // Broad luminous glow under ribbon
      drawPath(
        path = path1,
        brush = Brush.horizontalGradient(
          colors = listOf(
            Color(0x00FF6A00),
            Color(0x66FF6A00).copy(alpha = pulseAlpha * 0.7f),
            Color(0x99FFA000).copy(alpha = pulseAlpha),
            Color(0x44FF4500).copy(alpha = pulseAlpha * 0.6f),
            Color(0x00FF6A00)
          )
        ),
        style = Stroke(width = 16f)
      )

      // Core sharp bright light ribbon
      drawPath(
        path = path1,
        brush = Brush.horizontalGradient(
          colors = listOf(
            Color(0x00FFFFFF),
            Color(0xFFFF9933).copy(alpha = pulseAlpha),
            Color(0xFFFFFFFF).copy(alpha = pulseAlpha * 0.9f),
            Color(0xFFFF7700).copy(alpha = pulseAlpha),
            Color(0x00FFFFFF)
          )
        ),
        style = Stroke(width = 3.5f)
      )

      // 4. Secondary flowing orange wave ribbon (Crossing wave)
      val wave2Y = h * 0.58f - Math.cos(rad.toDouble()).toFloat() * 10f
      val path2 = Path().apply {
        moveTo(0f, wave2Y + 30f)
        cubicTo(
          w * 0.35f, wave2Y - 45f,
          w * 0.65f, wave2Y + 40f,
          w, wave2Y - 35f
        )
      }

      drawPath(
        path = path2,
        brush = Brush.horizontalGradient(
          colors = listOf(
            Color(0x00FF4500),
            Color(0x55FF5500).copy(alpha = pulseAlpha * 0.6f),
            Color(0x88FF8800).copy(alpha = pulseAlpha * 0.8f),
            Color(0x00FF4500)
          )
        ),
        style = Stroke(width = 10f)
      )

      drawPath(
        path = path2,
        brush = Brush.horizontalGradient(
          colors = listOf(
            Color(0x00FFFFFF),
            Color(0xFFFFB366).copy(alpha = pulseAlpha * 0.8f),
            Color(0x00FFFFFF)
          )
        ),
        style = Stroke(width = 2.2f)
      )

      // Subtle orange dot grid matrix on upper-left and upper-right background
      val dotSpacing = 28f
      for (x in (w * 0.05f).toInt()..(w * 0.28f).toInt() step dotSpacing.toInt()) {
        for (y in (h * 0.08f).toInt()..(h * 0.22f).toInt() step dotSpacing.toInt()) {
          drawCircle(
            color = Color(0x24FF7700),
            radius = 1.6f,
            center = Offset(x.toFloat(), y.toFloat())
          )
        }
      }

      for (x in (w * 0.72f).toInt()..(w * 0.95f).toInt() step dotSpacing.toInt()) {
        for (y in (h * 0.08f).toInt()..(h * 0.22f).toInt() step dotSpacing.toInt()) {
          drawCircle(
            color = Color(0x20FF7700),
            radius = 1.6f,
            center = Offset(x.toFloat(), y.toFloat())
          )
        }
      }
    }
  }
}
