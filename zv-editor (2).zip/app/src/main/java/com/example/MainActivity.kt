package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.data.db.ProjectEntity
import com.example.model.ActiveEditorProject
import com.example.model.UserProfile
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.MyProjectsScreen
import com.example.ui.screens.PhotoEditorScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.screens.VideoEditorScreen
import com.example.ui.screens.WelcomeScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.ZvBlack

enum class ScreenState {
  SPLASH,
  WELCOME,
  AUTH,
  HOME,
  VIDEO_EDITOR,
  PHOTO_EDITOR,
  MY_PROJECTS,
  SETTINGS
}

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      MyApplicationTheme {
        Surface(
          modifier = Modifier.fillMaxSize(),
          color = ZvBlack
        ) {
          ZvAppRoot()
        }
      }
    }
  }
}

@Composable
fun ZvAppRoot() {
  var currentScreen by remember { mutableStateOf(ScreenState.SPLASH) }
  var userProfile by remember { mutableStateOf(UserProfile.ANONYMOUS) }
  var currentVideoProject by remember { mutableStateOf<ActiveEditorProject?>(null) }
  var currentPhotoUri by remember { mutableStateOf<String?>(null) }

  AnimatedContent(
    targetState = currentScreen,
    transitionSpec = {
      fadeIn(animationSpec = tween(400)) togetherWith fadeOut(animationSpec = tween(300))
    },
    label = "screen_navigation"
  ) { screen ->
    when (screen) {
      ScreenState.SPLASH -> {
        SplashScreen(
          onFinishSplash = {
            currentScreen = ScreenState.WELCOME
          }
        )
      }

      ScreenState.WELCOME -> {
        WelcomeScreen(
          onReplaySplash = {
            currentScreen = ScreenState.SPLASH
          },
          onNavigateNext = {
            if (userProfile.isAuthenticated) {
              currentScreen = ScreenState.HOME
            } else {
              currentScreen = ScreenState.AUTH
            }
          },
          onOpenAuth = {
            currentScreen = ScreenState.AUTH
          },
          userProfile = userProfile,
          onLogout = {
            userProfile = UserProfile.ANONYMOUS
          }
        )
      }

      ScreenState.AUTH -> {
        AuthScreen(
          onAuthSuccess = { profile ->
            userProfile = profile
            currentScreen = ScreenState.HOME
          },
          onGuestSkip = {
            userProfile = UserProfile.GUEST
            currentScreen = ScreenState.HOME
          },
          onBack = {
            currentScreen = ScreenState.WELCOME
          }
        )
      }

      ScreenState.HOME -> {
        HomeScreen(
          userProfile = userProfile,
          onNavigateToVideoEditor = { mediaUri ->
            currentVideoProject = ActiveEditorProject(
              mediaUri = mediaUri ?: ActiveEditorProject.SAMPLE_VIDEOS.first()
            )
            currentScreen = ScreenState.VIDEO_EDITOR
          },
          onNavigateToPhotoEditor = { photoUri ->
            currentPhotoUri = photoUri ?: ActiveEditorProject.SAMPLE_PHOTOS.first()
            currentScreen = ScreenState.PHOTO_EDITOR
          },
          onNavigateToMusicStudio = {
            currentVideoProject = ActiveEditorProject(
              mediaUri = ActiveEditorProject.SAMPLE_VIDEOS.first(),
              musicTrackName = "Upbeat Funk Beat"
            )
            currentScreen = ScreenState.VIDEO_EDITOR
          },
          onNavigateToEffectsStudio = {
            currentVideoProject = ActiveEditorProject(
              mediaUri = ActiveEditorProject.SAMPLE_VIDEOS.first(),
              effectName = "Glitch"
            )
            currentScreen = ScreenState.VIDEO_EDITOR
          },
          onNavigateToTextStudio = {
            currentVideoProject = ActiveEditorProject(
              mediaUri = ActiveEditorProject.SAMPLE_VIDEOS.first(),
              textOverlay = "ZV CREATOR"
            )
            currentScreen = ScreenState.VIDEO_EDITOR
          },
          onNavigateToStickersStudio = {
            currentVideoProject = ActiveEditorProject(
              mediaUri = ActiveEditorProject.SAMPLE_VIDEOS.first(),
              stickerName = "🔥"
            )
            currentScreen = ScreenState.VIDEO_EDITOR
          },
          onNavigateToMyProjects = {
            currentScreen = ScreenState.MY_PROJECTS
          },
          onNavigateToSettings = {
            currentScreen = ScreenState.SETTINGS
          },
          onOpenProject = { projectEntity ->
            if (projectEntity.type == "PHOTO") {
              currentPhotoUri = projectEntity.mediaUri
              currentScreen = ScreenState.PHOTO_EDITOR
            } else {
              currentVideoProject = ActiveEditorProject.fromEntity(projectEntity)
              currentScreen = ScreenState.VIDEO_EDITOR
            }
          },
          onOpenAuth = {
            currentScreen = ScreenState.AUTH
          }
        )
      }

      ScreenState.VIDEO_EDITOR -> {
        VideoEditorScreen(
          initialProject = currentVideoProject,
          onBack = {
            currentScreen = ScreenState.HOME
          },
          onSavedToMyProjects = {
            currentScreen = ScreenState.MY_PROJECTS
          }
        )
      }

      ScreenState.PHOTO_EDITOR -> {
        PhotoEditorScreen(
          initialPhotoUri = currentPhotoUri,
          onBack = {
            currentScreen = ScreenState.HOME
          },
          onSavedToProjects = {
            currentScreen = ScreenState.MY_PROJECTS
          }
        )
      }

      ScreenState.MY_PROJECTS -> {
        MyProjectsScreen(
          onBack = {
            currentScreen = ScreenState.HOME
          },
          onOpenProject = { projectEntity ->
            if (projectEntity.type == "PHOTO") {
              currentPhotoUri = projectEntity.mediaUri
              currentScreen = ScreenState.PHOTO_EDITOR
            } else {
              currentVideoProject = ActiveEditorProject.fromEntity(projectEntity)
              currentScreen = ScreenState.VIDEO_EDITOR
            }
          },
          onNewProject = {
            currentVideoProject = ActiveEditorProject(
              mediaUri = ActiveEditorProject.SAMPLE_VIDEOS.first()
            )
            currentScreen = ScreenState.VIDEO_EDITOR
          }
        )
      }

      ScreenState.SETTINGS -> {
        SettingsScreen(
          userProfile = userProfile,
          onBack = {
            currentScreen = ScreenState.HOME
          },
          onOpenAuth = {
            currentScreen = ScreenState.AUTH
          },
          onSignOut = {
            userProfile = UserProfile.ANONYMOUS
            currentScreen = ScreenState.WELCOME
          }
        )
      }
    }
  }
}

/**
 * Kept for test compatibility and preview rendering.
 */
@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
  Text(text = "Hello $name!", modifier = modifier)
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
  MyApplicationTheme {
    ZvAppRoot()
  }
}
