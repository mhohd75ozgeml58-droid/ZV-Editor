package com.example

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.db.ProjectEntity
import com.example.data.db.ZvDatabase
import com.example.data.repository.ProjectRepository
import com.example.model.ActiveEditorProject
import com.example.model.UserProfile
import com.example.ui.screens.HOME_TILES
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  private lateinit var db: ZvDatabase
  private lateinit var repository: ProjectRepository

  @Before
  fun setup() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    db = Room.inMemoryDatabaseBuilder(context, ZvDatabase::class.java)
      .allowMainThreadQueries()
      .build()
    repository = ProjectRepository(db.projectDao())
  }

  @After
  fun teardown() {
    db.close()
  }

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("ZV Editor", appName)
  }

  @Test
  fun `verify user profile guest mode defaults`() {
    val guest = UserProfile.GUEST
    assertEquals(true, guest.isGuest)
    assertEquals(true, guest.isAuthenticated)
    assertEquals("Guest Creator", guest.name)

    val anon = UserProfile.ANONYMOUS
    assertEquals(false, anon.isGuest)
    assertEquals(false, anon.isAuthenticated)
  }

  @Test
  fun `verify 8 core home tiles exist`() {
    assertEquals(8, HOME_TILES.size)
    val tileIds = HOME_TILES.map { it.id }
    assertTrue(tileIds.contains("video_editor"))
    assertTrue(tileIds.contains("photo_editor"))
    assertTrue(tileIds.contains("music"))
    assertTrue(tileIds.contains("effects"))
    assertTrue(tileIds.contains("text"))
    assertTrue(tileIds.contains("stickers"))
    assertTrue(tileIds.contains("my_projects"))
    assertTrue(tileIds.contains("settings"))
  }

  @Test
  fun `verify room project persistence CRUD operations`() = runBlocking {
    // 1. Insert
    val project = ProjectEntity(
      title = "Test Video Project",
      type = "VIDEO",
      durationSeconds = 20.0f,
      aspectRatio = "9:16",
      filterName = "Vivid Orange",
      musicTrackName = "Upbeat Funk Beat"
    )
    val insertedId = repository.saveProject(project)
    assertTrue(insertedId > 0)

    // 2. Read
    val list = repository.allProjects.first()
    assertEquals(1, list.size)
    assertEquals("Test Video Project", list[0].title)
    assertEquals("Vivid Orange", list[0].filterName)

    // 3. Rename
    repository.renameProject(insertedId, "Renamed ZV Project")
    val updated = repository.getProjectById(insertedId)
    assertNotNull(updated)
    assertEquals("Renamed ZV Project", updated?.title)

    // 4. Duplicate
    val dupId = repository.duplicateProject(insertedId)
    assertNotNull(dupId)
    val listAfterDup = repository.allProjects.first()
    assertEquals(2, listAfterDup.size)
    assertTrue(listAfterDup.any { it.title == "Renamed ZV Project (Copy)" })

    // 5. Delete
    repository.deleteProject(insertedId)
    val listAfterDelete = repository.allProjects.first()
    assertEquals(1, listAfterDelete.size)
  }

  @Test
  fun `verify active editor project model conversions`() {
    val active = ActiveEditorProject(
      title = "Cinema Masterpiece",
      type = "VIDEO",
      aspectRatio = "16:9",
      speed = 1.5f,
      volume = 1.2f,
      filterName = "Cyber Neon",
      effectName = "Glitch",
      textOverlay = "EPIC TRAVEL"
    )

    val entity = active.toEntity()
    assertEquals("Cinema Masterpiece", entity.title)
    assertEquals("16:9", entity.aspectRatio)
    assertEquals(1.5f, entity.speed)
    assertEquals("Cyber Neon", entity.filterName)
    assertEquals("Glitch", entity.effectName)
    assertEquals("EPIC TRAVEL", entity.textOverlay)

    val backToActive = ActiveEditorProject.fromEntity(entity)
    assertEquals(active.title, backToActive.title)
    assertEquals(active.aspectRatio, backToActive.aspectRatio)
    assertEquals(active.filterName, backToActive.filterName)
  }
}
